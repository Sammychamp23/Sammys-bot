const https = require('https');

const OANDA_BASE = 'api-fxpractice.oanda.com';
const API_KEY    = process.env.OANDA_API_KEY;
const ACCOUNT_ID = process.env.OANDA_ACCOUNT_ID;

function oandaRequest(method, path, body = null) {
  return new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : null;
    const opts = {
      hostname: OANDA_BASE,
      path,
      method,
      headers: {
        Authorization: `Bearer ${API_KEY}`,
        'Content-Type': 'application/json',
        ...(data ? { 'Content-Length': Buffer.byteLength(data) } : {}),
      },
    };

    const req = https.request(opts, (res) => {
      let raw = '';
      res.on('data', (c) => (raw += c));
      res.on('end', () => {
        try {
          resolve({ status: res.statusCode, body: JSON.parse(raw) });
        } catch {
          resolve({ status: res.statusCode, body: raw });
        }
      });
    });

    req.on('error', reject);
    if (data) req.write(data);
    req.end();
  });
}

// Convert a display pair like "EUR/USD" or "EURUSD" to OANDA instrument format "EUR_USD"
function normalizeInstrument(pair) {
  let p = pair.replace(/\s/g, '').toUpperCase();
  // Already has separator
  if (p.includes('/')) return p.replace('/', '_');
  if (p.includes('_')) return p;
  // 6-char pair with no separator e.g. EURUSD → EUR_USD
  if (p.length === 6) return p.slice(0, 3) + '_' + p.slice(3);
  return p;
}

// Get current mid price for an instrument
async function getPrice(instrument) {
  const inst = normalizeInstrument(instrument);
  const res = await oandaRequest('GET', `/v3/accounts/${encodeURIComponent(ACCOUNT_ID)}/pricing?instruments=${inst}`);
  if (res.status !== 200) throw new Error(`Pricing failed: ${JSON.stringify(res.body)}`);
  const price = res.body.prices?.[0];
  if (!price) throw new Error('No price data returned');
  const bid = parseFloat(price.bids[0].price);
  const ask = parseFloat(price.asks[0].price);
  return { bid, ask, mid: (bid + ask) / 2 };
}

// Get account summary
async function getAccountSummary() {
  const res = await oandaRequest('GET', `/v3/accounts/${encodeURIComponent(ACCOUNT_ID)}/summary`);
  if (res.status !== 200) throw new Error(`Account summary failed: ${JSON.stringify(res.body)}`);
  return res.body.account;
}

// Place a market order with SL and TP
// direction: 'BUY' or 'SELL'
// units: positive for BUY, negative for SELL (e.g. 1000 or -1000)
// sl: stop loss price string
// tp: take profit price string
async function placeMarketOrder({ instrument, direction, units, sl, tp }) {
  const inst = normalizeInstrument(instrument);
  const signedUnits = direction === 'BUY' ? Math.abs(units) : -Math.abs(units);

  const order = {
    order: {
      type: 'MARKET',
      instrument: inst,
      units: String(signedUnits),
      timeInForce: 'FOK',
      ...(sl ? { stopLossOnFill: { price: String(sl), timeInForce: 'GTC' } } : {}),
      ...(tp ? { takeProfitOnFill: { price: String(tp), timeInForce: 'GTC' } } : {}),
    },
  };

  const res = await oandaRequest('POST', `/v3/accounts/${encodeURIComponent(ACCOUNT_ID)}/orders`, order);
  if (res.status !== 201) throw new Error(`Order failed (${res.status}): ${JSON.stringify(res.body)}`);
  return res.body;
}

// Close all open trades for an instrument
async function closeOpenTrades(instrument) {
  const inst = normalizeInstrument(instrument);
  const res = await oandaRequest('GET', `/v3/accounts/${encodeURIComponent(ACCOUNT_ID)}/openTrades`);
  if (res.status !== 200) throw new Error('Could not fetch open trades');

  const matching = (res.body.trades || []).filter((t) => t.instrument === inst);
  const results = [];
  for (const trade of matching) {
    const r = await oandaRequest('PUT', `/v3/accounts/${ACCOUNT_ID}/trades/${trade.id}/close`);
    results.push(r);
  }
  return results;
}

module.exports = { placeMarketOrder, getPrice, getAccountSummary, normalizeInstrument, closeOpenTrades };
