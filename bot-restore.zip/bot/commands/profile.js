const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getLevel, xpForLevel, getCoins, getChallenge, getRep, getPath, getUserSquad, getInventory } = require('../data/store');

const PATHS = {
  casual:      { name: '🎮 Casual' },
  competitive: { name: '⚔️ Competitive' },
  creator:     { name: '🎬 Content Creator' },
  trader:      { name: '💹 Trader' },
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName('profile')
    .setDescription('View a full player profile')
    .addUserOption((opt) => opt.setName('user').setDescription('User to view (default: you)')),

  async execute(interaction) {
    const target = interaction.options.getUser('user') ?? interaction.user;
    const guildId = interaction.guild.id;
    const userId = target.id;

    const { level, xp } = getLevel(guildId, userId);
    const needed = xpForLevel(level + 1);
    const bar = '█'.repeat(Math.floor((xp / needed) * 15)) + '░'.repeat(15 - Math.floor((xp / needed) * 15));
    const econData = getCoins(guildId, userId);
    const coins = econData.coins;
    const voiceMinutes = econData.voiceMinutes || 0;
    const challengeStats = getChallenge(guildId, userId);
    const { rep } = getRep(guildId, userId);
    const pathData = getPath(guildId, userId);
    const squad = getUserSquad(guildId, userId);
    const inventory = getInventory(guildId, userId);
    const member = await interaction.guild.members.fetch(userId).catch(() => null);

    const embed = new EmbedBuilder()
      .setColor(0x6366f1)
      .setTitle(`🎮 ${target.username}'s Profile`)
      .setThumbnail(target.displayAvatarURL({ dynamic: true }))
      .addFields(
        { name: '⭐ Level', value: `**${level}**\n\`${bar}\`\n${xp}/${needed} XP`, inline: true },
        { name: '💰 Coins', value: `**${coins.toLocaleString()}**`, inline: true },
        { name: '⭐ Reputation', value: `**${rep}** rep`, inline: true },
        { name: '⚔️ Challenges', value: `W: **${challengeStats.wins}** | L: **${challengeStats.losses}**`, inline: true },
        { name: '🎙️ VC Time', value: `**${voiceMinutes}** min`, inline: true },
        { name: '🛤️ Path', value: pathData ? PATHS[pathData.path]?.name ?? pathData.path : 'None chosen', inline: true },
        { name: '🏰 Squad', value: squad ? `**${squad.name}**` : 'No squad', inline: true },
        { name: '🎒 Inventory', value: inventory.length > 0 ? inventory.slice(0, 5).join(', ') + (inventory.length > 5 ? ` +${inventory.length - 5} more` : '') : 'Empty', inline: true },
      )
      .setFooter({ text: `Member since: ${member?.joinedAt?.toDateString() ?? 'Unknown'}` })
      .setTimestamp();

    return interaction.reply({ embeds: [embed] });
  },
};
