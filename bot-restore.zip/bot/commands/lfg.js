const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { checkFirstAction, addCoins, addXp } = require('../data/store');

const GAME_ROLES = ['🔫 Fortnite','⚡ Valorant','🔲 Minecraft','💣 Call of Duty','🏃 Apex Legends','🌍 GTA V','🔵 Roblox','🗡️ League of Legends','💀 Warzone','🎯 Overwatch 2','⚽ Rocket League','🕷️ Dead by Daylight'];
const PLATFORM_ROLES = ['🖥️ PC','🎮 PlayStation','🟢 Xbox','📱 Mobile','🔴 Nintendo Switch'];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('lfg')
    .setDescription('Looking for Group — create or find matches')
    .addSubcommand((sub) =>
      sub.setName('create').setDescription('Create an LFG listing')
        .addStringOption((opt) => opt.setName('game').setDescription('Game you want to play').setRequired(true))
        .addStringOption((opt) => opt.setName('mode').setDescription('Game mode (Ranked, Casual, Duo…)').setRequired(true))
        .addIntegerOption((opt) => opt.setName('players').setDescription('Players needed').setRequired(true).setMinValue(1).setMaxValue(10))
        .addStringOption((opt) => opt.setName('platform').setDescription('Platform (PC, PlayStation, Xbox…)'))
        .addStringOption((opt) => opt.setName('note').setDescription('Extra info (rank, region, mic…)'))
    )
    .addSubcommand((sub) =>
      sub.setName('find').setDescription('Find open LFG listings in the channel')
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub === 'find') {
      const lfgChannel = interaction.guild.channels.cache.find((c) => c.name === '🔍lfg' && c.isTextBased());
      const embed = new EmbedBuilder()
        .setColor(0x6366f1)
        .setTitle('🔍 Find a Group')
        .setDescription(
          lfgChannel
            ? `Browse open listings in ${lfgChannel}!\n\nUse \`/lfg create\` to post your own.`
            : 'No dedicated LFG channel found. Use `/lfg create` to post here.'
        )
        .addFields(
          { name: '💡 Tip', value: 'Make sure your game & platform roles match in `/lfg create` for the best matches!' }
        )
        .setTimestamp();
      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'create') {
      const game = interaction.options.getString('game');
      const mode = interaction.options.getString('mode');
      const players = interaction.options.getInteger('players');
      const platform = interaction.options.getString('platform') ?? 'Any';
      const note = interaction.options.getString('note') ?? 'None';

      const lfgChannel =
        interaction.guild.channels.cache.find((c) => c.name === '🔍lfg' && c.isTextBased()) ??
        interaction.channel;

      // Find matching game role to ping
      const matchedGameRole = interaction.guild.roles.cache.find(
        (r) => GAME_ROLES.includes(r.name) && r.name.toLowerCase().includes(game.toLowerCase())
      );
      const matchedPlatformRole = interaction.guild.roles.cache.find(
        (r) => PLATFORM_ROLES.includes(r.name) && r.name.toLowerCase().includes(platform.toLowerCase())
      );

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('lfg_join').setLabel('✋ Join').setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId('lfg_close').setLabel('🔒 Close').setStyle(ButtonStyle.Danger),
      );

      const embed = new EmbedBuilder()
        .setColor(0x22c55e)
        .setTitle(`🔍 LFG — ${game}`)
        .setAuthor({ name: interaction.user.username, iconURL: interaction.user.displayAvatarURL() })
        .addFields(
          { name: '🎮 Game', value: game, inline: true },
          { name: '⚔️ Mode', value: mode, inline: true },
          { name: '👥 Players Needed', value: `${players}`, inline: true },
          { name: '🖥️ Platform', value: platform, inline: true },
          { name: '📝 Note', value: note, inline: true },
          { name: '✋ Joined', value: `${interaction.user}` },
        )
        .setFooter({ text: 'Click Join to fill a spot!' })
        .setTimestamp();

      // Ping relevant roles
      const pingContent = [
        matchedGameRole ? `${matchedGameRole}` : '',
        matchedPlatformRole ? `${matchedPlatformRole}` : '',
      ].filter(Boolean).join(' ');

      const msg = await lfgChannel.send({ content: pingContent || undefined, embeds: [embed], components: [row] });

      // Auto-create a temp voice channel for the group
      const voiceCat = interaction.guild.channels.cache.find((c) => c.name === '🔊 VOICE CHANNELS' && c.type === 4);
      let tempVoice = null;
      if (voiceCat) {
        tempVoice = await interaction.guild.channels.create({
          name: `🎮 ${game} — ${mode}`,
          type: 2,
          parent: voiceCat.id,
          userLimit: players,
        }).catch(() => null);
      }

      const replyContent = [
        `✅ LFG posted in ${lfgChannel}!`,
        tempVoice ? `🎙️ Temp voice channel created: ${tempVoice}` : '',
        matchedGameRole ? `📣 Pinged ${matchedGameRole.name} players.` : '',
      ].filter(Boolean).join('\n');

      await interaction.reply({ content: replyContent, ephemeral: true });

      // First action bonus: first LFG post of the day
      if (checkFirstAction(interaction.guild.id, interaction.user.id, 'lfg')) {
        addCoins(interaction.guild.id, interaction.user.id, 60);
        addXp(interaction.guild.id, interaction.user.id, 120);
        const bonusEmbed = new EmbedBuilder()
          .setColor(0x22c55e)
          .setTitle('🔍 First LFG Bonus!')
          .setDescription(`${interaction.user} posted their **first LFG today!** 🎉\n+**60 💰 coins** + **120 ⭐ XP** bonus!\n\n*Keep finding teammates to earn more!*`)
          .setFooter({ text: 'Come back tomorrow for another first-LFG bonus!' })
          .setTimestamp();
        lfgChannel.send({ embeds: [bonusEmbed] }).catch(() => {});
      }

      const joined = new Set([interaction.user.id]);

      const collector = msg.createMessageComponentCollector({ time: 3_600_000 });

      collector.on('collect', async (btn) => {
        if (btn.customId === 'lfg_join') {
          if (joined.has(btn.user.id)) return btn.reply({ content: '❌ Already joined!', ephemeral: true });
          joined.add(btn.user.id);
          const names = [...joined].map((id) => `<@${id}>`).join(', ');
          const remaining = Math.max(0, players - joined.size);
          const updatedEmbed = EmbedBuilder.from(embed).setFields(
            { name: '🎮 Game', value: game, inline: true },
            { name: '⚔️ Mode', value: mode, inline: true },
            { name: '👥 Spots Remaining', value: `${remaining}`, inline: true },
            { name: '🖥️ Platform', value: platform, inline: true },
            { name: '📝 Note', value: note, inline: true },
            { name: `✋ Joined (${joined.size})`, value: names },
          );
          if (joined.size >= players) {
            updatedEmbed.setColor(0xef4444).setTitle(`🔒 LFG FULL — ${game}`);
            collector.stop('full');
          }
          await btn.update({ embeds: [updatedEmbed], components: joined.size < players ? [row] : [] });
        }

        if (btn.customId === 'lfg_close') {
          if (btn.user.id !== interaction.user.id) return btn.reply({ content: '❌ Only the creator can close.', ephemeral: true });
          collector.stop('closed');
          const closedEmbed = EmbedBuilder.from(embed).setColor(0x6b7280).setTitle(`🔒 LFG Closed — ${game}`);
          await btn.update({ embeds: [closedEmbed], components: [] });
          if (tempVoice) await tempVoice.delete().catch(() => {});
        }
      });

      collector.on('end', async (_, reason) => {
        if (reason === 'time') {
          const expiredEmbed = EmbedBuilder.from(embed).setColor(0x6b7280).setTitle(`⌛ LFG Expired — ${game}`);
          await msg.edit({ embeds: [expiredEmbed], components: [] }).catch(() => {});
          if (tempVoice) await tempVoice.delete().catch(() => {});
        }
      });
    }
  },
};
