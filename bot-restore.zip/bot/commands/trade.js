const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const OpenAI = require('openai').default;
const { placeMarketOrder, getAccountSummary, getPrice } = require('../oanda');
const fs = require('fs');
const path = require('path');

const openai = (process.env.AI_INTEGRATIONS_OPENAI_API_KEY || process.env.OPENAI_API_KEY)
  ? new OpenAI({
      apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY || process.env.OPENAI_API_KEY,
      baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL || undefined,
    })
  : null;

const TIMEFRAMES = ['1m', '5m', '15m', '30m', '1h', '4h', '1D', '1W'];

// Persist alert channel per guild
const SETTINGS_FILE = path.join(__dirname, '../data/trade-settings.json');

function loadSettings() {
  try {
    if (fs.existsSync(SETTINGS_FILE)) return JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf8'));
  } catch {}
  return {};
}

function saveSettings(data) {
  fs.writeFileSync(SETTINGS_FILE, JSON.stringify(data, null, 2));
}

function getAlertChannelId(guildId) {
  return loadSettings()[guildId]?.alertChannelId || null;
}

function setAlertChannelId(guildId, channelId) {
  const settings = loadSettings();
  settings[guildId] = { ...(settings[guildId] || {}), alertChannelId: channelId };
  saveSettings(settings);
}

module.exports = {
  setAlertChannelId,
  data: new SlashCommandBuilder()
    .setName('trade')
    .setDescription('AI-powered forex trade analysis and signals')
    .addSubcommand((sub) =>
      sub
        .setName('analyze')
        .setDescription('Upload a chart and get an AI trade signal')
        .addAttachmentOption((opt) =>
          opt.setName('chart').setDescription('Screenshot of your forex chart').setRequired(true)
        )
        .addStringOption((opt) =>
          opt.setName('pair').setDescription('Currency pair (e.g. EUR/USD, GBP/JPY)').setRequired(false)
        )
        .addStringOption((opt) =>
          opt
            .setName('timeframe')
            .setDescription('Chart timeframe')
            .setRequired(false)
            .addChoices(...TIMEFRAMES.map((tf) => ({ name: tf, value: tf })))
        )
        .addStringOption((opt) =>
          opt
            .setName('direction')
            .setDescription('Trade direction you are considering')
            .setRequired(false)
            .addChoices(
              { name: 'Long (Buy)', value: 'long' },
              { name: 'Short (Sell)', value: 'short' },
              { name: 'Undecided', value: 'undecided' }
            )
        )
        .addBooleanOption((opt) =>
          opt
            .setName('autotrade')
            .setDescription('Automatically place the trade on your OANDA demo account?')
            .setRequired(false)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName('setchannel')
        .setDescription('Set which channel receives major trade alert pings')
        .addChannelOption((opt) =>
          opt
            .setName('channel')
            .setDescription('The channel to send emergency trade alerts to')
            .setRequired(true)
        )
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    // ── SET CHANNEL ──────────────────────────────────────────────────────────
    if (sub === 'setchannel') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
        return interaction.reply({
          content: '❌ You need the **Manage Channels** permission to set the alert channel.',
          flags: 64,
        });
      }

      const channel = interaction.options.getChannel('channel');

      if (!channel.isTextBased()) {
        return interaction.reply({ content: '❌ Please pick a text channel.', flags: 64 });
      }

      setAlertChannelId(interaction.guild.id, channel.id);

      return interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(0x6366f1)
            .setTitle('✅ Alert Channel Set')
            .setDescription(
              `Major trade alerts (high-confidence signals) will now be sent to ${channel}.\n\n` +
              `Whenever the AI detects a strong BUY or SELL signal, it will ping @everyone there automatically.`
            )
            .setTimestamp(),
        ],
        flags: 64,
      });
    }

    // ── ANALYZE ──────────────────────────────────────────────────────────────
    if (sub === 'analyze') {
      await interaction.deferReply();

      const attachment  = interaction.options.getAttachment('chart');
      const pair        = interaction.options.getString('pair')      || 'Unknown pair';
      const timeframe   = interaction.options.getString('timeframe') || 'Unknown timeframe';
      const direction   = interaction.options.getString('direction') || 'undecided';
      const autoTrade   = interaction.options.getBoolean('autotrade') ?? true;

      const validTypes = ['image/png', 'image/jpeg', 'image/jpg', 'image/webp', 'image/gif'];
      if (!validTypes.includes(attachment.contentType)) {
        return interaction.editReply({
          content: '❌ Please attach a valid image file (PNG, JPEG, WebP, or GIF).',
        });
      }

      const directionText =
        direction === 'long' ? 'a Long (Buy)' : direction === 'short' ? 'a Short (Sell)' : 'an undecided';

      const pairInfo      = pair      !== 'Unknown pair'      ? `The pair is **${pair}**.`           : '';
      const timeframeInfo = timeframe !== 'Unknown timeframe' ? `The timeframe is **${timeframe}**.` : '';
      const directionInfo =
        direction !== 'undecided'
          ? `The trader is leaning ${directionText} — confirm or correct this bias based on what you see.`
          : 'The trader has no directional bias yet.';

      const prompt = `You are an advanced market analysis and prediction trading bot. Analyze the chart image and generate a HIGH CONVICTION trading signal.

${pairInfo} ${timeframeInfo} ${directionInfo}

IMPORTANT RULES:
- You MUST output either BUY or SELL. HOLD is not allowed. Always pick the stronger direction based on the chart.
- Weigh all the evidence and commit to a side — if it's unclear, pick the direction with even a slight edge and explain why.
- All price numbers MUST be wrapped in backticks like \`1.0920\` so the user can easily copy them.
- Confidence must reflect how strongly the indicators align — be honest but always commit to a direction.

Study the chart carefully and identify:
- Price trend (uptrend, downtrend, ranging)
- RSI (if visible — overbought above 70, oversold below 30)
- MACD (if visible — bullish or bearish crossover, momentum direction)
- EMA/SMA (if visible — is price above or below the moving average lines)
- Bollinger Bands (if visible — squeeze, breakout, band touch)
- Support & Resistance (key price floors and ceilings)
- Volume (if visible — is it confirming the move or weak)
- Candlestick patterns (engulfing, pin bar, doji, strong breakout candle, etc.)

You MUST commit to BUY or SELL. There is no third option.

Output your signal in EXACTLY this format:

🚨 **SIGNAL ALERT**
**Pair:** ${pair !== 'Unknown pair' ? pair : '[read from chart]'}
**Direction:** BUY 📈 or SELL 📉 (pick one — no HOLD)
**Confidence:** XX%
**Timeframe:** ${timeframe !== 'Unknown timeframe' ? timeframe : '[read from chart]'} — Scalp / Intraday / Swing

📋 **Why this signal:**
- [Signal 1 — explain in one plain sentence what this indicator is showing]
- [Signal 2 — explain in one plain sentence]
- [Signal 3 — explain in one plain sentence]

📉 **Risk Management:**
- **Take Profit 1:** \`[price]\` — first place to take money off the table
- **Take Profit 2:** \`[price]\` — bigger target if momentum continues
- **Stop Loss:** \`[price]\` — exit here if the trade goes wrong
- **Risk/Reward:** [X:X] — for every $1 you risk, you could make $X

🗣️ **In plain English:**
2–3 sentences explaining the trade simply. No jargon — if you use a term, explain it in brackets right after.

⚠️ *Not financial advice. Always do your own research before placing any trade.*

If the image is not a chart or too blurry to read, say so clearly.`;

      if (!openai) {
        return interaction.editReply({ content: '❌ AI analysis is not configured. Please set the OpenAI API key.' });
      }

      // Download the image from Discord first (ephemeral URLs expire quickly)
      let imageDataUrl;
      try {
        const imgResponse = await fetch(attachment.url);
        if (!imgResponse.ok) throw new Error(`Image download failed: ${imgResponse.status}`);
        const buffer = Buffer.from(await imgResponse.arrayBuffer());
        const mimeType = attachment.contentType || 'image/png';
        imageDataUrl = `data:${mimeType};base64,${buffer.toString('base64')}`;
      } catch (err) {
        console.error('[trade] Image download error:', err);
        return interaction.editReply({ content: '❌ Failed to download the chart image. Please try again.' });
      }

      let analysis;
      try {
        const response = await openai.chat.completions.create({
          model: 'gpt-5.2',
          max_completion_tokens: 8192,
          messages: [
            {
              role: 'user',
              content: [
                { type: 'image_url', image_url: { url: imageDataUrl } },
                { type: 'text', text: prompt },
              ],
            },
          ],
        });
        analysis = response.choices[0]?.message?.content;
      } catch (err) {
        console.error('[trade] OpenAI error:', err);
        return interaction.editReply({ content: '❌ Failed to analyze the chart. Please try again.' });
      }

      if (!analysis) {
        return interaction.editReply({ content: '❌ The AI did not return an analysis. Please try again.' });
      }

      // Parse signal from AI response
      const isBuy  = /\*\*Direction:\*\*\s*BUY/i.test(analysis);
      const isSell = /\*\*Direction:\*\*\s*SELL/i.test(analysis);
      const aiDirection = isBuy ? 'BUY' : isSell ? 'SELL' : 'HOLD';

      const confidenceMatch = analysis.match(/\*\*Confidence:\*\*\s*(\d+)%/i);
      const confidence = confidenceMatch ? parseInt(confidenceMatch[1]) : 0;

      // If user didn't provide a pair, try to read it from the AI's analysis
      const aiPairMatch = analysis.match(/\*\*Pair:\*\*\s*([A-Z]{3}[/\\_]?[A-Z]{3})/i);
      const tradePair = (pair !== 'Unknown pair') ? pair : (aiPairMatch ? aiPairMatch[1] : null);

      const tp1Match = analysis.match(/Take Profit 1[^`]*`([^`]+)`/i);
      const tp2Match = analysis.match(/Take Profit 2[^`]*`([^`]+)`/i);
      const slMatch  = analysis.match(/Stop Loss[^`]*`([^`]+)`/i);
      const tp1 = tp1Match ? tp1Match[1] : null;
      const tp2 = tp2Match ? tp2Match[1] : null;
      const sl  = slMatch  ? slMatch[1]  : null;

      const signalEmoji = aiDirection === 'BUY' ? '📈' : aiDirection === 'SELL' ? '📉' : '➡️';
      const signalColor = aiDirection === 'BUY' ? 0x22c55e : aiDirection === 'SELL' ? 0xef4444 : 0x6366f1;

      const truncate = (text, max = 4096) => (text.length > max ? text.slice(0, max - 3) + '...' : text);

      const embed = new EmbedBuilder()
        .setColor(signalColor)
        .setTitle(`${signalEmoji} Market Prediction — ${pair}`)
        .setDescription(`**Timeframe:** ${timeframe} | **Confidence:** ${confidence}%\n\n` + truncate(analysis))
        .setImage(attachment.url)
        .setFooter({
          text: `Requested by ${interaction.user.username} • AI analysis only — not financial advice`,
          iconURL: interaction.user.displayAvatarURL(),
        })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });

      // ── AUTO-TRADE on OANDA demo ──────────────────────────────────────────
      if (autoTrade && (aiDirection === 'BUY' || aiDirection === 'SELL') && tradePair) {
        try {
          const account = await getAccountSummary();
          const balance  = parseFloat(account.balance);
          // Risk 1% of account balance per trade, minimum 1000 units
          const riskAmount = balance * 0.01;
          const units = Math.max(1000, Math.floor(riskAmount * 100));

          const priceData = await getPrice(tradePair);
          const currentPrice = aiDirection === 'BUY' ? priceData.ask : priceData.bid;

          // Use parsed SL/TP from AI or fall back to pip-based defaults
          const pipSize = tradePair.includes('JPY') ? 0.01 : 0.0001;
          const defaultSl = aiDirection === 'BUY'
            ? (currentPrice - pipSize * 30).toFixed(tradePair.includes('JPY') ? 3 : 5)
            : (currentPrice + pipSize * 30).toFixed(tradePair.includes('JPY') ? 3 : 5);
          const defaultTp = aiDirection === 'BUY'
            ? (currentPrice + pipSize * 60).toFixed(tradePair.includes('JPY') ? 3 : 5)
            : (currentPrice - pipSize * 60).toFixed(tradePair.includes('JPY') ? 3 : 5);

          const finalSl = sl || defaultSl;
          const finalTp = tp1 || defaultTp;

          const orderResult = await placeMarketOrder({
            instrument: tradePair,
            direction: aiDirection,
            units,
            sl: finalSl,
            tp: finalTp,
          });

          const tradeId = orderResult.orderFillTransaction?.tradeOpened?.tradeID || 'N/A';
          const fillPrice = orderResult.orderFillTransaction?.price || currentPrice;

          const autoEmbed = new EmbedBuilder()
            .setColor(aiDirection === 'BUY' ? 0x00ff88 : 0xff2244)
            .setTitle(`✅ TRADE PLACED ON OANDA — ${tradePair}`)
            .setDescription(
              `🎯 **A real trade has been placed on your OANDA demo account right now.**\n\n` +
              `**Pair:** ${tradePair}\n` +
              `**Direction:** ${aiDirection === 'BUY' ? '📈 BUY' : '📉 SELL'}\n` +
              `**Units:** ${units.toLocaleString()}\n` +
              `**Entry Price:** \`${fillPrice}\`\n` +
              `**Take Profit:** \`${finalTp}\`\n` +
              `**Stop Loss:** \`${finalSl}\`\n` +
              `**Trade ID:** \`${tradeId}\`\n\n` +
              `🔗 Check it live at: https://www.oanda.com/demo-account/\n` +
              `⚠️ *Demo account only — no real money at risk.*`
            )
            .setTimestamp();

          await interaction.followUp({ embeds: [autoEmbed] });
        } catch (err) {
          console.error('[trade] OANDA auto-trade error:', err.message);
          const failEmbed = new EmbedBuilder()
            .setColor(0xff8800)
            .setTitle('❌ Auto-Trade FAILED — Not Placed')
            .setDescription(
              `The trade was **not placed** on OANDA.\n\n` +
              `**Reason:** ${err.message}\n\n` +
              `You can place this trade manually on your OANDA demo account using the signal above.`
            )
            .setTimestamp();
          await interaction.followUp({ embeds: [failEmbed] });
        }
      }

      // 🚨 EMERGENCY ALERT — 85%+ confidence BUY or SELL
      if ((aiDirection === 'BUY' || aiDirection === 'SELL') && confidence >= 85) {
        const alertEmoji = aiDirection === 'BUY' ? '🟢' : '🔴';
        const alertColor = aiDirection === 'BUY' ? 0x00ff88 : 0xff2244;
        const actionWord = aiDirection === 'BUY' ? 'BUY 📈' : 'SELL 📉';

        const alertEmbed = new EmbedBuilder()
          .setColor(alertColor)
          .setTitle(`🚨 MAJOR TRADE ALERT — ${pair}`)
          .setDescription(
            `${alertEmoji} **${actionWord}**\n` +
            `**Confidence:** ${confidence}%\n` +
            `**Timeframe:** ${timeframe}\n\n` +
            (tp1 ? `🎯 **Take Profit 1:** \`${tp1}\`\n` : '') +
            (tp2 ? `🎯 **Take Profit 2:** \`${tp2}\`\n` : '') +
            (sl  ? `🛑 **Stop Loss:** \`${sl}\`\n`       : '') +
            `\n⚠️ *Not financial advice. Always do your own research.*`
          )
          .setImage(attachment.url)
          .setFooter({ text: `AI Signal • ${new Date().toUTCString()}` })
          .setTimestamp();

        // Use saved alert channel, fall back to auto-detect, then current channel
        const savedId = getAlertChannelId(interaction.guild.id);
        const alertChannel =
          (savedId && interaction.guild.channels.cache.get(savedId)) ||
          interaction.guild.channels.cache.find(
            (ch) => ch.isTextBased() && /trade[-_]?alert|alert|signal|trading/i.test(ch.name)
          ) ||
          interaction.channel;

        await alertChannel.send({ content: '@everyone', embeds: [alertEmbed] });
      }
    }
  },
};
