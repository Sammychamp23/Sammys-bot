const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const {
  getLevel, xpForLevel, getCoins, getChallenge, getRep, getLeaderboard, getChallengeLeaderboard,
} = require('../data/store');
const fs   = require('fs');
const path = require('path');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('stats')
    .setDescription('View detailed stats')
    .addSubcommand((sub) =>
      sub.setName('me').setDescription('View your own detailed stats')
        .addUserOption((opt) => opt.setName('user').setDescription('User to check (default: you)'))
    )
    .addSubcommand((sub) => sub.setName('leaderboard').setDescription('View the XP leaderboard'))
    .addSubcommand((sub) => sub.setName('richest').setDescription('View the richest players by coins'))
    .addSubcommand((sub) => sub.setName('server').setDescription('View overall server analytics')),

  async execute(interaction) {
    const sub     = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;

    if (sub === 'me') {
      const target = interaction.options.getUser('user') ?? interaction.user;
      const userId = target.id;

      const { level, xp } = getLevel(guildId, userId);
      const needed    = xpForLevel(level + 1);
      const pct       = Math.min(100, Math.floor((xp / needed) * 100));
      const barFilled = Math.floor(pct / 5);
      const bar       = '█'.repeat(barFilled) + '░'.repeat(20 - barFilled);

      const { coins, voiceMinutes, messagesCount, dailyStreak } = getCoins(guildId, userId);
      const { wins, losses, coinsWon } = getChallenge(guildId, userId);
      const { rep } = getRep(guildId, userId);
      const totalGames = wins + losses;
      const wr = totalGames > 0 ? Math.round((wins / totalGames) * 100) : 0;

      const lb   = getLeaderboard(guildId);
      const rank = lb.findIndex((e) => e.userId === userId) + 1;

      const embed = new EmbedBuilder()
        .setColor(0x6366f1)
        .setTitle(`📊 ${target.username}'s Stats`)
        .setThumbnail(target.displayAvatarURL({ dynamic: true }))
        .addFields(
          { name: '⭐ Level & XP', value: `Level **${level}** (${pct}%)\n\`${bar}\`\n${xp.toLocaleString()} / ${needed.toLocaleString()} XP`, inline: false },
          { name: '🏅 Server Rank',   value: rank > 0 ? `**#${rank}** on leaderboard` : 'Not ranked yet', inline: true },
          { name: '💰 Coins',         value: `**${coins.toLocaleString()}**`, inline: true },
          { name: '⭐ Reputation',    value: `**${rep}** rep points`, inline: true },
          { name: '⚔️ Challenges',   value: `**${wins}W** / **${losses}L** (${wr}% WR)`, inline: true },
          { name: '💸 Coins Won',     value: `**${(coinsWon || 0).toLocaleString()}** from challenges`, inline: true },
          { name: '🎙️ VC Time',      value: `**${voiceMinutes || 0}** minutes`, inline: true },
          { name: '💬 Messages',      value: `**${(messagesCount || 0).toLocaleString()}** tracked`, inline: true },
          { name: '🔥 Daily Streak',  value: `**${dailyStreak || 0}** days`, inline: true },
        )
        .setFooter({ text: 'Stats are tracked automatically.' })
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'leaderboard') {
      const board = getLeaderboard(guildId);
      if (!board.length) {
        return interaction.reply({ content: '❌ No data yet — start chatting to earn XP!', ephemeral: true });
      }
      const medals = ['🥇', '🥈', '🥉'];
      const lines  = await Promise.all(
        board.map(async (entry, i) => {
          const user = await interaction.client.users.fetch(entry.userId).catch(() => null);
          const name = user?.username ?? 'Unknown';
          return `${medals[i] ?? `**${i + 1}.**`} **${name}** — Level ${entry.level} (${entry.xp} XP)`;
        })
      );

      const embed = new EmbedBuilder()
        .setColor(0xf59e0b)
        .setTitle('🏆 XP Leaderboard')
        .setDescription(lines.join('\n'))
        .setFooter({ text: 'Earn XP by chatting and being active in voice!' })
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'richest') {
      const econFile = path.join(__dirname, '../data/economy.json');
      const econRaw  = fs.existsSync(econFile)
        ? (() => { try { return JSON.parse(fs.readFileSync(econFile, 'utf8')); } catch { return {}; } })()
        : {};

      const entries = Object.entries(econRaw)
        .filter(([k]) => k.startsWith(guildId))
        .map(([k, v]) => ({ userId: k.split('-')[1], coins: v.coins || 0 }))
        .sort((a, b) => b.coins - a.coins)
        .slice(0, 10);

      if (!entries.length) {
        return interaction.reply({ content: '❌ No coin data yet!', ephemeral: true });
      }

      const medals = ['🥇', '🥈', '🥉'];
      const lines  = await Promise.all(
        entries.map(async (entry, i) => {
          const user = await interaction.client.users.fetch(entry.userId).catch(() => null);
          return `${medals[i] ?? `**${i + 1}.**`} **${user?.username ?? 'Unknown'}** — ${entry.coins.toLocaleString()} 💰`;
        })
      );

      const embed = new EmbedBuilder()
        .setColor(0xf59e0b)
        .setTitle('💰 Richest Players')
        .setDescription(lines.join('\n'))
        .setFooter({ text: 'Earn coins via chat, voice, quests & daily!' })
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'server') {
      await interaction.deferReply();

      const guild      = interaction.guild;
      const totalMembers = guild.memberCount;
      const bots       = guild.members.cache.filter((m) => m.user.bot).size;
      const humans     = totalMembers - bots;

      // Economy totals
      const econFile = path.join(__dirname, '../data/economy.json');
      const econRaw  = fs.existsSync(econFile)
        ? (() => { try { return JSON.parse(fs.readFileSync(econFile, 'utf8')); } catch { return {}; } })()
        : {};
      const econEntries = Object.entries(econRaw).filter(([k]) => k.startsWith(guildId));
      const totalCoins  = econEntries.reduce((s, [, v]) => s + (v.coins || 0), 0);
      const totalMsgs   = econEntries.reduce((s, [, v]) => s + (v.messagesCount || 0), 0);
      const totalVC     = econEntries.reduce((s, [, v]) => s + (v.voiceMinutes || 0), 0);
      const activePlayers = econEntries.filter(([, v]) => (v.messagesCount || 0) > 0).length;

      // Level totals
      const levelFile = path.join(__dirname, '../data/levels.json');
      const levelRaw  = fs.existsSync(levelFile)
        ? (() => { try { return JSON.parse(fs.readFileSync(levelFile, 'utf8')); } catch { return {}; } })()
        : {};
      const levelEntries = Object.entries(levelRaw).filter(([k]) => k.startsWith(guildId));
      const avgLevel = levelEntries.length
        ? Math.round(levelEntries.reduce((s, [, v]) => s + (v.level || 0), 0) / levelEntries.length * 10) / 10
        : 0;

      // Invite totals
      const inviteFile = path.join(__dirname, '../data/invites.json');
      const inviteRaw  = fs.existsSync(inviteFile)
        ? (() => { try { return JSON.parse(fs.readFileSync(inviteFile, 'utf8')); } catch { return {}; } })()
        : {};
      const totalInvites = Object.entries(inviteRaw)
        .filter(([k]) => k.startsWith(guildId))
        .reduce((s, [, v]) => s + (v.count || 0), 0);

      const embed = new EmbedBuilder()
        .setColor(0x3b82f6)
        .setTitle(`📊 ${guild.name} — Server Analytics`)
        .setThumbnail(guild.iconURL({ dynamic: true }))
        .addFields(
          { name: '👥 Members',        value: `**${totalMembers.toLocaleString()}** total\n**${humans.toLocaleString()}** humans · **${bots}** bots`, inline: true },
          { name: '🟢 Active Players', value: `**${activePlayers}** have sent messages`, inline: true },
          { name: '📲 Tracked Invites',value: `**${totalInvites}** invite${totalInvites !== 1 ? 's' : ''}`, inline: true },
          { name: '💬 Total Messages', value: `**${totalMsgs.toLocaleString()}** tracked`, inline: true },
          { name: '🎙️ Total VC Time',  value: `**${totalVC.toLocaleString()}** minutes`, inline: true },
          { name: '⭐ Avg Level',       value: `**${avgLevel}**`, inline: true },
          { name: '💰 Coins in Economy', value: `**${totalCoins.toLocaleString()}** total`, inline: true },
          { name: '📅 Server Created',  value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:R>`, inline: true },
        )
        .setFooter({ text: 'Use /stats leaderboard and /stats richest for top players.' })
        .setTimestamp();

      return interaction.editReply({ embeds: [embed] });
    }
  },
};
