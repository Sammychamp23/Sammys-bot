const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { load } = require('../data/store');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('serverstats')
    .setDescription('Admin: View detailed server statistics')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((sub) => sub.setName('overview').setDescription('Server overview & boost info'))
    .addSubcommand((sub) => sub.setName('activity').setDescription('Most active members by messages & voice'))
    .addSubcommand((sub) => sub.setName('roles').setDescription('Role distribution breakdown')),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const guild = interaction.guild;
    await interaction.deferReply({ ephemeral: true });

    if (sub === 'overview') {
      await guild.members.fetch().catch(() => {});
      const total = guild.memberCount;
      const bots = guild.members.cache.filter((m) => m.user.bot).size;
      const humans = total - bots;
      const online = guild.members.cache.filter((m) => m.presence?.status && m.presence.status !== 'offline').size;
      const boosters = guild.members.cache.filter((m) => m.premiumSince).size;
      const boostLevel = guild.premiumTier;
      const boostCount = guild.premiumSubscriptionCount ?? 0;
      const textChannels = guild.channels.cache.filter((c) => c.isTextBased() && !c.isThread()).size;
      const voiceChannels = guild.channels.cache.filter((c) => c.isVoiceBased()).size;
      const roles = guild.roles.cache.size;
      const createdAt = `<t:${Math.floor(guild.createdTimestamp / 1000)}:D>`;

      const embed = new EmbedBuilder()
        .setColor(0x6366f1)
        .setTitle(`📊 ${guild.name} — Server Stats`)
        .setThumbnail(guild.iconURL({ dynamic: true }))
        .addFields(
          { name: '👥 Members', value: `**${humans.toLocaleString()}** humans\n**${bots}** bots\n**${total.toLocaleString()}** total`, inline: true },
          { name: '🟢 Online', value: `**${online}** online`, inline: true },
          { name: '💎 Boosters', value: `**${boosters}** boosters\n**${boostCount}** boosts\n**Level ${boostLevel}**`, inline: true },
          { name: '💬 Channels', value: `**${textChannels}** text\n**${voiceChannels}** voice`, inline: true },
          { name: '🏷️ Roles', value: `**${roles}** roles`, inline: true },
          { name: '📅 Created', value: createdAt, inline: true },
        )
        .setFooter({ text: `Server ID: ${guild.id}` })
        .setTimestamp();

      return interaction.editReply({ embeds: [embed] });
    }

    if (sub === 'activity') {
      const economy = load('economy.json');
      const guildEntries = Object.entries(economy)
        .filter(([k]) => k.startsWith(guild.id))
        .map(([k, v]) => ({ userId: k.replace(`${guild.id}-`, ''), messages: v.messagesCount || 0, voice: v.voiceMinutes || 0, coins: v.coins || 0 }))
        .filter((e) => e.messages > 0 || e.voice > 0);

      const topChat = [...guildEntries].sort((a, b) => b.messages - a.messages).slice(0, 5);
      const topVoice = [...guildEntries].sort((a, b) => b.voice - a.voice).slice(0, 5);

      const chatLines = await Promise.all(topChat.map(async (e, i) => {
        const member = await guild.members.fetch(e.userId).catch(() => null);
        const name = member?.displayName ?? 'Unknown';
        return `**${i + 1}.** ${name} — **${e.messages.toLocaleString()}** messages`;
      }));

      const voiceLines = await Promise.all(topVoice.map(async (e, i) => {
        const member = await guild.members.fetch(e.userId).catch(() => null);
        const name = member?.displayName ?? 'Unknown';
        const h = Math.floor(e.voice / 60);
        const m = e.voice % 60;
        return `**${i + 1}.** ${name} — **${h}h ${m}m** in voice`;
      }));

      const embed = new EmbedBuilder()
        .setColor(0x22c55e)
        .setTitle('⚡ Member Activity')
        .addFields(
          { name: '💬 Top Chatters', value: chatLines.join('\n') || 'No data yet', inline: false },
          { name: '🎙️ Top Voice', value: voiceLines.join('\n') || 'No data yet', inline: false },
        )
        .setFooter({ text: 'Based on all-time tracked stats' })
        .setTimestamp();

      return interaction.editReply({ embeds: [embed] });
    }

    if (sub === 'roles') {
      await guild.members.fetch().catch(() => {});
      const roleCounts = guild.roles.cache
        .filter((r) => r.name !== '@everyone' && r.members.size > 0)
        .map((r) => ({ name: r.name, count: r.members.size, color: r.hexColor }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 15);

      const lines = roleCounts.map((r) => `**${r.name}** — ${r.count} member${r.count !== 1 ? 's' : ''}`);

      const embed = new EmbedBuilder()
        .setColor(0x8b5cf6)
        .setTitle('🏷️ Role Distribution')
        .setDescription(lines.join('\n') || 'No roles with members found.')
        .setFooter({ text: `Showing top ${roleCounts.length} roles by member count` })
        .setTimestamp();

      return interaction.editReply({ embeds: [embed] });
    }
  },
};
