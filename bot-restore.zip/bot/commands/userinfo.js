const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('userinfo')
    .setDescription('View information about a member')
    .addUserOption((option) =>
      option.setName('target').setDescription('The member to look up')
    ),

  async execute(interaction) {
    const target = interaction.options.getMember('target') ?? interaction.member;
    const user = target.user;

    const roles = target.roles.cache
      .filter((r) => r.id !== interaction.guild.id)
      .map((r) => r.toString())
      .join(', ') || 'None';

    const embed = new EmbedBuilder()
      .setColor(target.displayHexColor === '#000000' ? 0x6366f1 : target.displayColor)
      .setTitle(`👤 ${user.tag}`)
      .setThumbnail(user.displayAvatarURL({ dynamic: true }))
      .addFields(
        { name: 'User ID', value: user.id, inline: true },
        { name: 'Nickname', value: target.nickname ?? 'None', inline: true },
        { name: 'Bot', value: user.bot ? 'Yes' : 'No', inline: true },
        {
          name: 'Account Created',
          value: `<t:${Math.floor(user.createdTimestamp / 1000)}:F>`,
          inline: false,
        },
        {
          name: 'Joined Server',
          value: `<t:${Math.floor(target.joinedTimestamp / 1000)}:F>`,
          inline: false,
        },
        { name: `Roles (${target.roles.cache.size - 1})`, value: roles }
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
