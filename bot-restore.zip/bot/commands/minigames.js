const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getCoins, addCoins, getInventory } = require('../data/store');

const cooldowns = new Map();
function checkCooldown(userId, cmd, ms) {
  const key = `${userId}-${cmd}`;
  const last = cooldowns.get(key) || 0;
  const remaining = ms - (Date.now() - last);
  if (remaining > 0) return remaining;
  cooldowns.set(key, Date.now());
  return 0;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('minigames')
    .setDescription('Play mini-games to win coins')
    .addSubcommand((sub) =>
      sub.setName('coinflip').setDescription('Flip a coin — double or nothing')
        .addIntegerOption((opt) => opt.setName('bet').setDescription('Coins to bet').setRequired(true).setMinValue(10).setMaxValue(5000))
        .addStringOption((opt) =>
          opt.setName('side').setDescription('Heads or Tails').setRequired(true)
            .addChoices({ name: 'Heads', value: 'heads' }, { name: 'Tails', value: 'tails' })
        )
    )
    .addSubcommand((sub) =>
      sub.setName('slots').setDescription('Spin the slot machine')
        .addIntegerOption((opt) => opt.setName('bet').setDescription('Coins to bet').setRequired(true).setMinValue(10).setMaxValue(2000))
    )
    .addSubcommand((sub) =>
      sub.setName('duel').setDescription('Duel another user for coins')
        .addUserOption((opt) => opt.setName('user').setDescription('User to duel').setRequired(true))
        .addIntegerOption((opt) => opt.setName('bet').setDescription('Coins to bet').setRequired(true).setMinValue(10).setMaxValue(3000))
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;
    const userId = interaction.user.id;

    if (sub === 'coinflip') {
      const wait = checkCooldown(userId, 'coinflip', 15_000);
      if (wait) return interaction.reply({ content: `⏳ Cooldown: **${Math.ceil(wait / 1000)}s** remaining.`, ephemeral: true });

      const bet = interaction.options.getInteger('bet');
      const side = interaction.options.getString('side');
      const { coins } = getCoins(guildId, userId);
      if (coins < bet) return interaction.reply({ content: `❌ You only have **${coins}** coins.`, ephemeral: true });

      const result = Math.random() < 0.5 ? 'heads' : 'tails';
      const won = result === side;
      const change = won ? bet : -bet;
      const newBalance = addCoins(guildId, userId, change);

      const embed = new EmbedBuilder()
        .setColor(won ? 0x22c55e : 0xef4444)
        .setTitle(won ? '🪙 You Won!' : '🪙 You Lost!')
        .setDescription(`The coin landed on **${result.toUpperCase()}**!`)
        .addFields(
          { name: 'Your Pick', value: side.toUpperCase(), inline: true },
          { name: won ? 'Won' : 'Lost', value: `**${bet}** coins`, inline: true },
          { name: 'Balance', value: `**${newBalance.toLocaleString()}** coins`, inline: true },
        )
        .setTimestamp();
      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'slots') {
      const wait = checkCooldown(userId, 'slots', 20_000);
      if (wait) return interaction.reply({ content: `⏳ Cooldown: **${Math.ceil(wait / 1000)}s** remaining.`, ephemeral: true });

      const bet = interaction.options.getInteger('bet');
      const { coins } = getCoins(guildId, userId);
      if (coins < bet) return interaction.reply({ content: `❌ You only have **${coins}** coins.`, ephemeral: true });

      const inventory = getInventory(guildId, userId);
      const hasCharm = inventory.includes('🍀 Lucky Charm');
      const symbols = ['🍒', '🍋', '🔔', '⭐', '💎', '7️⃣'];
      // Lucky Charm: 15% chance to force a pair on the first two reels
      const spin = () => symbols[Math.floor(Math.random() * symbols.length)];
      let reels = [spin(), spin(), spin()];
      if (hasCharm && Math.random() < 0.15) reels[1] = reels[0];
      const display = `[ ${reels.join(' | ')} ]`;

      let multiplier = 0;
      if (reels[0] === reels[1] && reels[1] === reels[2]) {
        multiplier = reels[0] === '💎' ? 10 : reels[0] === '7️⃣' ? 7 : reels[0] === '⭐' ? 5 : 3;
      } else if (reels[0] === reels[1] || reels[1] === reels[2] || reels[0] === reels[2]) {
        multiplier = 0.5;
      }

      let change, resultText;
      if (multiplier === 0) {
        change = -bet;
        resultText = '❌ No match — better luck next time!';
      } else {
        change = Math.floor(bet * multiplier);
        resultText = multiplier >= 5 ? '🎉 JACKPOT!' : multiplier >= 3 ? '🔥 Three of a kind!' : '✅ Pair match!';
      }

      const newBalance = addCoins(guildId, userId, change);

      const embed = new EmbedBuilder()
        .setColor(multiplier > 0 ? 0xf59e0b : 0xef4444)
        .setTitle('🎰 Slot Machine')
        .setDescription(`${display}\n\n${resultText}${hasCharm ? '\n🍀 *Lucky Charm active*' : ''}`)
        .addFields(
          { name: change >= 0 ? 'Won' : 'Lost', value: `**${Math.abs(change)}** coins`, inline: true },
          { name: 'Balance', value: `**${newBalance.toLocaleString()}** coins`, inline: true },
        )
        .setTimestamp();
      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'duel') {
      const wait = checkCooldown(userId, 'duel', 60_000);
      if (wait) return interaction.reply({ content: `⏳ Cooldown: **${Math.ceil(wait / 1000)}s** remaining.`, ephemeral: true });

      const target = interaction.options.getUser('user');
      const bet = interaction.options.getInteger('bet');

      if (target.id === userId) return interaction.reply({ content: '❌ Cannot duel yourself.', ephemeral: true });
      if (target.bot) return interaction.reply({ content: '❌ Cannot duel a bot.', ephemeral: true });

      const { coins: myCoins } = getCoins(guildId, userId);
      const { coins: targetCoins } = getCoins(guildId, target.id);
      if (myCoins < bet) return interaction.reply({ content: `❌ You only have **${myCoins}** coins.`, ephemeral: true });
      if (targetCoins < bet) return interaction.reply({ content: `❌ ${target.username} only has **${targetCoins}** coins.`, ephemeral: true });

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('duel_accept').setLabel('⚔️ Accept').setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId('duel_decline').setLabel('❌ Decline').setStyle(ButtonStyle.Danger),
      );

      const embed = new EmbedBuilder()
        .setColor(0xf59e0b)
        .setTitle('⚔️ Coin Duel Request!')
        .setDescription(`${interaction.user} challenges ${target} for **${bet.toLocaleString()} coins**!\n\n${target}, do you accept?`)
        .setFooter({ text: 'Expires in 60 seconds' });

      const msg = await interaction.reply({ embeds: [embed], components: [row], fetchReply: true });
      const collector = msg.createMessageComponentCollector({ time: 60_000 });

      collector.on('collect', async (btn) => {
        if (btn.user.id !== target.id) return btn.reply({ content: '❌ Not for you.', ephemeral: true });
        collector.stop();

        if (btn.customId === 'duel_decline') {
          const decEmbed = EmbedBuilder.from(embed).setColor(0x6b7280).setTitle('❌ Duel Declined');
          return btn.update({ embeds: [decEmbed], components: [] });
        }

        const winnerId = Math.random() < 0.5 ? userId : target.id;
        const loserId = winnerId === userId ? target.id : userId;
        addCoins(guildId, winnerId, bet);
        addCoins(guildId, loserId, -bet);

        const winnerUser = winnerId === userId ? interaction.user : target;
        const resultEmbed = new EmbedBuilder()
          .setColor(0x22c55e)
          .setTitle('⚔️ Duel Result!')
          .setDescription(`🏆 **${winnerUser.username}** wins **${bet.toLocaleString()} coins**!`)
          .setTimestamp();

        return btn.update({ embeds: [resultEmbed], components: [] });
      });

      collector.on('end', (_, reason) => {
        if (reason === 'time') msg.edit({ components: [] }).catch(() => {});
      });
    }
  },
};
