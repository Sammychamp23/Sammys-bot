const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { activateChaosMode, getChaosMode } = require('../data/store');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('chaosmode')
    .setDescription('Manage Chaos Mode — temporarily boost all server rewards')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand((sub) =>
      sub.setName('start')
        .setDescription('Activate Chaos Mode with boosted rewards')
        .addIntegerOption((opt) =>
          opt.setName('duration').setDescription('Duration in minutes (default: 30)').setMinValue(5).setMaxValue(120)
        )
        .addNumberOption((opt) =>
          opt.setName('multiplier').setDescription('Reward multiplier (default: 2x)').setMinValue(1.5).setMaxValue(5)
        )
    )
    .addSubcommand((sub) =>
      sub.setName('status').setDescription('Check if Chaos Mode is currently active')
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;

    if (sub === 'status') {
      const chaos = getChaosMode(guildId);
      if (!chaos.active) {
        return interaction.reply({
          embeds: [new EmbedBuilder()
            .setColor(0x6b7280)
            .setTitle('🌪️ Chaos Mode')
            .setDescription('Chaos Mode is currently **inactive**.\n\nUse `/chaosmode start` to activate it!')
            .setTimestamp()],
        });
      }
      const remaining = Math.ceil((chaos.endsAt - Date.now()) / 60000);
      return interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor(0xef4444)
          .setTitle('🌪️ CHAOS MODE ACTIVE!')
          .setDescription(`**${chaos.multiplier}x rewards** are currently active!\n\nEnds in **${remaining} minute${remaining !== 1 ? 's' : ''}**.`)
          .setTimestamp()],
      });
    }

    if (sub === 'start') {
      const current = getChaosMode(guildId);
      if (current.active) {
        const remaining = Math.ceil((current.endsAt - Date.now()) / 60000);
        return interaction.reply({
          content: `❌ Chaos Mode is already active! Ends in **${remaining}m**.`,
          ephemeral: true,
        });
      }
      const durationMins = interaction.options.getInteger('duration') ?? 30;
      const multiplier = interaction.options.getNumber('multiplier') ?? 2;
      activateChaosMode(guildId, durationMins * 60 * 1000, multiplier);

      const embed = new EmbedBuilder()
        .setColor(0xef4444)
        .setTitle('🌪️ CHAOS MODE ACTIVATED!')
        .setDescription(`**${multiplier}x rewards** for the next **${durationMins} minutes!** 🔥\n\nAll XP and coin gains are massively boosted — get active NOW!`)
        .addFields(
          { name: '⏱️ Duration', value: `${durationMins} minutes`, inline: true },
          { name: '🔥 Multiplier', value: `${multiplier}x`, inline: true },
          { name: '📣 Activated by', value: `${interaction.user}`, inline: true },
        )
        .setFooter({ text: 'Chaos Mode boosts ALL XP and coin earnings across chat and voice!' })
        .setTimestamp();

      return interaction.reply({ content: '@everyone', embeds: [embed] });
    }
  },
};
