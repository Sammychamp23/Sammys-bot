const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getRep, addRep } = require('../data/store');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rep')
    .setDescription('Give reputation to a user or check rep')
    .addSubcommand((sub) =>
      sub.setName('give').setDescription('Give +1 rep to a user (12hr cooldown per person)')
        .addUserOption((opt) => opt.setName('user').setDescription('User to rep').setRequired(true))
    )
    .addSubcommand((sub) =>
      sub.setName('check').setDescription('Check a user\'s reputation')
        .addUserOption((opt) => opt.setName('user').setDescription('User to check'))
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;
    const userId = interaction.user.id;

    if (sub === 'give') {
      const target = interaction.options.getUser('user');
      if (target.id === userId) return interaction.reply({ content: '❌ You cannot rep yourself.', ephemeral: true });
      if (target.bot) return interaction.reply({ content: '❌ You cannot rep a bot.', ephemeral: true });

      const result = addRep(guildId, userId, target.id);

      if (!result.success) {
        const hours = Math.floor(result.remaining / 3600000);
        const mins = Math.floor((result.remaining % 3600000) / 60000);
        return interaction.reply({
          content: `⏳ You already repped **${target.username}** recently. Try again in **${hours}h ${mins}m**.`,
          ephemeral: true,
        });
      }

      const embed = new EmbedBuilder()
        .setColor(0xf59e0b)
        .setTitle('⭐ Reputation Given!')
        .setDescription(`You gave +1 rep to **${target.username}**! They now have **${result.newRep} ⭐ rep**.`)
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'check') {
      const target = interaction.options.getUser('user') ?? interaction.user;
      const { rep } = getRep(guildId, target.id);

      const embed = new EmbedBuilder()
        .setColor(0xf59e0b)
        .setTitle(`⭐ ${target.username}'s Reputation`)
        .setThumbnail(target.displayAvatarURL())
        .setDescription(`**${rep} ⭐** reputation points`)
        .setFooter({ text: 'Earn rep by being helpful and positive!' })
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }
  },
};
