const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

const dataFile = path.join(__dirname, '..', 'reactionRoles.json');

function loadData() {
  if (!fs.existsSync(dataFile)) return {};
  try { return JSON.parse(fs.readFileSync(dataFile, 'utf8')); } catch { return {}; }
}

function saveData(data) {
  fs.writeFileSync(dataFile, JSON.stringify(data, null, 2));
}

const GAME_ROLES = {
  '🔫': '🔫 Fortnite',
  '⚡': '⚡ Valorant',
  '⛏️': '🔲 Minecraft',
  '💣': '💣 Call of Duty',
  '🦅': '🏃 Apex Legends',
  '🚗': '🌍 GTA V',
  '🎲': '🔵 Roblox',
  '🗡️': '🗡️ League of Legends',
  '☠️': '💀 Warzone',
  '🎯': '🎯 Overwatch 2',
  '🚀': '⚽ Rocket League',
  '🕷️': '🕷️ Dead by Daylight',
};

const PLATFORM_ROLES = {
  '🖥️': '🖥️ PC',
  '🕹️': '🎮 PlayStation',
  '🟢': '🟢 Xbox',
  '📱': '📱 Mobile',
  '🔴': '🔴 Nintendo Switch',
};

const PING_ROLES = {
  '📣': '📣 Announcements',
  '🎉': '🎉 Giveaways',
  '🌙': '🎮 Game Night',
  '📺': '📺 Stream Pings',
  '🔔': '🔔 Event Pings',
};

const PATH_ROLES = {
  '🟩': '🎮 Casual',
  '⚔️': '⚔️ Competitive',
  '🎬': '🎬 Content Creator',
  '💹': '💹 Trader',
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName('reactionroles')
    .setDescription('Post the reaction roles message in the roles channel')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  GAME_ROLES,
  PLATFORM_ROLES,
  PING_ROLES,
  PATH_ROLES,
  loadData,
  saveData,

  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });

    const channel =
      interaction.guild.channels.cache.find((c) => c.name === '🗺️roles' && c.isTextBased()) ??
      interaction.guild.channels.cache.find((c) => c.name === 'roles' && c.isTextBased()) ??
      interaction.channel;

    // Path roles embed
    const pathEmbed = new EmbedBuilder()
      .setColor(0x6366f1)
      .setTitle('🛤️ Player Path')
      .setDescription(
        'React to choose your player identity!\n\n' +
        Object.entries(PATH_ROLES)
          .map(([emoji, role]) => `${emoji} — **${role}**`)
          .join('\n') +
        '\n\n> 💡 Use `/path choose` for the full system with perks & cooldowns.'
      );

    // Game roles embed
    const gameEmbed = new EmbedBuilder()
      .setColor(0xa855f7)
      .setTitle('🎮 Game Roles')
      .setDescription(
        'React to get the game roles you play!\n\n' +
        Object.entries(GAME_ROLES)
          .map(([emoji, role]) => `${emoji} — **${role.replace(/^\S+\s/, '')}**`)
          .join('\n')
      );

    // Platform roles embed
    const platformEmbed = new EmbedBuilder()
      .setColor(0x3b82f6)
      .setTitle('🖥️ Platform Roles')
      .setDescription(
        'React to show what platform you game on!\n\n' +
        Object.entries(PLATFORM_ROLES)
          .map(([emoji, role]) => `${emoji} — **${role.replace(/^\S+\s/, '')}**`)
          .join('\n')
      );

    // Ping roles embed
    const pingEmbed = new EmbedBuilder()
      .setColor(0xf59e0b)
      .setTitle('🔔 Notification Roles')
      .setDescription(
        'React to get notified for events!\n\n' +
        Object.entries(PING_ROLES)
          .map(([emoji, role]) => `${emoji} — **${role.replace(/^\S+\s/, '')}**`)
          .join('\n')
      )
      .setFooter({ text: 'React to get a role — remove your reaction to lose it!' });

    // Send all embeds
    const pathMsg     = await channel.send({ embeds: [pathEmbed] });
    const gameMsg     = await channel.send({ embeds: [gameEmbed] });
    const platformMsg = await channel.send({ embeds: [platformEmbed] });
    const pingMsg     = await channel.send({ embeds: [pingEmbed] });

    // Add reactions
    for (const emoji of Object.keys(PATH_ROLES))     await pathMsg.react(emoji).catch(() => {});
    for (const emoji of Object.keys(GAME_ROLES))     await gameMsg.react(emoji).catch(() => {});
    for (const emoji of Object.keys(PLATFORM_ROLES)) await platformMsg.react(emoji).catch(() => {});
    for (const emoji of Object.keys(PING_ROLES))     await pingMsg.react(emoji).catch(() => {});

    // Save message IDs so bot remembers them after restart
    const data = loadData();
    data[pathMsg.id]     = PATH_ROLES;
    data[gameMsg.id]     = GAME_ROLES;
    data[platformMsg.id] = PLATFORM_ROLES;
    data[pingMsg.id]     = PING_ROLES;
    saveData(data);

    await interaction.editReply({ content: `✅ Reaction roles posted in ${channel}!` });
  },
};
