const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { createAuction, getAuctions, placeBid, endAuction, getCoins } = require('../data/store');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('auction')
    .setDescription('Auction house — bid on items with coins')
    .addSubcommand((sub) =>
      sub.setName('create').setDescription('Create a new auction')
        .addStringOption((opt) => opt.setName('item').setDescription('Item name to auction').setRequired(true))
        .addIntegerOption((opt) => opt.setName('starting_price').setDescription('Starting bid in coins').setRequired(true).setMinValue(50))
        .addIntegerOption((opt) => opt.setName('hours').setDescription('Duration in hours (1–48)').setRequired(true).setMinValue(1).setMaxValue(48))
    )
    .addSubcommand((sub) =>
      sub.setName('bid').setDescription('Place a bid on an auction')
        .addStringOption((opt) => opt.setName('id').setDescription('Auction ID (from /auction view)').setRequired(true))
        .addIntegerOption((opt) => opt.setName('amount').setDescription('Your bid in coins').setRequired(true).setMinValue(1))
    )
    .addSubcommand((sub) => sub.setName('view').setDescription('Browse active auctions'))
    .addSubcommand((sub) => sub.setName('mine').setDescription('View auctions you created')),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;
    const userId = interaction.user.id;

    if (sub === 'create') {
      const item = interaction.options.getString('item');
      const startingPrice = interaction.options.getInteger('starting_price');
      const hours = interaction.options.getInteger('hours');
      const endsAt = Date.now() + hours * 3600000;

      const id = createAuction(guildId, userId, item, startingPrice, endsAt);

      const embed = new EmbedBuilder()
        .setColor(0xf59e0b)
        .setTitle('🔨 Auction Created!')
        .addFields(
          { name: 'Item', value: item, inline: true },
          { name: 'Starting Bid', value: `${startingPrice.toLocaleString()} 💰`, inline: true },
          { name: 'Ends', value: `<t:${Math.floor(endsAt / 1000)}:R>`, inline: true },
          { name: 'Auction ID', value: `\`${id.slice(-8)}\``, inline: true },
        )
        .setFooter({ text: 'Others can bid using /auction bid' })
        .setTimestamp();
      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'view') {
      const auctions = getAuctions(guildId).filter((a) => !a.ended && a.endsAt > Date.now());
      if (auctions.length === 0) {
        return interaction.reply({ content: '🔨 No active auctions! Create one with `/auction create`.', flags: 64 });
      }

      const lines = await Promise.all(auctions.slice(0, 10).map(async (a) => {
        const seller = await interaction.client.users.fetch(a.sellerId).catch(() => null);
        const topBidder = a.topBidderId ? await interaction.client.users.fetch(a.topBidderId).catch(() => null) : null;
        return `\`${a.id.slice(-8)}\` **${a.item}**\nSeller: ${seller?.username ?? '?'} | Current: **${a.currentBid.toLocaleString()} 💰** ${topBidder ? `(${topBidder.username})` : '(no bids)'}\nEnds: <t:${Math.floor(a.endsAt / 1000)}:R>`;
      }));

      const embed = new EmbedBuilder()
        .setColor(0xf59e0b)
        .setTitle('🔨 Active Auctions')
        .setDescription(lines.join('\n\n'))
        .setFooter({ text: 'Use /auction bid [id] [amount] to place a bid' })
        .setTimestamp();
      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'bid') {
      const shortId = interaction.options.getString('id');
      const amount = interaction.options.getInteger('amount');
      const auctions = getAuctions(guildId);
      const auction = auctions.find((a) => a.id.endsWith(shortId) || a.id === shortId);

      if (!auction) return interaction.reply({ content: '❌ Auction not found.', flags: 64 });
      if (auction.ended || auction.endsAt <= Date.now()) return interaction.reply({ content: '❌ This auction has ended.', flags: 64 });
      if (auction.sellerId === userId) return interaction.reply({ content: '❌ You cannot bid on your own auction.', flags: 64 });

      const { coins } = getCoins(guildId, userId);
      const minBid = auction.currentBid + Math.max(10, Math.floor(auction.currentBid * 0.05));

      if (amount < minBid) return interaction.reply({ content: `❌ Minimum bid is **${minBid.toLocaleString()}** 💰 (5% increment).`, flags: 64 });
      if (coins < amount) return interaction.reply({ content: `❌ You only have **${coins.toLocaleString()}** 💰.`, flags: 64 });

      const result = placeBid(guildId, userId, auction.id, amount);
      if (!result.success) return interaction.reply({ content: `❌ ${result.reason}`, flags: 64 });

      const embed = new EmbedBuilder()
        .setColor(0x22c55e)
        .setTitle('🔨 Bid Placed!')
        .addFields(
          { name: 'Item', value: auction.item, inline: true },
          { name: 'Your Bid', value: `${amount.toLocaleString()} 💰`, inline: true },
          { name: 'Ends', value: `<t:${Math.floor(auction.endsAt / 1000)}:R>`, inline: true },
        )
        .setFooter({ text: 'You will be notified if outbid. Coins held until auction ends.' })
        .setTimestamp();
      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'mine') {
      const auctions = getAuctions(guildId).filter((a) => a.sellerId === userId);
      if (auctions.length === 0) return interaction.reply({ content: '🔨 You have no auctions.', flags: 64 });
      const lines = auctions.map((a) =>
        `\`${a.id.slice(-8)}\` **${a.item}** — **${a.currentBid.toLocaleString()} 💰** ${a.ended ? '(ended)' : `ends <t:${Math.floor(a.endsAt / 1000)}:R>`}`
      );
      const embed = new EmbedBuilder()
        .setColor(0x6366f1)
        .setTitle('🔨 Your Auctions')
        .setDescription(lines.join('\n'))
        .setTimestamp();
      return interaction.reply({ embeds: [embed], flags: 64 });
    }
  },
};
