const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Warn a member')
    .addUserOption((option) =>
      option.setName('target').setDescription('The member to warn').setRequired(true)
    )
    .addStringOption((option) =>
      option.setName('reason').setDescription('Reason for the warning').setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction, client) {
    const target = interaction.options.getMember('target');
    const reason = interaction.options.getString('reason');

    if (!target) return interaction.reply({ content: '❌ Member not found.', ephemeral: true });
    if (target.id === interaction.user.id)
      return interaction.reply({ content: '❌ You cannot warn yourself.', ephemeral: true });

    const guildId = interaction.guild.id;
    const key = `${guildId}-${target.id}`;

    if (!client.warnings.has(key)) client.warnings.set(key, []);
    const warnings = client.warnings.get(key);
    warnings.push({ reason, moderator: interaction.user.tag, timestamp: new Date().toISOString() });

    const embed = new EmbedBuilder()
      .setColor(0xfbbf24)
      .setTitle('⚠️ Member Warned')
      .addFields(
        { name: 'Member', value: `${target.user.tag} (${target.id})` },
        { name: 'Moderator', value: interaction.user.tag },
        { name: 'Reason', value: reason },
        { name: 'Total Warnings', value: `${warnings.length}` }
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });

    try {
      await target.send(
        `⚠️ You have been warned in **${interaction.guild.name}**.\n**Reason:** ${reason}\n**Total warnings:** ${warnings.length}`
      );
    } catch {
    }
  },
};
