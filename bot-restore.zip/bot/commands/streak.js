const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getActivityStreak } = require('../data/store');

const MILESTONES = [
  { days: 3,  coins: 300,  xp: 100, label: '🔥 3-Day Streak' },
  { days: 7,  coins: 700,  xp: 250, label: '⚡ 7-Day Streak' },
  { days: 14, coins: 1500, xp: 500, label: '💫 14-Day Streak' },
  { days: 30, coins: 5000, xp: 1000, label: '👑 30-Day Streak' },
];

function getMultiplier(streak) {
  if (streak >= 30) return 3.0;
  if (streak >= 14) return 2.5;
  if (streak >= 7)  return 2.0;
  if (streak >= 3)  return 1.5;
  return 1.0;
}

function streakBar(streak) {
  const max = 30;
  const filled = Math.min(streak, max);
  const blocks = 20;
  const filledBlocks = Math.round((filled / max) * blocks);
  return '█'.repeat(filledBlocks) + '░'.repeat(blocks - filledBlocks) + ` ${streak}/30`;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('streak')
    .setDescription('View your activity streak and multiplier'),

  MILESTONES,
  getMultiplier,

  async execute(interaction) {
    const guildId = interaction.guild.id;
    const userId = interaction.user.id;
    const streak = getActivityStreak(guildId, userId);

    const multiplier = getMultiplier(streak.current);
    const nextMilestone = MILESTONES.find((m) => m.days > streak.current);
    const lastActive = streak.lastActiveDate
      ? `<t:${Math.floor(streak.lastActive / 1000)}:R>`
      : 'Never';

    const embed = new EmbedBuilder()
      .setColor(streak.current >= 7 ? 0xf59e0b : streak.current >= 3 ? 0xf97316 : 0x6366f1)
      .setTitle(`🔥 ${interaction.user.username}'s Streak`)
      .setDescription(`**${streak.current}-day streak!**\n${streakBar(streak.current)}`)
      .addFields(
        { name: '💰 Reward Multiplier', value: `**${multiplier}x** on XP & coins`, inline: true },
        { name: '📅 Last Active', value: lastActive, inline: true },
        { name: '🎯 Next Milestone', value: nextMilestone
          ? `Day **${nextMilestone.days}** — +${nextMilestone.coins} coins, +${nextMilestone.xp} XP`
          : '👑 Max milestone reached!', inline: false },
        { name: '🏆 Milestones', value: MILESTONES.map((m) =>
          `${streak.current >= m.days ? '✅' : '⬜'} **${m.label}** — ${m.coins} 💰 + ${m.xp} XP`
        ).join('\n'), inline: false },
      )
      .setFooter({ text: 'Stay active daily to keep your streak! Missing a day resets it.' })
      .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
      .setTimestamp();

    return interaction.reply({ embeds: [embed] });
  },
};
