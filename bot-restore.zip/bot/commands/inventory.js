const { SlashCommandBuilder, EmbedBuilder, ChannelType, PermissionsBitField } = require('discord.js');
const { getInventory, removeFromInventory, addCoins, activateXpBoost, getXpBoostExpiry } = require('../data/store');

const USABLE_ITEMS = {
  '⚡ XP Boost Token': { desc: 'Doubles your XP gain for 1 hour. Use `/inventory activate` to turn it on.', canUse: true },
  '🍀 Lucky Charm':    { desc: 'Passively increases your slot machine odds while in your inventory.', canUse: false },
  '🎨 Custom Name Color': { desc: 'DM a mod to request your custom role color.', canUse: false },
  '🔊 Private VC Unlock': { desc: 'Creates a private voice channel for you for 24 hours. Use `/inventory activate` to claim.', canUse: true },
};

const SELL_PRICES = {
  '⚡ XP Boost Token': 400,
  '🍀 Lucky Charm': 150,
  '🎨 Custom Name Color': 750,
  '🔊 Private VC Unlock': 1250,
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName('inventory')
    .setDescription('View and manage your inventory')
    .addSubcommand((sub) => sub.setName('view').setDescription('View your inventory'))
    .addSubcommand((sub) =>
      sub.setName('activate').setDescription('Activate a usable item')
        .addStringOption((opt) =>
          opt.setName('item').setDescription('Item to activate').setRequired(true)
            .addChoices(
              { name: '⚡ XP Boost Token — doubles XP for 1 hour', value: 'xpboost' },
              { name: '🔊 Private VC Unlock — creates a private VC for 24h', value: 'vcunlock' },
            )
        )
    )
    .addSubcommand((sub) =>
      sub.setName('sell').setDescription('Sell an item for coins')
        .addStringOption((opt) => opt.setName('item').setDescription('Item name to sell').setRequired(true))
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;
    const userId = interaction.user.id;

    if (sub === 'view') {
      const inventory = getInventory(guildId, userId);

      if (!inventory.length) {
        return interaction.reply({
          embeds: [
            new EmbedBuilder()
              .setColor(0x6366f1)
              .setTitle('🎒 Your Inventory')
              .setDescription('Your inventory is empty!\n\nBuy items from `/shop browse` or earn them from mystery drops and quests.')
              .setTimestamp(),
          ],
        });
      }

      const counts = {};
      for (const item of inventory) counts[item] = (counts[item] || 0) + 1;

      const boostExpiry = getXpBoostExpiry(guildId, userId);
      const boostActive = boostExpiry && Date.now() < boostExpiry;

      const itemLines = Object.entries(counts).map(([item, qty]) => {
        const info = USABLE_ITEMS[item];
        const sellPrice = SELL_PRICES[item];
        const qtyStr = qty > 1 ? ` x${qty}` : '';
        const sellStr = sellPrice ? ` | Sell: ${sellPrice} 💰` : '';
        let extra = '';
        if (item === '⚡ XP Boost Token' && boostActive) {
          const mins = Math.ceil((boostExpiry - Date.now()) / 60000);
          extra = `\n> ⚡ *Boost active — ${mins} min remaining*`;
        }
        return `**${item}${qtyStr}**\n${info ? info.desc : 'Special item.'}${sellStr}${extra}`;
      });

      const embed = new EmbedBuilder()
        .setColor(0x6366f1)
        .setTitle('🎒 Your Inventory')
        .setDescription(itemLines.join('\n\n') || 'Empty')
        .addFields({ name: '💡 Tips', value: 'Use `/inventory activate` to use items · `/inventory sell` to sell for coins.' })
        .setFooter({ text: `${inventory.length} item(s) total` })
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'activate') {
      const choice = interaction.options.getString('item');
      await interaction.deferReply({ ephemeral: true });

      if (choice === 'xpboost') {
        const inventory = getInventory(guildId, userId);
        if (!inventory.includes('⚡ XP Boost Token')) {
          return interaction.editReply({ content: '❌ You don\'t have an **⚡ XP Boost Token** in your inventory.' });
        }
        const existing = getXpBoostExpiry(guildId, userId);
        if (existing && Date.now() < existing) {
          const mins = Math.ceil((existing - Date.now()) / 60000);
          return interaction.editReply({ content: `⚡ You already have an active boost with **${mins} min** remaining!` });
        }
        removeFromInventory(guildId, userId, '⚡ XP Boost Token');
        activateXpBoost(guildId, userId);
        const embed = new EmbedBuilder()
          .setColor(0xf59e0b)
          .setTitle('⚡ XP Boost Activated!')
          .setDescription('Your XP gain is now **doubled** for the next **1 hour**!\n\nChat, react, and earn — every message gives 2× XP until the boost expires.')
          .setTimestamp();
        return interaction.editReply({ embeds: [embed] });
      }

      if (choice === 'vcunlock') {
        const inventory = getInventory(guildId, userId);
        if (!inventory.includes('🔊 Private VC Unlock')) {
          return interaction.editReply({ content: '❌ You don\'t have a **🔊 Private VC Unlock** in your inventory.' });
        }

        try {
          const guild = interaction.guild;
          const member = interaction.member;

          const channel = await guild.channels.create({
            name: `🔒 ${member.displayName}'s VC`,
            type: ChannelType.GuildVoice,
            permissionOverwrites: [
              { id: guild.roles.everyone, deny: [PermissionsBitField.Flags.ViewChannel] },
              { id: userId, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak, PermissionsBitField.Flags.MoveMembers] },
            ],
          });

          removeFromInventory(guildId, userId, '🔊 Private VC Unlock');

          // Delete after 24 hours
          setTimeout(() => channel.delete().catch(() => {}), 24 * 60 * 60 * 1000);

          const embed = new EmbedBuilder()
            .setColor(0x22c55e)
            .setTitle('🔊 Private VC Created!')
            .setDescription(`Your private voice channel **${channel.name}** is ready!\n\nIt will be automatically deleted in **24 hours**.`)
            .setTimestamp();
          return interaction.editReply({ embeds: [embed] });
        } catch (err) {
          console.error('[Inventory] VC create error:', err.message);
          return interaction.editReply({ content: '❌ Could not create the voice channel. Make sure the bot has **Manage Channels** permission.' });
        }
      }
    }

    if (sub === 'sell') {
      const itemName = interaction.options.getString('item');
      const inventory = getInventory(guildId, userId);

      const found = inventory.find((i) => i.toLowerCase() === itemName.toLowerCase() || i === itemName);
      if (!found) {
        return interaction.reply({ content: `❌ You don't have **${itemName}** in your inventory.`, ephemeral: true });
      }

      const sellPrice = SELL_PRICES[found];
      if (!sellPrice) {
        return interaction.reply({ content: `❌ **${found}** cannot be sold.`, ephemeral: true });
      }

      removeFromInventory(guildId, userId, found);
      const newBalance = addCoins(guildId, userId, sellPrice);

      const embed = new EmbedBuilder()
        .setColor(0x22c55e)
        .setTitle('💸 Item Sold!')
        .addFields(
          { name: 'Item', value: found, inline: true },
          { name: 'Sold For', value: `**${sellPrice.toLocaleString()}** 💰`, inline: true },
          { name: 'New Balance', value: `**${newBalance.toLocaleString()}** coins`, inline: true },
        )
        .setTimestamp();
      return interaction.reply({ embeds: [embed] });
    }
  },
};
