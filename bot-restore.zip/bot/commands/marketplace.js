const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { listItem, getListings, buyListing, removeListing, getInventory, getCoins } = require('../data/store');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('market')
    .setDescription('Player marketplace — buy and sell items')
    .addSubcommand((sub) =>
      sub.setName('list').setDescription('List an item for sale')
        .addStringOption((opt) => opt.setName('item').setDescription('Item name to sell').setRequired(true))
        .addIntegerOption((opt) => opt.setName('price').setDescription('Price in coins').setRequired(true).setMinValue(1).setMaxValue(100000))
    )
    .addSubcommand((sub) =>
      sub.setName('browse').setDescription('Browse all active listings')
    )
    .addSubcommand((sub) =>
      sub.setName('buy').setDescription('Buy a listing by ID')
        .addStringOption((opt) => opt.setName('id').setDescription('Listing ID').setRequired(true))
    )
    .addSubcommand((sub) =>
      sub.setName('remove').setDescription('Remove your own listing')
        .addStringOption((opt) => opt.setName('id').setDescription('Listing ID').setRequired(true))
    )
    .addSubcommand((sub) => sub.setName('inventory').setDescription('View your inventory')),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;
    const userId = interaction.user.id;

    if (sub === 'list') {
      const item = interaction.options.getString('item');
      const price = interaction.options.getInteger('price');
      const inventory = getInventory(guildId, userId);
      if (!inventory.includes(item)) {
        return interaction.reply({ content: `❌ You don't have **${item}** in your inventory.`, ephemeral: true });
      }
      const id = listItem(guildId, userId, item, price);
      const embed = new EmbedBuilder()
        .setColor(0x22c55e)
        .setTitle('🏪 Listed!')
        .setDescription(`**${item}** listed for **${price.toLocaleString()} coins**.\nListing ID: \`${id}\``)
        .setTimestamp();
      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'browse') {
      const listings = getListings(guildId);
      if (listings.length === 0) {
        return interaction.reply({ content: '🏪 The marketplace is empty! Use `/market list` to sell something.', ephemeral: true });
      }

      const lines = await Promise.all(
        listings.slice(0, 15).map(async (l) => {
          const seller = await interaction.client.users.fetch(l.sellerId).catch(() => null);
          return `\`${l.id.slice(-6)}\` **${l.item}** — **${l.price.toLocaleString()} 💰** by ${seller?.username ?? 'Unknown'}`;
        })
      );

      const embed = new EmbedBuilder()
        .setColor(0xf59e0b)
        .setTitle('🏪 Marketplace')
        .setDescription(lines.join('\n'))
        .setFooter({ text: `${listings.length} listing(s) • Use the full ID with /market buy` })
        .setTimestamp();
      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'buy') {
      const listings = getListings(guildId);
      const shortId = interaction.options.getString('id');
      const listing = listings.find((l) => l.id.endsWith(shortId) || l.id === shortId);
      if (!listing) return interaction.reply({ content: '❌ Listing not found.', ephemeral: true });

      const result = buyListing(guildId, userId, listing.id);
      if (!result.success) return interaction.reply({ content: `❌ ${result.reason}`, ephemeral: true });

      const seller = await interaction.client.users.fetch(result.listing.sellerId).catch(() => null);
      const embed = new EmbedBuilder()
        .setColor(0x22c55e)
        .setTitle('✅ Purchase Complete!')
        .addFields(
          { name: 'Item', value: result.listing.item, inline: true },
          { name: 'Paid', value: `${result.listing.price.toLocaleString()} coins`, inline: true },
          { name: 'Seller', value: seller?.username ?? 'Unknown', inline: true },
        )
        .setTimestamp();
      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'remove') {
      const shortId = interaction.options.getString('id');
      const listings = getListings(guildId);
      const listing = listings.find((l) => l.id.endsWith(shortId) || l.id === shortId);
      if (!listing) return interaction.reply({ content: '❌ Listing not found.', ephemeral: true });

      const result = removeListing(guildId, userId, listing.id);
      if (!result.success) return interaction.reply({ content: `❌ ${result.reason}`, ephemeral: true });
      return interaction.reply({ content: `✅ Listing removed.`, ephemeral: true });
    }

    if (sub === 'inventory') {
      const inventory = getInventory(guildId, userId);
      const embed = new EmbedBuilder()
        .setColor(0x6366f1)
        .setTitle(`🎒 ${interaction.user.username}'s Inventory`)
        .setDescription(inventory.length > 0 ? inventory.map((item) => `• ${item}`).join('\n') : 'Your inventory is empty.')
        .setFooter({ text: 'Buy items from the shop or marketplace' })
        .setTimestamp();
      return interaction.reply({ embeds: [embed] });
    }
  },
};
