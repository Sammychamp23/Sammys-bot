const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getSessionStats, getSessionLeaderboard } = require('../data/store');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('session')
    .setDescription('Gaming session commands')
    .addSubcommand((sub) =>
      sub
        .setName('create')
        .setDescription('Manually create a gaming session')
        .addStringOption((opt) =>
          opt.setName('game').setDescription('Game name').setRequired(true)
        )
        .addStringOption((opt) =>
          opt
            .setName('mode')
            .setDescription('Game mode (e.g. Ranked, Chill, Squads)')
            .setRequired(true)
        )
        .addIntegerOption((opt) =>
          opt
            .setName('players_needed')
            .setDescription('Max number of players (2–20)')
            .setMinValue(2)
            .setMaxValue(20)
            .setRequired(true)
        )
        .addIntegerOption((opt) =>
          opt
            .setName('countdown')
            .setDescription('Countdown in minutes before session starts (1–30, default 10)')
            .setMinValue(1)
            .setMaxValue(30)
            .setRequired(false)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName('stats')
        .setDescription('View your session stats or the server leaderboard')
        .addUserOption((opt) =>
          opt.setName('user').setDescription('User to check (default: yourself)').setRequired(false)
        )
    ),

  async execute(interaction, client) {
    const sub = interaction.options.getSubcommand();

    if (sub === 'create') {
      const game = interaction.options.getString('game');
      const mode = interaction.options.getString('mode');
      const maxPlayers = interaction.options.getInteger('players_needed');
      const countdownMins = interaction.options.getInteger('countdown') ?? 10;

      if (!client.createAndRunSession) {
        return interaction.reply({ content: '❌ Session system is not ready yet.', ephemeral: true });
      }

      await interaction.reply({ content: `✅ Creating **${game}** session...`, ephemeral: true });

      const channel = interaction.channel;
      await client.createAndRunSession(interaction.guild, channel, {
        game,
        mode,
        maxPlayers,
        countdownMins,
        host: interaction.user.id,
      });
      return;
    }

    if (sub === 'stats') {
      const targetUser = interaction.options.getUser('user') ?? interaction.user;
      const stats = getSessionStats(interaction.guild.id, targetUser.id);
      const leaderboard = getSessionLeaderboard(interaction.guild.id);

      const lbLines = [];
      for (let i = 0; i < leaderboard.length; i++) {
        const e = leaderboard[i];
        const member = await interaction.guild.members.fetch(e.userId).catch(() => null);
        const name = member ? member.user.username : 'Unknown';
        const medal = ['🥇', '🥈', '🥉'][i] || `**${i + 1}.**`;
        lbLines.push(`${medal} ${name} — ${e.completed} completed · ${e.joined} joined`);
      }

      const embed = new EmbedBuilder()
        .setColor(0x6366f1)
        .setTitle(`🎮 Session Stats — ${targetUser.username}`)
        .addFields(
          { name: '🎯 Sessions Joined', value: `${stats.joined}`, inline: true },
          { name: '✅ Sessions Completed', value: `${stats.completed}`, inline: true },
          {
            name: '🏆 Server Leaderboard',
            value: lbLines.length > 0 ? lbLines.join('\n') : 'No sessions completed yet.',
            inline: false,
          }
        )
        .setFooter({ text: 'Join sessions to climb the leaderboard!' })
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }
  },
};
