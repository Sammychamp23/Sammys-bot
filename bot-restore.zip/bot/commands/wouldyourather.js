const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

const questions = [
  ['Have unlimited lives in any game', 'Have unlimited in-game currency in any game'],
  ['Play every game for free', 'Always win every multiplayer match'],
  ['Be a pro at FPS games', 'Be a pro at strategy games'],
  ['Have a gaming PC worth $10,000', 'Have every console ever made'],
  ['Play your favourite game with your favourite streamer', 'Get paid to test unreleased games'],
  ['Never experience lag again', 'Always find a full lobby instantly'],
  ['Have a photographic memory for game maps', 'Have perfect aim in every shooter'],
  ['Be stuck in a game you hate with great teammates', 'Play a game you love with toxic teammates'],
  ['Stream to 1 million viewers once', 'Stream to 1,000 loyal viewers daily'],
  ['Always win but never enjoy the game', 'Always lose but have a blast playing'],
  ['Have your game deleted with no backup', 'Lose all your in-game friends forever'],
  ['Respawn instantly but at the wrong location', 'Respawn in the right spot but after 30 seconds'],
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('wouldyourather')
    .setDescription('Get a random Would You Rather question for the server'),

  async execute(interaction) {
    const [optionA, optionB] = questions[Math.floor(Math.random() * questions.length)];

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('wyr_a').setLabel('🅰️ Option A').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('wyr_b').setLabel('🅱️ Option B').setStyle(ButtonStyle.Danger)
    );

    const embed = new EmbedBuilder()
      .setColor(0x6366f1)
      .setTitle('🤔 Would You Rather...')
      .addFields(
        { name: '🅰️ Option A', value: optionA, inline: true },
        { name: '🅱️ Option B', value: optionB, inline: true }
      )
      .setFooter({ text: 'Vote using the buttons below!' })
      .setTimestamp();

    const message = await interaction.reply({ embeds: [embed], components: [row], fetchReply: true });

    const votes = { a: new Set(), b: new Set() };

    const collector = message.createMessageComponentCollector({ time: 60_000 });

    collector.on('collect', async (btn) => {
      const userId = btn.user.id;
      if (btn.customId === 'wyr_a') {
        votes.a.add(userId);
        votes.b.delete(userId);
      } else {
        votes.b.add(userId);
        votes.a.delete(userId);
      }

      const updatedEmbed = EmbedBuilder.from(embed).setFields(
        { name: `🅰️ Option A — ${votes.a.size} vote(s)`, value: optionA, inline: true },
        { name: `🅱️ Option B — ${votes.b.size} vote(s)`, value: optionB, inline: true }
      );

      await btn.update({ embeds: [updatedEmbed], components: [row] });
    });

    collector.on('end', async () => {
      const winner =
        votes.a.size > votes.b.size
          ? `🅰️ Option A wins with ${votes.a.size} vote(s)!`
          : votes.b.size > votes.a.size
          ? `🅱️ Option B wins with ${votes.b.size} vote(s)!`
          : "It's a tie!";

      const finalEmbed = EmbedBuilder.from(embed)
        .setFields(
          { name: `🅰️ Option A — ${votes.a.size} vote(s)`, value: optionA, inline: true },
          { name: `🅱️ Option B — ${votes.b.size} vote(s)`, value: optionB, inline: true }
        )
        .setFooter({ text: `Voting closed — ${winner}` });

      const disabledRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('wyr_a').setLabel('🅰️ Option A').setStyle(ButtonStyle.Primary).setDisabled(true),
        new ButtonBuilder().setCustomId('wyr_b').setLabel('🅱️ Option B').setStyle(ButtonStyle.Danger).setDisabled(true)
      );

      await message.edit({ embeds: [finalEmbed], components: [disabledRow] });
    });
  },
};
