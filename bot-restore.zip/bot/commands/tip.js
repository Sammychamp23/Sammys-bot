const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

const tips = [
  { game: 'General', tip: 'Always warm up before ranked matches — even 10 minutes makes a big difference.' },
  { game: 'General', tip: 'Take breaks every hour. Fatigue is one of the biggest killers of performance.' },
  { game: 'General', tip: 'Watch your own replays. You learn more from your mistakes than your wins.' },
  { game: 'General', tip: 'Mute toxic teammates. A focused mind plays better than an angry one.' },
  { game: 'General', tip: 'Communication wins games. Even simple callouts can turn a match around.' },
  { game: 'Valorant', tip: 'Always buy utility before a deagle. Information wins rounds, not a flashy gun.' },
  { game: 'Valorant', tip: 'Learn one agent deeply before trying others — mastery beats variety at low ranks.' },
  { game: 'Valorant', tip: "Don't peek when you're on low health — trade kills are free wins for the enemy." },
  { game: 'Fortnite', tip: 'Land at smaller named POIs early on to get loot without 10 people fighting you.' },
  { game: 'Fortnite', tip: 'Always build a 1x1 after a fight. Healing in the open is asking to be third-partied.' },
  { game: 'Minecraft', tip: 'Always carry a water bucket in the nether — it saves you from lava falls.' },
  { game: 'Minecraft', tip: 'Torches placed on the left wall keep you from getting lost in caves.' },
  { game: 'Apex Legends', tip: "Don't split from your squad. Apex is a team game — alone you're easy pickings." },
  { game: 'Apex Legends', tip: 'Ping everything. The ping system is one of the best in any game — use it.' },
  { game: 'Call of Duty', tip: 'Slide-cancel to move faster between gunfights. Movement is the meta.' },
  { game: 'Call of Duty', tip: 'Suppressor attachments keep you off the minimap — great for flanking.' },
  { game: 'Rocket League', tip: "Don't chase the ball — position yourself for where the ball is going." },
  { game: 'Rocket League', tip: 'Fast aerials are faster than jump aerials. Learn the timing early.' },
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('tip')
    .setDescription('Get a random gaming tip'),

  async execute(interaction) {
    const tip = tips[Math.floor(Math.random() * tips.length)];

    const embed = new EmbedBuilder()
      .setColor(0x10b981)
      .setTitle('🎮 Gaming Tip')
      .addFields(
        { name: '🕹️ Game', value: tip.game, inline: true },
        { name: '💡 Tip', value: tip.tip }
      )
      .setFooter({ text: 'Use /tip again for another tip!' })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
