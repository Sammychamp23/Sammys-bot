const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('clear')
    .setDescription('Delete a number of messages from the channel')
    .addIntegerOption((option) =>
      option
        .setName('amount')
        .setDescription('Number of messages to delete (1-100)')
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(100)
    )
    .addUserOption((option) =>
      option.setName('target').setDescription('Only delete messages from this user')
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

  async execute(interaction) {
    const amount = interaction.options.getInteger('amount');
    const target = interaction.options.getUser('target');

    await interaction.deferReply({ ephemeral: true });

    let messages = await interaction.channel.messages.fetch({ limit: 100 });

    if (target) {
      messages = messages.filter((m) => m.author.id === target.id);
    }

    messages = [...messages.values()].slice(0, amount);

    const deleted = await interaction.channel.bulkDelete(messages, true);

    const embed = new EmbedBuilder()
      .setColor(0x3b82f6)
      .setTitle('🗑️ Messages Cleared')
      .addFields(
        { name: 'Deleted', value: `${deleted.size} message(s)` },
        { name: 'Channel', value: `${interaction.channel}` },
        { name: 'Moderator', value: interaction.user.tag },
        ...(target ? [{ name: 'Filtered User', value: target.tag }] : [])
      )
      .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
  },
};
