const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getRoleShopStock, buyRoleShopItem } = require('../data/store');

const RARITY_COLORS = {
  common:    0x9ca3af,
  rare:      0x3b82f6,
  epic:      0xa855f7,
  legendary: 0xf59e0b,
};

const RARITY_LABELS = {
  common:    '⚪ Common',
  rare:      '🔵 Rare',
  epic:      '🟣 Epic',
  legendary: '🟡 Legendary',
};

const ROLE_SHOP_ITEMS = [
  // Common — stock 10, restock 15–30 min
  { id: 'gamer',       rarity: 'common',    role: '🎮 Gamer',          price: 500,   stock: 10, restockMin: 15,   restockMax: 30  },
  { id: 'sharpshooter',rarity: 'common',    role: '🎯 Competitive',    price: 600,   stock: 10, restockMin: 15,   restockMax: 30  },
  { id: 'casual',      rarity: 'common',    role: '🎮 Casual',         price: 400,   stock: 10, restockMin: 10,   restockMax: 20  },

  // Rare — stock 5, restock 1–3 hours
  { id: 'elite',       rarity: 'rare',      role: '💜 Elite',          price: 2000,  stock: 5,  restockMin: 60,   restockMax: 180 },
  { id: 'trusted',     rarity: 'rare',      role: '🤝 Trusted',        price: 2500,  stock: 5,  restockMin: 60,   restockMax: 180 },
  { id: 'creator',     rarity: 'rare',      role: '🎬 Content Creator', price: 3000,  stock: 5,  restockMin: 90,   restockMax: 180 },

  // Epic — stock 3, restock 6–12 hours
  { id: 'vip',         rarity: 'epic',      role: '🌟 VIP',            price: 5000,  stock: 3,  restockMin: 360,  restockMax: 720 },
  { id: 'trader',      rarity: 'epic',      role: '💹 Trader',         price: 6000,  stock: 3,  restockMin: 360,  restockMax: 720 },

  // Legendary — stock 1, restock 24–72 hours
  { id: 'legend',      rarity: 'legendary', role: '🏆 Legend',         price: 10000, stock: 1,  restockMin: 1440, restockMax: 4320 },
  { id: 'champion',    rarity: 'legendary', role: '🥇 Seasonal Champion', price: 15000, stock: 1, restockMin: 2880, restockMax: 4320 },
];

function getRestockTime(item, lastRestock) {
  const jitter = 0.8 + Math.random() * 0.4;
  const range = item.restockMax - item.restockMin;
  const minutes = item.restockMin + Math.floor(range * jitter);
  return lastRestock + minutes * 60 * 1000;
}

function formatCountdown(ms) {
  if (ms <= 0) return 'Restocking soon...';
  const h = Math.floor(ms / 3600000);
  const m = Math.floor((ms % 3600000) / 60000);
  if (h > 0) return `${h}h ${m}m`;
  return `${m}m`;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('roleshop')
    .setDescription('Browse and buy exclusive roles with limited stock')
    .addSubcommand((sub) => sub.setName('browse').setDescription('View the role shop'))
    .addSubcommand((sub) =>
      sub.setName('buy').setDescription('Purchase a role from the shop')
        .addStringOption((opt) =>
          opt.setName('role').setDescription('Role to purchase').setRequired(true)
            .addChoices(...ROLE_SHOP_ITEMS.map((i) => ({ name: `${RARITY_LABELS[i.rarity]} — ${i.role} (${i.price.toLocaleString()} 💰)`, value: i.id })))
        )
    ),

  ROLE_SHOP_ITEMS,

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;
    const userId = interaction.user.id;

    if (sub === 'browse') {
      const stock = getRoleShopStock(guildId);
      const now = Date.now();

      const grouped = { common: [], rare: [], epic: [], legendary: [] };

      for (const item of ROLE_SHOP_ITEMS) {
        const s = stock[item.id] || { current: item.stock, lastRestock: now };
        const restockAt = s.current === 0 ? getRestockTime(item, s.lastRestock) : null;
        const available = restockAt && restockAt <= now;
        const currentStock = available ? item.stock : s.current;

        let line;
        if (currentStock <= 0 && restockAt && restockAt > now) {
          line = `**${item.role}** — ${item.price.toLocaleString()} 💰 | ❌ Sold out · ⏳ ${formatCountdown(restockAt - now)}`;
        } else {
          line = `**${item.role}** — ${item.price.toLocaleString()} 💰 | ✅ ${currentStock} left`;
        }
        grouped[item.rarity].push(line);
      }

      const embed = new EmbedBuilder()
        .setColor(0xf59e0b)
        .setTitle('🏪 Role Shop')
        .setDescription('Limited stock — roles sell out fast! Use `/roleshop buy` to purchase.')
        .addFields(
          { name: '⚪ Common', value: grouped.common.join('\n') || 'None', inline: false },
          { name: '🔵 Rare', value: grouped.rare.join('\n') || 'None', inline: false },
          { name: '🟣 Epic', value: grouped.epic.join('\n') || 'None', inline: false },
          { name: '🟡 Legendary', value: grouped.legendary.join('\n') || 'None', inline: false },
        )
        .setFooter({ text: 'Stock restocks automatically • Earn coins via chat, voice & quests' })
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'buy') {
      const itemId = interaction.options.getString('role');
      const item = ROLE_SHOP_ITEMS.find((i) => i.id === itemId);

      const result = buyRoleShopItem(guildId, userId, item);

      if (!result.success) {
        return interaction.reply({ content: `❌ ${result.reason}`, ephemeral: true });
      }

      const role = interaction.guild.roles.cache.find((r) => r.name === item.role);
      if (!role) return interaction.reply({ content: `❌ The role **${item.role}** doesn't exist on this server. Run \`/setup\` first!`, ephemeral: true });

      if (interaction.member.roles.cache.has(role.id)) {
        return interaction.reply({ content: `❌ You already have the **${item.role}** role!`, ephemeral: true });
      }

      await interaction.member.roles.add(role).catch(() => {});

      const embed = new EmbedBuilder()
        .setColor(RARITY_COLORS[item.rarity])
        .setTitle('✅ Role Purchased!')
        .setDescription(`You now have **${item.role}**!`)
        .addFields(
          { name: 'Rarity', value: RARITY_LABELS[item.rarity], inline: true },
          { name: 'Cost', value: `${item.price.toLocaleString()} 💰`, inline: true },
          { name: 'Remaining Balance', value: `${result.newBalance.toLocaleString()} 💰`, inline: true },
          { name: 'Stock Left', value: `${result.stockLeft} remaining`, inline: true },
        )
        .setFooter({ text: `${item.rarity === 'legendary' ? '🌟 Extremely rare!' : 'Grab it before it sells out!'}` })
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }
  },
};
