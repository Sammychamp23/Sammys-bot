const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const cfg = require('../data/config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('config')
    .setDescription('Configure the bot for your server')
    .addSubcommand((sub) =>
      sub
        .setName('logs')
        .setDescription('Set the channel for mod/server logs')
        .addChannelOption((opt) => opt.setName('channel').setDescription('Log channel').setRequired(true))
    )
    .addSubcommand((sub) =>
      sub
        .setName('automod')
        .setDescription('Toggle auto-moderation features')
        .addStringOption((opt) =>
          opt
            .setName('feature')
            .setDescription('Feature to toggle')
            .setRequired(true)
            .addChoices(
              { name: 'Anti-Spam', value: 'antispam' },
              { name: 'Anti-Caps', value: 'anticaps' },
              { name: 'Anti-Links', value: 'antilinks' },
              { name: 'Anti-Raid', value: 'antiraid' }
            )
        )
        .addBooleanOption((opt) => opt.setName('enabled').setDescription('Enable or disable').setRequired(true))
    )
    .addSubcommand((sub) =>
      sub
        .setName('autorole')
        .setDescription('Set a role to auto-assign when a member joins')
        .addRoleOption((opt) => opt.setName('role').setDescription('Role to auto-assign (leave empty to disable)'))
    )
    .addSubcommand((sub) =>
      sub
        .setName('blacklist')
        .setDescription('Manage the word blacklist')
        .addStringOption((opt) =>
          opt
            .setName('action')
            .setDescription('Add or remove a word')
            .setRequired(true)
            .addChoices({ name: 'Add word', value: 'add' }, { name: 'Remove word', value: 'remove' }, { name: 'List words', value: 'list' })
        )
        .addStringOption((opt) => opt.setName('word').setDescription('The word to add/remove'))
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;

    if (sub === 'logs') {
      const channel = interaction.options.getChannel('channel');
      cfg.set(guildId, 'logsChannel', channel.id);
      await interaction.reply({
        embeds: [new EmbedBuilder().setColor(0x22c55e).setDescription(`✅ Log channel set to ${channel}.`)],
      });
    }

    if (sub === 'automod') {
      const feature = interaction.options.getString('feature');
      const enabled = interaction.options.getBoolean('enabled');
      cfg.set(guildId, feature, enabled);
      const labels = { antispam: 'Anti-Spam', anticaps: 'Anti-Caps', antilinks: 'Anti-Links', antiraid: 'Anti-Raid' };
      await interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(enabled ? 0x22c55e : 0xef4444)
            .setDescription(`${enabled ? '✅' : '❌'} **${labels[feature]}** has been ${enabled ? 'enabled' : 'disabled'}.`),
        ],
      });
    }

    if (sub === 'autorole') {
      const role = interaction.options.getRole('role');
      if (role) {
        cfg.set(guildId, 'autorole', role.id);
        await interaction.reply({
          embeds: [new EmbedBuilder().setColor(0x22c55e).setDescription(`✅ Auto-role set to ${role}. New members will receive this role on join.`)],
        });
      } else {
        cfg.set(guildId, 'autorole', null);
        await interaction.reply({ embeds: [new EmbedBuilder().setColor(0xf59e0b).setDescription('✅ Auto-role disabled.')] });
      }
    }

    if (sub === 'blacklist') {
      const action = interaction.options.getString('action');
      const word = interaction.options.getString('word')?.toLowerCase();
      const list = cfg.get(guildId, 'blacklist', []);

      if (action === 'list') {
        return interaction.reply({
          embeds: [
            new EmbedBuilder()
              .setColor(0x6366f1)
              .setTitle('🚫 Blacklisted Words')
              .setDescription(list.length ? list.map((w) => `\`${w}\``).join(', ') : 'No words blacklisted yet.'),
          ],
          ephemeral: true,
        });
      }

      if (!word) return interaction.reply({ content: '❌ Please provide a word.', ephemeral: true });

      if (action === 'add') {
        if (list.includes(word)) return interaction.reply({ content: '❌ Already blacklisted.', ephemeral: true });
        list.push(word);
        cfg.set(guildId, 'blacklist', list);
        await interaction.reply({ embeds: [new EmbedBuilder().setColor(0x22c55e).setDescription(`✅ \`${word}\` added to blacklist.`)], ephemeral: true });
      }

      if (action === 'remove') {
        const idx = list.indexOf(word);
        if (idx === -1) return interaction.reply({ content: '❌ Word not in blacklist.', ephemeral: true });
        list.splice(idx, 1);
        cfg.set(guildId, 'blacklist', list);
        await interaction.reply({ embeds: [new EmbedBuilder().setColor(0x22c55e).setDescription(`✅ \`${word}\` removed from blacklist.`)], ephemeral: true });
      }
    }
  },
};
