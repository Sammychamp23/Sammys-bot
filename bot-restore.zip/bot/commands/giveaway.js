const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require('discord.js');
const fs   = require('fs');
const path = require('path');

const dataFile = path.join(__dirname, '..', 'data', 'giveaways.json');

function load() {
  if (!fs.existsSync(dataFile)) return {};
  try { return JSON.parse(fs.readFileSync(dataFile, 'utf8')); } catch { return {}; }
}
function save(data) { fs.writeFileSync(dataFile, JSON.stringify(data, null, 2)); }

function pickWinners(entries, count) {
  const pool = [...entries];
  const winners = [];
  while (winners.length < count && pool.length) {
    const idx = Math.floor(Math.random() * pool.length);
    winners.push(pool.splice(idx, 1)[0]);
  }
  return winners;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('giveaway')
    .setDescription('Giveaway management')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((sub) =>
      sub.setName('start')
        .setDescription('Start a giveaway')
        .addStringOption((o) => o.setName('prize').setDescription('What are you giving away?').setRequired(true))
        .addIntegerOption((o) => o.setName('minutes').setDescription('Duration in minutes').setRequired(true).setMinValue(1))
        .addIntegerOption((o) => o.setName('winners').setDescription('Number of winners (default: 1)').setMinValue(1).setMaxValue(10))
    )
    .addSubcommand((sub) =>
      sub.setName('end').setDescription('End a giveaway early by message ID')
        .addStringOption((o) => o.setName('message_id').setDescription('Giveaway message ID').setRequired(true))
    )
    .addSubcommand((sub) =>
      sub.setName('reroll').setDescription('Reroll a finished giveaway')
        .addStringOption((o) => o.setName('message_id').setDescription('Giveaway message ID').setRequired(true))
    ),

  // Called from interactionCreate for button presses
  async handleEntry(interaction) {
    const giveawayId = interaction.customId.replace('giveaway_enter_', '');
    const data = load();
    const gw = data[giveawayId];
    if (!gw) return interaction.reply({ content: '❌ Giveaway not found.', ephemeral: true });
    if (gw.ended) return interaction.reply({ content: '❌ This giveaway has already ended.', ephemeral: true });
    if (gw.entries.includes(interaction.user.id)) {
      return interaction.reply({ content: '✅ You are already entered! Good luck! 🍀', ephemeral: true });
    }
    gw.entries.push(interaction.user.id);
    save(data);
    return interaction.reply({
      content: `🎉 You entered the giveaway for **${gw.prize}**! **${gw.entries.length}** entries so far. Good luck!`,
      ephemeral: true,
    });
  },

  async endGiveaway(client, giveawayId) {
    const data = load();
    const gw = data[giveawayId];
    if (!gw || gw.ended) return;

    gw.ended = true;
    const winners = pickWinners(gw.entries, gw.winnerCount);
    gw.winners = winners;
    save(data);

    try {
      const guild   = await client.guilds.fetch(gw.guildId).catch(() => null);
      if (!guild) return;
      const channel = await guild.channels.fetch(gw.channelId).catch(() => null);
      if (!channel) return;
      const msg     = await channel.messages.fetch(giveawayId).catch(() => null);

      const winnerMentions = winners.length
        ? winners.map((id) => `<@${id}>`).join(', ')
        : 'Nobody entered 😢';

      const endEmbed = new EmbedBuilder()
        .setColor(0xa855f7)
        .setTitle('🎉 Giveaway Ended!')
        .setDescription(`**Prize:** ${gw.prize}\n\n🏆 **Winner${winners.length > 1 ? 's' : ''}:** ${winnerMentions}`)
        .addFields({ name: '📊 Total Entries', value: `**${gw.entries.length}**` })
        .setFooter({ text: 'Congratulations to the winners!' })
        .setTimestamp();

      if (msg) await msg.edit({ embeds: [endEmbed], components: [] }).catch(() => {});

      await channel.send({
        content: `🎉 Congratulations ${winnerMentions}! You won **${gw.prize}**!`,
        embeds: [endEmbed],
      }).catch(() => {});
    } catch { /* silent */ }
  },

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub === 'start') {
      const prize      = interaction.options.getString('prize');
      const minutes    = interaction.options.getInteger('minutes');
      const winnerCount = interaction.options.getInteger('winners') ?? 1;
      const endsAt     = Date.now() + minutes * 60 * 1000;

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId('giveaway_enter_PLACEHOLDER')
          .setLabel('🎉 Enter Giveaway')
          .setStyle(ButtonStyle.Primary),
      );

      const embed = new EmbedBuilder()
        .setColor(0xf59e0b)
        .setTitle('🎁 GIVEAWAY!')
        .setDescription(`**Prize:** ${prize}\n\nClick the button below to enter!\n\n⏰ **Ends:** <t:${Math.floor(endsAt / 1000)}:R>`)
        .addFields(
          { name: '🏆 Winners',  value: `**${winnerCount}**`, inline: true },
          { name: '🎟️ Entries', value: '**0**', inline: true },
          { name: '⏱️ Duration', value: `**${minutes}** minute${minutes > 1 ? 's' : ''}`, inline: true },
        )
        .setFooter({ text: 'Hosted by ' + interaction.user.username })
        .setTimestamp();

      const channel = interaction.guild.channels.cache.find(
        (c) => c.name === '🎁giveaways' && c.isTextBased()
      ) ?? interaction.channel;

      const giveawayMsg = await channel.send({ embeds: [embed], components: [row] });

      // Update button with real message ID
      const realRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`giveaway_enter_${giveawayMsg.id}`)
          .setLabel('🎉 Enter Giveaway')
          .setStyle(ButtonStyle.Primary),
      );
      await giveawayMsg.edit({ components: [realRow] });

      // Ping giveaways role if it exists
      const pingRole = interaction.guild.roles.cache.find((r) => r.name === '🎉 Giveaways');
      if (pingRole) {
        await channel.send({ content: `${pingRole} A new giveaway has started! Prize: **${prize}**` }).catch(() => {});
      }

      const data = load();
      data[giveawayMsg.id] = {
        guildId: interaction.guild.id,
        channelId: channel.id,
        prize,
        winnerCount,
        endsAt,
        entries: [],
        ended: false,
        winners: [],
      };
      save(data);

      // Schedule auto-end
      setTimeout(() => {
        this.endGiveaway(interaction.client, giveawayMsg.id);
      }, minutes * 60 * 1000);

      return interaction.reply({
        content: `✅ Giveaway started in ${channel} for **${prize}** — ends in **${minutes}** minute${minutes > 1 ? 's' : ''}!`,
        ephemeral: true,
      });
    }

    if (sub === 'end') {
      const msgId = interaction.options.getString('message_id');
      await this.endGiveaway(interaction.client, msgId);
      return interaction.reply({ content: '✅ Giveaway ended!', ephemeral: true });
    }

    if (sub === 'reroll') {
      const msgId = interaction.options.getString('message_id');
      const data  = load();
      const gw    = data[msgId];
      if (!gw) return interaction.reply({ content: '❌ Giveaway not found.', ephemeral: true });
      const newWinners = pickWinners(gw.entries, gw.winnerCount);
      gw.winners = newWinners;
      save(data);
      const mentions = newWinners.length ? newWinners.map((id) => `<@${id}>`).join(', ') : 'Nobody';
      return interaction.reply({ content: `🎲 Rerolled! New winner${newWinners.length > 1 ? 's' : ''}: ${mentions}` });
    }
  },
};
