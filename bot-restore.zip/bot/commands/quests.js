const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { DAILY_QUESTS, WEEKLY_QUESTS, getQuestData, claimQuest } = require('../data/store');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('quests')
    .setDescription('View and claim your daily and weekly quests')
    .addSubcommand((sub) => sub.setName('view').setDescription('See your active quests'))
    .addSubcommand((sub) =>
      sub.setName('claim').setDescription('Claim a completed quest reward')
        .addStringOption((opt) =>
          opt.setName('quest').setDescription('Quest ID to claim').setRequired(true)
            .addChoices(
              { name: '[Daily] Chat 10 times', value: 'messages10' },
              { name: '[Daily] Chat 25 times', value: 'messages25' },
              { name: '[Daily] Spend 15 min in VC', value: 'vc15' },
              { name: '[Weekly] Chat 100 times', value: 'messages100' },
              { name: '[Weekly] Spend 60 min in VC', value: 'vc60' },
              { name: '[Weekly] Win 3 challenges', value: 'wins3' },
            )
        )
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;
    const userId = interaction.user.id;

    if (sub === 'view') {
      const { entry } = getQuestData(guildId, userId);

      const formatQuest = (q, bucket) => {
        const progress = bucket[q.id]?.progress || 0;
        const claimed = bucket[q.id]?.claimed || false;
        const bar = Math.floor((progress / q.goal) * 10);
        const status = claimed ? '✅' : progress >= q.goal ? '🎁 Ready!' : `${'█'.repeat(bar)}${'░'.repeat(10 - bar)} ${progress}/${q.goal}`;
        return `**${q.name}**\n${status}\n+${q.xp} XP, +${q.coins} coins`;
      };

      const dailyFields = DAILY_QUESTS.map((q) => ({
        name: `📅 ${q.name}`,
        value: (() => {
          const progress = entry.daily[q.id]?.progress || 0;
          const claimed = entry.daily[q.id]?.claimed || false;
          const bar = Math.floor((progress / q.goal) * 10);
          if (claimed) return '✅ Claimed';
          if (progress >= q.goal) return `🎁 Ready to claim! (\`/quests claim\`)`;
          return `${'█'.repeat(bar)}${'░'.repeat(10 - bar)} ${progress}/${q.goal}\n+${q.xp} XP, +${q.coins} 💰`;
        })(),
        inline: false,
      }));

      const weeklyFields = WEEKLY_QUESTS.map((q) => ({
        name: `📆 ${q.name}`,
        value: (() => {
          const progress = entry.weekly[q.id]?.progress || 0;
          const claimed = entry.weekly[q.id]?.claimed || false;
          const bar = Math.floor((progress / q.goal) * 10);
          if (claimed) return '✅ Claimed';
          if (progress >= q.goal) return `🎁 Ready to claim! (\`/quests claim\`)`;
          return `${'█'.repeat(bar)}${'░'.repeat(10 - bar)} ${progress}/${q.goal}\n+${q.xp} XP, +${q.coins} 💰`;
        })(),
        inline: false,
      }));

      const embed = new EmbedBuilder()
        .setColor(0x6366f1)
        .setTitle('🎯 Your Quests')
        .setDescription('Complete quests to earn XP and coins. Quests reset daily/weekly.')
        .addFields(
          { name: '─── Daily Quests ───', value: '\u200B' },
          ...dailyFields,
          { name: '─── Weekly Quests ───', value: '\u200B' },
          ...weeklyFields,
        )
        .setFooter({ text: 'Quests track messages and VC time automatically.' })
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'claim') {
      const questId = interaction.options.getString('quest');
      const result = claimQuest(guildId, userId, questId);

      if (!result.success) {
        return interaction.reply({ content: `❌ ${result.reason}`, ephemeral: true });
      }

      const embed = new EmbedBuilder()
        .setColor(0x22c55e)
        .setTitle('🎁 Quest Reward Claimed!')
        .addFields(
          { name: 'Quest', value: result.quest.name, inline: true },
          { name: 'XP Earned', value: `+**${result.quest.xp}** XP`, inline: true },
          { name: 'Coins Earned', value: `+**${result.quest.coins}** 💰`, inline: true },
        )
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }
  },
};
