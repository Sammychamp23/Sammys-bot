const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getClaimableRewards, claimAllRewards, getCoins } = require('../data/store');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('claim')
    .setDescription('Claim all your pending rewards (comeback bonuses, event prizes, etc.)'),

  async execute(interaction) {
    const guildId = interaction.guild.id;
    const userId = interaction.user.id;

    const pending = getClaimableRewards(guildId, userId);

    if (!pending.length) {
      const embed = new EmbedBuilder()
        .setColor(0x6366f1)
        .setTitle('🎁 Claimable Rewards')
        .setDescription("You have no pending rewards right now.\n\n**How to earn claimable rewards:**\n• Come back after 3+ days of inactivity\n• React to event drops in chat\n• Win server events and competitions\n• Complete special challenges")
        .setTimestamp();
      return interaction.reply({ embeds: [embed] });
    }

    const result = claimAllRewards(guildId, userId);
    const { coins } = getCoins(guildId, userId);

    const rewardLines = result.rewards.map((r) => {
      const parts = [];
      if (r.coins) parts.push(`+${r.coins.toLocaleString()} 💰`);
      if (r.xp) parts.push(`+${r.xp} ⭐ XP`);
      if (r.label) parts.push(r.label);
      return `• ${parts.join(' ')}${r.reason ? ` — *${r.reason}*` : ''}`;
    }).join('\n');

    const embed = new EmbedBuilder()
      .setColor(0xf59e0b)
      .setTitle('🎁 Rewards Claimed!')
      .setDescription(`You claimed **${result.rewards.length}** reward(s):\n\n${rewardLines}`)
      .addFields(
        { name: '💰 Total Coins', value: `+**${result.totalCoins.toLocaleString()}**`, inline: true },
        { name: '⭐ Total XP', value: `+**${result.totalXp}**`, inline: true },
        { name: '👛 New Balance', value: `**${coins.toLocaleString()}** coins`, inline: true },
      )
      .setTimestamp();

    return interaction.reply({ embeds: [embed] });
  },
};
