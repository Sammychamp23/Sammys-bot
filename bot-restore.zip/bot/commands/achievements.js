const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { ACHIEVEMENTS, getAchievements, claimAchievement } = require('../data/store');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('achievements')
    .setDescription('View and claim your achievements')
    .addSubcommand((sub) => sub.setName('view').setDescription('See all achievements and your progress'))
    .addSubcommand((sub) =>
      sub.setName('claim').setDescription('Claim a completed achievement reward')
        .addStringOption((opt) => opt.setName('id').setDescription('Achievement ID to claim').setRequired(true))
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;
    const userId = interaction.user.id;

    if (sub === 'view') {
      const achs = getAchievements(guildId, userId);
      const completed = achs.filter((a) => a.progress >= a.goal && a.claimed);
      const ready = achs.filter((a) => a.progress >= a.goal && !a.claimed);
      const inProgress = achs.filter((a) => a.progress < a.goal);

      const readyLines = ready.length
        ? ready.map((a) => `✅ **${a.name}** — *${a.desc}*\n> 🏅 +${a.xp} XP, +${a.coins.toLocaleString()} coins | \`/achievements claim ${a.id}\``).join('\n\n')
        : '*None ready to claim.*';

      const inProgressLines = inProgress.slice(0, 6).map((a) => {
        const pct = Math.floor((a.progress / a.goal) * 10);
        const bar = '█'.repeat(pct) + '░'.repeat(10 - pct);
        return `**${a.name}** — ${a.progress}/${a.goal}\n\`${bar}\` ${a.desc}`;
      }).join('\n\n');

      const embed = new EmbedBuilder()
        .setColor(0xa855f7)
        .setTitle(`🏆 ${interaction.user.username}'s Achievements`)
        .addFields(
          { name: `🎁 Ready to Claim (${ready.length})`, value: readyLines.slice(0, 1024) },
          { name: `📈 In Progress (${inProgress.length})`, value: inProgressLines || '*None in progress.*' },
          { name: `✔ Completed`, value: `**${completed.length}** / **${ACHIEVEMENTS.length}** achievements unlocked` },
        )
        .setFooter({ text: 'Use /achievements claim <id> to collect rewards!' })
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'claim') {
      const achId = interaction.options.getString('id');
      const result = claimAchievement(guildId, userId, achId);
      if (!result.success) return interaction.reply({ content: `❌ ${result.reason}`, ephemeral: true });

      const embed = new EmbedBuilder()
        .setColor(0xf59e0b)
        .setTitle('🏆 Achievement Unlocked!')
        .setDescription(`**${result.ach.name}**\n${result.ach.desc}`)
        .addFields(
          { name: '⭐ XP Earned', value: `+**${result.ach.xp}** XP`, inline: true },
          { name: '💰 Coins Earned', value: `+**${result.ach.coins.toLocaleString()}** coins`, inline: true },
        )
        .setFooter({ text: 'Keep grinding for more achievements!' })
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }
  },
};
