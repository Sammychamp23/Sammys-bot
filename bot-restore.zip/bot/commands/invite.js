const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const fs   = require('fs');
const path = require('path');

const dataFile = path.join(__dirname, '..', 'data', 'invites.json');

function load() {
  if (!fs.existsSync(dataFile)) return {};
  try { return JSON.parse(fs.readFileSync(dataFile, 'utf8')); } catch { return {}; }
}
function save(data) { fs.writeFileSync(dataFile, JSON.stringify(data, null, 2)); }

const MILESTONES = [
  { count: 1,   coins: 200,  role: null,               label: '1 invite'   },
  { count: 3,   coins: 500,  role: null,               label: '3 invites'  },
  { count: 5,   coins: 1000, role: '🤝 Trusted',       label: '5 invites'  },
  { count: 10,  coins: 2500, role: '🌟 VIP',           label: '10 invites' },
  { count: 25,  coins: 5000, role: null,               label: '25 invites' },
  { count: 50,  coins: 10000, role: null,              label: '50 invites' },
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('invite')
    .setDescription('Invite friends and earn rewards!')
    .addSubcommand((sub) => sub.setName('link').setDescription('Get your invite link and see the benefits'))
    .addSubcommand((sub) => sub.setName('stats').setDescription('Check your invite count and progress'))
    .addSubcommand((sub) =>
      sub.setName('leaderboard').setDescription('See who has the most invites')
    ),

  async execute(interaction) {
    const sub     = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;
    const userId  = interaction.user.id;

    if (sub === 'link') {
      // Create or reuse an existing invite from the bot
      let inviteUrl = 'Use your own invite link from Server Settings';
      try {
        const channel = interaction.guild.channels.cache.find((c) => c.isTextBased() && !c.name.includes('staff'));
        if (channel) {
          const invite = await channel.createInvite({ maxAge: 0, maxUses: 0, unique: false, reason: `Invite link for ${interaction.user.username}` });
          inviteUrl = invite.url;
        }
      } catch { /* no perms, skip */ }

      const embed = new EmbedBuilder()
        .setColor(0x22c55e)
        .setTitle('📲 Invite Friends & Earn Rewards!')
        .setDescription(`Share this server and get rewarded for every friend that joins!\n\n🔗 **Your Invite Link:**\n${inviteUrl}`)
        .addFields(
          {
            name: '🎁 Invite Milestones',
            value: MILESTONES.map((m) =>
              `**${m.label}** — +${m.coins.toLocaleString()} 💰 coins${m.role ? ` + **${m.role}** role` : ''}`
            ).join('\n'),
          },
          {
            name: '💡 Why Invite?',
            value: '> More members = more LFG matches\n> More events and giveaways\n> Better economy from a bigger community\n> Help your friends find their gaming home!',
          },
        )
        .setFooter({ text: 'Use /invite stats to check your progress!' })
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'stats') {
      const data  = load();
      const k     = `${guildId}-${userId}`;
      const entry = data[k] || { count: 0, claimed: [] };
      const next  = MILESTONES.find((m) => m.count > entry.count);

      const embed = new EmbedBuilder()
        .setColor(0x6366f1)
        .setTitle(`📊 ${interaction.user.username}'s Invite Stats`)
        .addFields(
          { name: '👥 Total Invites', value: `**${entry.count}**`, inline: true },
          { name: '🏆 Milestones Hit', value: `**${entry.claimed?.length ?? 0}**`, inline: true },
          { name: '🎯 Next Milestone', value: next ? `**${next.label}** (${next.count - entry.count} more to go!)` : '🎉 All milestones completed!', inline: false },
        )
        .setFooter({ text: 'Use /invite link to get your share link!' })
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'leaderboard') {
      const data = load();
      const entries = Object.entries(data)
        .filter(([k]) => k.startsWith(guildId))
        .map(([k, v]) => ({ userId: k.split('-')[1], count: v.count || 0 }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 10);

      if (!entries.length) {
        return interaction.reply({ content: '❌ No invite data yet — use `/invite link` to start!', ephemeral: true });
      }

      const medals = ['🥇', '🥈', '🥉'];
      const lines  = await Promise.all(
        entries.map(async (e, i) => {
          const user = await interaction.client.users.fetch(e.userId).catch(() => null);
          return `${medals[i] ?? `**${i + 1}.**`} **${user?.username ?? 'Unknown'}** — ${e.count} invite${e.count !== 1 ? 's' : ''}`;
        })
      );

      const embed = new EmbedBuilder()
        .setColor(0xf59e0b)
        .setTitle('👥 Invite Leaderboard')
        .setDescription(lines.join('\n'))
        .setFooter({ text: 'Invite more friends to climb the board!' })
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }
  },

  // Track invites when a member joins — called from index.js guildMemberAdd
  async trackInvite(guild, inviterId) {
    if (!inviterId) return null;
    const data  = load();
    const k     = `${guild.id}-${inviterId}`;
    if (!data[k]) data[k] = { count: 0, claimed: [] };
    data[k].count += 1;
    const milestone = MILESTONES.find(
      (m) => m.count === data[k].count && !data[k].claimed.includes(m.count)
    );
    if (milestone) data[k].claimed.push(milestone.count);
    save(data);
    return milestone;
  },
};
