const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('lock')
    .setDescription('Lock or unlock a channel')
    .addSubcommand((sub) =>
      sub
        .setName('channel')
        .setDescription('Lock a channel so members cannot send messages')
        .addChannelOption((opt) => opt.setName('channel').setDescription('Channel to lock (defaults to current)'))
        .addStringOption((opt) => opt.setName('reason').setDescription('Reason for locking'))
    )
    .addSubcommand((sub) =>
      sub
        .setName('unlock')
        .setDescription('Unlock a channel')
        .addChannelOption((opt) => opt.setName('channel').setDescription('Channel to unlock (defaults to current)'))
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const channel = interaction.options.getChannel('channel') ?? interaction.channel;
    const reason = interaction.options.getString('reason') ?? 'No reason provided';
    const everyone = interaction.guild.roles.everyone;

    if (sub === 'channel') {
      await channel.permissionOverwrites.edit(everyone, { SendMessages: false });
      const embed = new EmbedBuilder()
        .setColor(0xef4444)
        .setTitle('🔒 Channel Locked')
        .addFields(
          { name: 'Channel', value: `${channel}`, inline: true },
          { name: 'Moderator', value: interaction.user.tag, inline: true },
          { name: 'Reason', value: reason }
        )
        .setTimestamp();
      await interaction.reply({ embeds: [embed] });
      await channel.send({ embeds: [new EmbedBuilder().setColor(0xef4444).setDescription('🔒 This channel has been locked by a moderator.')] });
    }

    if (sub === 'unlock') {
      await channel.permissionOverwrites.edit(everyone, { SendMessages: null });
      const embed = new EmbedBuilder()
        .setColor(0x22c55e)
        .setTitle('🔓 Channel Unlocked')
        .addFields(
          { name: 'Channel', value: `${channel}`, inline: true },
          { name: 'Moderator', value: interaction.user.tag, inline: true }
        )
        .setTimestamp();
      await interaction.reply({ embeds: [embed] });
      await channel.send({ embeds: [new EmbedBuilder().setColor(0x22c55e).setDescription('🔓 This channel has been unlocked.')] });
    }
  },
};
