const { SlashCommandBuilder, EmbedBuilder, ChannelType, PermissionsBitField } = require('discord.js');
const { joinQueue, leaveQueue, getQueue, getQueueSummary, popGroup } = require('../data/store');

const GAMES = [
  { name: 'Fortnite', value: 'fortnite', size: 4 },
  { name: 'Valorant', value: 'valorant', size: 5 },
  { name: 'Apex Legends', value: 'apex', size: 3 },
  { name: 'Call of Duty / Warzone', value: 'cod', size: 4 },
  { name: 'Minecraft', value: 'minecraft', size: 4 },
  { name: 'Rocket League', value: 'rocketleague', size: 2 },
  { name: 'Any Game', value: 'any', size: 4 },
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('queue')
    .setDescription('Join or leave the matchmaking queue')
    .addSubcommand((sub) =>
      sub.setName('join').setDescription('Join the queue for a game')
        .addStringOption((opt) =>
          opt.setName('game').setDescription('Game to queue for').setRequired(true)
            .addChoices(...GAMES.map((g) => ({ name: g.name, value: g.value })))
        )
    )
    .addSubcommand((sub) =>
      sub.setName('leave').setDescription('Leave the queue for a game')
        .addStringOption((opt) =>
          opt.setName('game').setDescription('Game queue to leave (leave blank to leave all)')
            .addChoices(...GAMES.map((g) => ({ name: g.name, value: g.value })))
        )
    )
    .addSubcommand((sub) => sub.setName('status').setDescription('View active queues')),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;
    const userId = interaction.user.id;

    if (sub === 'join') {
      const game = interaction.options.getString('game');
      const gameDef = GAMES.find((g) => g.value === game);
      const result = joinQueue(guildId, userId, game);

      if (!result.success) return interaction.reply({ content: `❌ ${result.reason}`, ephemeral: true });

      const q = getQueue(guildId, game);
      const embed = new EmbedBuilder()
        .setColor(0x22c55e)
        .setTitle(`🎮 Joined Queue — ${gameDef.name}`)
        .setDescription(`You're **#${result.position}** in queue.\nNeed **${gameDef.size}** players to start — **${q.length}/${gameDef.size}** ready.`)
        .setFooter({ text: 'Use /queue leave to exit the queue.' })
        .setTimestamp();

      await interaction.reply({ embeds: [embed] });

      // Check if we have enough for a group
      if (q.length >= gameDef.size) {
        const group = popGroup(guildId, game, gameDef.size);
        if (group) {
          const mentions = group.map((id) => `<@${id}>`).join(', ');

          // Create a temporary voice channel for the group
          let vc = null;
          try {
            vc = await interaction.guild.channels.create({
              name: `🎮 ${gameDef.name} Match`,
              type: ChannelType.GuildVoice,
              permissionOverwrites: [
                { id: interaction.guild.roles.everyone, deny: [PermissionsBitField.Flags.ViewChannel] },
                ...group.map((id) => ({ id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak] })),
              ],
            });
            setTimeout(() => vc.delete().catch(() => {}), 2 * 60 * 60 * 1000); // 2 hours
          } catch { /* no perms */ }

          const matchEmbed = new EmbedBuilder()
            .setColor(0xf59e0b)
            .setTitle(`⚡ Match Found — ${gameDef.name}!`)
            .setDescription(`${mentions}\n\nYour group of **${gameDef.size}** is ready!${vc ? `\n\n🔊 Join your private VC: **${vc.name}**` : ''}`)
            .setFooter({ text: 'Good luck and have fun! 🎮' })
            .setTimestamp();

          interaction.channel.send({ content: mentions, embeds: [matchEmbed] }).catch(() => {});
        }
      }
      return;
    }

    if (sub === 'leave') {
      const game = interaction.options.getString('game');
      const result = leaveQueue(guildId, userId, game);
      if (!result.success) return interaction.reply({ content: `❌ ${result.reason}`, ephemeral: true });
      return interaction.reply({ content: `✅ Left queue for: **${result.games.join(', ')}**`, ephemeral: true });
    }

    if (sub === 'status') {
      const summary = getQueueSummary(guildId);

      if (!summary.length) {
        return interaction.reply({
          embeds: [
            new EmbedBuilder()
              .setColor(0x6366f1)
              .setTitle('🎮 Matchmaking Queues')
              .setDescription('No active queues right now.\n\nUse `/queue join` to be the first!')
              .setTimestamp(),
          ],
        });
      }

      const lines = summary.map((q) => {
        const gameDef = GAMES.find((g) => g.value === q.game);
        return `**${gameDef?.name ?? q.game}** — ${q.players}/${gameDef?.size ?? '?'} players`;
      }).join('\n');

      const embed = new EmbedBuilder()
        .setColor(0x6366f1)
        .setTitle('🎮 Active Matchmaking Queues')
        .setDescription(lines)
        .setFooter({ text: 'Use /queue join to get in a game!' })
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }
  },
};
