const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { getCoins, addCoins, claimDaily, claimWeekly } = require('../data/store');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('coins')
    .setDescription('Manage your server coins')
    .addSubcommand((sub) =>
      sub.setName('balance').setDescription('Check your coin balance')
        .addUserOption((opt) => opt.setName('user').setDescription('User to check'))
    )
    .addSubcommand((sub) => sub.setName('daily').setDescription('Claim your daily coins (streak bonuses!)'))
    .addSubcommand((sub) => sub.setName('weekly').setDescription('Claim your weekly coins (7-day cooldown)'))
    .addSubcommand((sub) =>
      sub.setName('give').setDescription('Give coins to another member')
        .addUserOption((opt) => opt.setName('user').setDescription('Who to give coins to').setRequired(true))
        .addIntegerOption((opt) => opt.setName('amount').setDescription('Amount to give').setRequired(true).setMinValue(1))
    )
    .addSubcommand((sub) =>
      sub.setName('add').setDescription('Add coins to a member (Admin only)')
        .addUserOption((opt) => opt.setName('user').setDescription('Target user').setRequired(true))
        .addIntegerOption((opt) => opt.setName('amount').setDescription('Amount to add').setRequired(true))
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;

    if (sub === 'balance') {
      const target = interaction.options.getUser('user') ?? interaction.user;
      const { coins, voiceMinutes, dailyStreak } = getCoins(guildId, target.id);
      const embed = new EmbedBuilder()
        .setColor(0xf59e0b)
        .setTitle(`💰 ${target.username}'s Balance`)
        .addFields(
          { name: 'Coins', value: `**${coins.toLocaleString()}** 💰`, inline: true },
          { name: 'VC Time', value: `**${voiceMinutes || 0}** min`, inline: true },
          { name: '🔥 Daily Streak', value: `**${dailyStreak || 0}** days`, inline: true },
        )
        .setFooter({ text: 'Earn via chat, voice, quests & daily/weekly!' })
        .setTimestamp();
      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'daily') {
      const result = claimDaily(guildId, interaction.user.id);
      if (!result.success) {
        const hours = Math.floor(result.remaining / 3600000);
        const mins  = Math.floor((result.remaining % 3600000) / 60000);
        return interaction.reply({ content: `⏳ Daily already claimed! Come back in **${hours}h ${mins}m**.`, ephemeral: true });
      }

      const streakEmoji = result.streak >= 30 ? '🔥🔥🔥' : result.streak >= 7 ? '🔥🔥' : result.streak >= 3 ? '🔥' : '✨';
      const milestoneText = result.milestoneBonus > 0
        ? `\n🎉 **Milestone bonus!** +${result.milestoneBonus} coins for a ${result.streak}-day streak!`
        : '';

      const nextMilestone = [3, 7, 14, 30].find((m) => m > result.streak) ?? null;
      const footerText = nextMilestone
        ? `Keep going! Milestone bonus at ${nextMilestone}-day streak!`
        : 'Max milestone reached! You\'re unstoppable!';

      const embed = new EmbedBuilder()
        .setColor(0x22c55e)
        .setTitle('💰 Daily Coins Claimed!')
        .addFields(
          { name: 'Base Reward',   value: `+**${result.base}** coins`, inline: true },
          { name: 'Streak Bonus',  value: `+**${result.streakBonus}** coins`, inline: true },
          { name: 'New Balance',   value: `**${result.total.toLocaleString()}** coins`, inline: true },
          { name: `${streakEmoji} Daily Streak`, value: `**${result.streak}** day${result.streak > 1 ? 's' : ''} in a row!${milestoneText}` },
        )
        .setFooter({ text: footerText })
        .setTimestamp();
      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'weekly') {
      const result = claimWeekly(guildId, interaction.user.id);
      if (!result.success) {
        const days  = Math.floor(result.remaining / 86400000);
        const hours = Math.floor((result.remaining % 86400000) / 3600000);
        return interaction.reply({ content: `⏳ Weekly already claimed! Come back in **${days}d ${hours}h**.`, ephemeral: true });
      }
      const embed = new EmbedBuilder()
        .setColor(0xa855f7)
        .setTitle('💜 Weekly Coins Claimed!')
        .addFields(
          { name: 'Base Reward',  value: `+**${result.base}** coins`, inline: true },
          { name: 'Streak Bonus', value: `+**${result.streakBonus}** coins`, inline: true },
          { name: 'New Balance',  value: `**${result.total.toLocaleString()}** coins`, inline: true },
          { name: '🔥 Weekly Streak', value: `**${result.streak}** week${result.streak > 1 ? 's' : ''} in a row!` },
        )
        .setFooter({ text: 'Come back next week for even bigger rewards!' })
        .setTimestamp();
      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'give') {
      const target  = interaction.options.getUser('user');
      const amount  = interaction.options.getInteger('amount');
      const { coins: senderCoins } = getCoins(guildId, interaction.user.id);
      if (target.id === interaction.user.id)
        return interaction.reply({ content: '❌ Cannot give coins to yourself.', ephemeral: true });
      if (senderCoins < amount)
        return interaction.reply({ content: `❌ You only have **${senderCoins}** coins.`, ephemeral: true });
      addCoins(guildId, interaction.user.id, -amount);
      const newBalance = addCoins(guildId, target.id, amount);
      const embed = new EmbedBuilder()
        .setColor(0x22c55e)
        .setTitle('💸 Coins Sent!')
        .addFields(
          { name: 'Sent To',           value: target.username, inline: true },
          { name: 'Amount',            value: `**${amount}** coins`, inline: true },
          { name: "Recipient Balance", value: `**${newBalance.toLocaleString()}** coins` },
        )
        .setTimestamp();
      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'add') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator))
        return interaction.reply({ content: '❌ Admins only.', ephemeral: true });
      const target  = interaction.options.getUser('user');
      const amount  = interaction.options.getInteger('amount');
      const newBalance = addCoins(guildId, target.id, amount);
      return interaction.reply({
        content: `✅ Added **${amount}** coins to ${target.username}. New balance: **${newBalance.toLocaleString()}**.`,
        ephemeral: true,
      });
    }
  },
};
