const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { UPGRADES, getUpgrades, buyUpgrade, getCoins } = require('../data/store');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('upgrades')
    .setDescription('Permanently upgrade your XP, coins, and cooldowns')
    .addSubcommand((sub) => sub.setName('view').setDescription('View available upgrades'))
    .addSubcommand((sub) =>
      sub.setName('buy').setDescription('Purchase an upgrade')
        .addStringOption((opt) =>
          opt.setName('upgrade').setDescription('Upgrade to purchase').setRequired(true)
            .addChoices(
              { name: '⚡ XP Multiplier — +10% XP per level', value: 'xp_boost' },
              { name: '💰 Coin Multiplier — +10% coins per level', value: 'coin_bonus' },
              { name: '⏱️ Cooldown Reduction — -15s cooldown per level', value: 'cd_reduction' },
            )
        )
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;
    const userId = interaction.user.id;

    if (sub === 'view') {
      const upgrades = getUpgrades(guildId, userId);
      const { coins } = getCoins(guildId, userId);

      const lines = upgrades.map((u) => {
        const bar = '🟩'.repeat(u.level) + '⬜'.repeat(u.maxLevel - u.level);
        const nextCost = u.level < u.maxLevel ? `${(u.costPerLevel * (u.level + 1)).toLocaleString()} 💰` : 'MAX';
        return `**${u.name}** — Level ${u.level}/${u.maxLevel}\n${bar}\n${u.desc} | *${u.effect}*\nNext level: **${nextCost}** | ID: \`${u.id}\``;
      }).join('\n\n');

      const embed = new EmbedBuilder()
        .setColor(0x22c55e)
        .setTitle('🏪 Upgrade Shop')
        .setDescription(lines)
        .addFields({ name: '💰 Your Balance', value: `**${coins.toLocaleString()}** coins` })
        .setFooter({ text: 'Use /upgrades buy <upgrade> to level up permanently!' })
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'buy') {
      const upgradeId = interaction.options.getString('upgrade');
      const result = buyUpgrade(guildId, userId, upgradeId);

      if (!result.success) return interaction.reply({ content: `❌ ${result.reason}`, ephemeral: true });

      const upgrade = UPGRADES.find((u) => u.id === upgradeId);
      const embed = new EmbedBuilder()
        .setColor(0x22c55e)
        .setTitle('⬆️ Upgrade Purchased!')
        .setDescription(`**${upgrade.name}** is now at **Level ${result.newLevel}**!`)
        .addFields(
          { name: '💸 Cost', value: `**${result.cost.toLocaleString()}** coins`, inline: true },
          { name: '📈 Effect', value: upgrade.effect, inline: true },
        )
        .setFooter({ text: `${upgrade.name} — ${upgrade.maxLevel - result.newLevel} level(s) remaining` })
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }
  },
};
