const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getCoins, addCoins } = require('../data/store');

const cooldowns = new Map();
const COOLDOWN_MS = 5 * 60 * 1000;
const MAX_BET = 5000;

const GAMBLE_OUTCOMES = [
  { chance: 0.40, mult: 0,    label: '💀 Loss',          color: 0xef4444, msg: 'You lost everything!' },
  { chance: 0.25, mult: 1.5,  label: '🎯 Small Win',     color: 0x22c55e, msg: 'A small victory!' },
  { chance: 0.20, mult: 2,    label: '🎲 Win',            color: 0x22c55e, msg: 'Nice win!' },
  { chance: 0.10, mult: 3,    label: '🔥 Big Win',        color: 0xf59e0b, msg: 'Big win! Keep it up!' },
  { chance: 0.04, mult: 5,    label: '💎 Jackpot!',       color: 0xa855f7, msg: 'JACKPOT! Incredible!' },
  { chance: 0.01, mult: 10,   label: '👑 MEGA JACKPOT!',  color: 0xfbbf24, msg: 'MEGA JACKPOT! Legendary!' },
];

function spinOutcome() {
  let roll = Math.random();
  for (const o of GAMBLE_OUTCOMES) {
    if (roll < o.chance) return o;
    roll -= o.chance;
  }
  return GAMBLE_OUTCOMES[0];
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('gamble')
    .setDescription('Risk your coins for a chance at big rewards')
    .addSubcommand((sub) =>
      sub.setName('spin').setDescription('Spin the wheel — risk coins for a reward')
        .addIntegerOption((opt) =>
          opt.setName('amount').setDescription(`Coins to bet (max ${MAX_BET.toLocaleString()})`).setRequired(true).setMinValue(10).setMaxValue(MAX_BET)
        )
    )
    .addSubcommand((sub) =>
      sub.setName('doubleornothing').setDescription('50/50 — double your coins or lose them all')
        .addIntegerOption((opt) =>
          opt.setName('amount').setDescription(`Coins to bet (max ${MAX_BET.toLocaleString()})`).setRequired(true).setMinValue(10).setMaxValue(MAX_BET)
        )
    )
    .addSubcommand((sub) => sub.setName('odds').setDescription('View the odds table')),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;
    const userId = interaction.user.id;
    const coolKey = `${guildId}-${userId}`;

    if (sub === 'odds') {
      const lines = GAMBLE_OUTCOMES.map((o) =>
        `${o.label} — **${(o.chance * 100).toFixed(0)}%** chance → **${o.mult}x** return`
      );
      const embed = new EmbedBuilder()
        .setColor(0x6366f1)
        .setTitle('🎲 Gamble Odds Table')
        .setDescription(lines.join('\n'))
        .setFooter({ text: `Max bet: ${MAX_BET.toLocaleString()} coins • 5-min cooldown` })
        .setTimestamp();
      return interaction.reply({ embeds: [embed], flags: 64 });
    }

    // Cooldown check
    const lastUsed = cooldowns.get(coolKey) || 0;
    const remaining = COOLDOWN_MS - (Date.now() - lastUsed);
    if (remaining > 0) {
      const mins = Math.ceil(remaining / 60000);
      return interaction.reply({ content: `⏳ You must wait **${mins}m** before gambling again.`, flags: 64 });
    }

    const bet = interaction.options.getInteger('amount');
    const { coins } = getCoins(guildId, userId);

    if (coins < bet) {
      return interaction.reply({ content: `❌ You only have **${coins.toLocaleString()}** coins.`, flags: 64 });
    }

    cooldowns.set(coolKey, Date.now());

    if (sub === 'doubleornothing') {
      const win = Math.random() < 0.5;
      const change = win ? bet : -bet;
      addCoins(guildId, userId, change);
      const newBalance = coins + change;

      const embed = new EmbedBuilder()
        .setColor(win ? 0x22c55e : 0xef4444)
        .setTitle(win ? '🎉 Double or Nothing — YOU WON!' : '💀 Double or Nothing — You Lost!')
        .addFields(
          { name: 'Bet', value: `${bet.toLocaleString()} 💰`, inline: true },
          { name: win ? 'Won' : 'Lost', value: `${Math.abs(change).toLocaleString()} 💰`, inline: true },
          { name: 'New Balance', value: `${newBalance.toLocaleString()} 💰`, inline: true },
        )
        .setFooter({ text: '50/50 odds — try again in 5 minutes' })
        .setTimestamp();
      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'spin') {
      const outcome = spinOutcome();
      const winnings = Math.floor(bet * outcome.mult);
      const change = winnings - bet;
      addCoins(guildId, userId, change);
      const newBalance = coins + change;

      const slots = ['🎰', '🎲', '💎', '7️⃣', '🃏', '🍀'];
      const s1 = slots[Math.floor(Math.random() * slots.length)];
      const s2 = slots[Math.floor(Math.random() * slots.length)];
      const s3 = slots[Math.floor(Math.random() * slots.length)];

      const embed = new EmbedBuilder()
        .setColor(outcome.color)
        .setTitle(`🎰 ${outcome.label}`)
        .setDescription(`${s1} | ${s2} | ${s3}\n\n*${outcome.msg}*`)
        .addFields(
          { name: 'Bet', value: `${bet.toLocaleString()} 💰`, inline: true },
          { name: 'Return', value: `${winnings.toLocaleString()} 💰 (${outcome.mult}x)`, inline: true },
          { name: change >= 0 ? '💚 Profit' : '🔴 Loss', value: `${change >= 0 ? '+' : ''}${change.toLocaleString()} 💰`, inline: true },
          { name: 'New Balance', value: `${newBalance.toLocaleString()} 💰`, inline: false },
        )
        .setFooter({ text: 'Use /gamble odds to see all outcomes • 5-min cooldown' })
        .setTimestamp();
      return interaction.reply({ embeds: [embed] });
    }
  },
};
