const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { createSquad, joinSquad, leaveSquad, getUserSquad, getSquadLeaderboard } = require('../data/store');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('squad')
    .setDescription('Manage your squad')
    .addSubcommand((sub) =>
      sub.setName('create').setDescription('Create a new squad')
        .addStringOption((opt) => opt.setName('name').setDescription('Squad name').setRequired(true).setMaxLength(30))
    )
    .addSubcommand((sub) =>
      sub.setName('join').setDescription('Join an existing squad')
        .addStringOption((opt) => opt.setName('name').setDescription('Squad name').setRequired(true))
    )
    .addSubcommand((sub) => sub.setName('leave').setDescription('Leave your current squad'))
    .addSubcommand((sub) => sub.setName('info').setDescription('View your squad info'))
    .addSubcommand((sub) => sub.setName('leaderboard').setDescription('View squad leaderboard')),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;
    const userId = interaction.user.id;

    if (sub === 'create') {
      const name = interaction.options.getString('name');
      const result = createSquad(guildId, userId, name);
      if (!result.success) return interaction.reply({ content: `❌ ${result.reason}`, ephemeral: true });

      const embed = new EmbedBuilder()
        .setColor(0x22c55e)
        .setTitle('🏰 Squad Created!')
        .setDescription(`You created **${name}**! Share the name with others so they can \`/squad join\`.`)
        .setTimestamp();
      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'join') {
      const name = interaction.options.getString('name');
      const result = joinSquad(guildId, userId, name);
      if (!result.success) return interaction.reply({ content: `❌ ${result.reason}`, ephemeral: true });

      const embed = new EmbedBuilder()
        .setColor(0x22c55e)
        .setTitle('✅ Joined Squad!')
        .setDescription(`You joined **${name}**!`)
        .setTimestamp();
      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'leave') {
      const result = leaveSquad(guildId, userId);
      if (!result.success) return interaction.reply({ content: `❌ ${result.reason}`, ephemeral: true });
      return interaction.reply({ content: `✅ You left **${result.squadName}**.`, ephemeral: true });
    }

    if (sub === 'info') {
      const squad = getUserSquad(guildId, userId);
      if (!squad) return interaction.reply({ content: '❌ You are not in a squad. Use `/squad create` or `/squad join`.', ephemeral: true });

      const memberLines = await Promise.all(
        squad.members.map(async (id) => {
          const user = await interaction.client.users.fetch(id).catch(() => null);
          const isOwner = id === squad.owner;
          return `${isOwner ? '👑' : '•'} ${user?.username ?? 'Unknown'}`;
        })
      );

      const embed = new EmbedBuilder()
        .setColor(0x6366f1)
        .setTitle(`🏰 Squad: ${squad.name}`)
        .addFields(
          { name: '👑 Owner', value: (await interaction.client.users.fetch(squad.owner).catch(() => null))?.username ?? 'Unknown', inline: true },
          { name: '👥 Members', value: `${squad.members.length}`, inline: true },
          { name: '🏆 Wins', value: `${squad.wins || 0}`, inline: true },
          { name: '📋 Roster', value: memberLines.join('\n') || 'None' },
        )
        .setTimestamp();
      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'leaderboard') {
      const board = getSquadLeaderboard(guildId);
      const medals = ['🥇', '🥈', '🥉'];
      const lines = board.map((s, i) =>
        `${medals[i] ?? `**${i + 1}.**`} **${s.name}** — ${s.members} members | ${s.wins} wins`
      );
      const embed = new EmbedBuilder()
        .setColor(0xf59e0b)
        .setTitle('🏆 Squad Leaderboard')
        .setDescription(lines.join('\n') || 'No squads yet!')
        .setTimestamp();
      return interaction.reply({ embeds: [embed] });
    }
  },
};
