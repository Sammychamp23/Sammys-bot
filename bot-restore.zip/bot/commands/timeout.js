const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

const DURATIONS = {
  '60': 60 * 1000,
  '300': 5 * 60 * 1000,
  '600': 10 * 60 * 1000,
  '3600': 60 * 60 * 1000,
  '86400': 24 * 60 * 60 * 1000,
  '604800': 7 * 24 * 60 * 60 * 1000,
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName('timeout')
    .setDescription('Timeout a member')
    .addUserOption((option) =>
      option.setName('target').setDescription('The member to timeout').setRequired(true)
    )
    .addStringOption((option) =>
      option
        .setName('duration')
        .setDescription('Duration of the timeout')
        .setRequired(true)
        .addChoices(
          { name: '1 minute', value: '60' },
          { name: '5 minutes', value: '300' },
          { name: '10 minutes', value: '600' },
          { name: '1 hour', value: '3600' },
          { name: '1 day', value: '86400' },
          { name: '1 week', value: '604800' }
        )
    )
    .addStringOption((option) =>
      option.setName('reason').setDescription('Reason for the timeout')
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const target = interaction.options.getMember('target');
    const durationKey = interaction.options.getString('duration');
    const reason = interaction.options.getString('reason') ?? 'No reason provided';
    const durationMs = DURATIONS[durationKey];

    if (!target) return interaction.reply({ content: '❌ Member not found.', ephemeral: true });
    if (!target.moderatable)
      return interaction.reply({ content: '❌ I cannot timeout this member.', ephemeral: true });
    if (target.id === interaction.user.id)
      return interaction.reply({ content: '❌ You cannot timeout yourself.', ephemeral: true });

    await target.timeout(durationMs, reason);

    const durationLabel = Object.entries({
      '60': '1 minute',
      '300': '5 minutes',
      '600': '10 minutes',
      '3600': '1 hour',
      '86400': '1 day',
      '604800': '1 week',
    }).find(([k]) => k === durationKey)?.[1];

    const embed = new EmbedBuilder()
      .setColor(0xf97316)
      .setTitle('⏱️ Member Timed Out')
      .addFields(
        { name: 'Member', value: `${target.user.tag} (${target.id})` },
        { name: 'Moderator', value: interaction.user.tag },
        { name: 'Duration', value: durationLabel },
        { name: 'Reason', value: reason }
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
