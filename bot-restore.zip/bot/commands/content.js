const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('content')
    .setDescription('Submit clips and vote on weekly highlights')
    .addSubcommand((sub) =>
      sub.setName('submit').setDescription('Submit a clip or highlight')
        .addStringOption((opt) => opt.setName('title').setDescription('Clip title').setRequired(true))
        .addStringOption((opt) => opt.setName('link').setDescription('Link to your clip (YouTube, Twitch, etc.)').setRequired(true))
        .addStringOption((opt) => opt.setName('game').setDescription('Game the clip is from').setRequired(true))
    )
    .addSubcommand((sub) =>
      sub.setName('highlights').setDescription('View and vote on this week\'s top clips')
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub === 'submit') {
      const title = interaction.options.getString('title');
      const link = interaction.options.getString('link');
      const game = interaction.options.getString('game');

      const contentChannel =
        interaction.guild.channels.cache.find((c) => c.name === '🏆clips-highlights' && c.isTextBased()) ??
        interaction.channel;

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('content_upvote').setLabel('👍 Fire').setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId('content_downvote').setLabel('👎 Nah').setStyle(ButtonStyle.Secondary),
      );

      const embed = new EmbedBuilder()
        .setColor(0xa855f7)
        .setTitle(`🎬 ${title}`)
        .setAuthor({ name: interaction.user.username, iconURL: interaction.user.displayAvatarURL() })
        .addFields(
          { name: '🎮 Game', value: game, inline: true },
          { name: '🔗 Link', value: link, inline: true },
          { name: '👍 Votes', value: '**0** 🔥', inline: true },
        )
        .setFooter({ text: 'Vote with the buttons below!' })
        .setTimestamp();

      const msg = await contentChannel.send({ embeds: [embed], components: [row] });

      if (contentChannel.id !== interaction.channelId) {
        await interaction.reply({ content: `✅ Clip submitted to ${contentChannel}!`, ephemeral: true });
      } else {
        await interaction.reply({ content: '✅ Clip submitted!', ephemeral: true });
      }

      const votes = new Map();
      const collector = msg.createMessageComponentCollector({ time: 7 * 24 * 60 * 60 * 1000 });

      collector.on('collect', async (btn) => {
        const prev = votes.get(btn.user.id);
        const newVote = btn.customId === 'content_upvote' ? 'up' : 'down';

        if (prev === newVote) {
          votes.delete(btn.user.id);
        } else {
          votes.set(btn.user.id, newVote);
        }

        const ups = [...votes.values()].filter((v) => v === 'up').length;
        const downs = [...votes.values()].filter((v) => v === 'down').length;

        const updatedEmbed = EmbedBuilder.from(embed).setFields(
          { name: '🎮 Game', value: game, inline: true },
          { name: '🔗 Link', value: link, inline: true },
          { name: '👍 Votes', value: `**${ups}** 🔥 | **${downs}** 👎`, inline: true },
        );

        await btn.update({ embeds: [updatedEmbed], components: [row] });
      });
    }

    if (sub === 'highlights') {
      const embed = new EmbedBuilder()
        .setColor(0xa855f7)
        .setTitle('🎬 Weekly Highlights')
        .setDescription(`Check out the latest submissions in <#${interaction.guild.channels.cache.find((c) => c.name === '🏆clips-highlights')?.id ?? 'clips-highlights'}>!\n\nSubmit your own clips with \`/content submit\`.`)
        .setTimestamp();
      return interaction.reply({ embeds: [embed] });
    }
  },
};
