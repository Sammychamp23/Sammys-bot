const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const cfg = require('../data/config');

const AD_TEMPLATES = [
  {
    title: '🎮 Looking for Your Gaming Home?',
    description: [
      'You\'ve found it. **{serverName}** is a growing gaming community packed with:',
      '',
      '⚔️ **Active Gaming Sessions** — Join organized matches for Valorant, Warzone, Minecraft & more',
      '💰 **Economy & Rewards** — Earn coins and XP just by chatting and playing',
      '🎁 **Mystery Drops & Events** — Random rewards, chaos mode boosts & giveaways',
      '📋 **Quests & Challenges** — Daily goals and 1v1 betting to keep things spicy',
      '🏆 **Leaderboards & Squads** — Climb the ranks or build a crew',
      '',
      '**{memberCount} members** and growing. Come be part of something great.',
    ].join('\n'),
  },
  {
    title: '🚀 The Server That Actually Does Things',
    description: [
      '**{serverName}** isn\'t just another Discord — it\'s a full gaming experience.',
      '',
      '🎯 Drop into sessions with real players',
      '💎 Build your profile, earn upgrades, and flex on the leaderboard',
      '🎰 Gamble, auction, and trade in our player economy',
      '🔥 Catch surprise events and Mystery Drops at any time',
      '',
      'With **{memberCount} members** already in, the fun never stops.',
      'Hit the invite link and jump in — your crew is waiting.',
    ].join('\n'),
  },
  {
    title: '👾 Your Next Favorite Server Just Dropped',
    description: [
      'Welcome to **{serverName}** — where gamers come to play, grind, and vibe.',
      '',
      '🕹️ Organized game sessions every day',
      '📈 Level up your profile with XP & coin rewards',
      '🤝 Find your squad and compete together',
      '🌪️ Chaos Mode events, mystery drops & more surprises',
      '🏅 Rep system to recognize the best community members',
      '',
      '**{memberCount} members** strong. Join and see what you\'ve been missing.',
    ].join('\n'),
  },
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('advertise')
    .setDescription('Manage automatic server advertisements')
    .addSubcommand((sub) =>
      sub
        .setName('setup')
        .setDescription('Set up auto-advertising in a channel')
        .addChannelOption((opt) =>
          opt.setName('channel').setDescription('Channel to post ads in').setRequired(true)
        )
        .addIntegerOption((opt) =>
          opt
            .setName('interval')
            .setDescription('How often to post (in hours)')
            .setRequired(true)
            .setMinValue(1)
            .setMaxValue(168)
        )
        .addStringOption((opt) =>
          opt.setName('invite').setDescription('Custom invite link to include (optional)')
        )
    )
    .addSubcommand((sub) =>
      sub.setName('disable').setDescription('Turn off auto-advertising')
    )
    .addSubcommand((sub) =>
      sub.setName('preview').setDescription('Preview the current ad embed')
    )
    .addSubcommand((sub) =>
      sub.setName('status').setDescription('Check current auto-advertise settings')
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;

    if (sub === 'setup') {
      const channel = interaction.options.getChannel('channel');
      const interval = interaction.options.getInteger('interval');
      const customInvite = interaction.options.getString('invite');

      cfg.set(guildId, 'advertiseChannel', channel.id);
      cfg.set(guildId, 'advertiseInterval', interval);
      cfg.set(guildId, 'advertiseLastPost', 0);
      if (customInvite) cfg.set(guildId, 'advertiseInvite', customInvite);

      await interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(0x22c55e)
            .setTitle('📢 Auto-Advertise Enabled!')
            .setDescription(
              `The bot will post a server ad in ${channel} every **${interval} hour${interval !== 1 ? 's' : ''}**.\n\nUse \`/advertise preview\` to see what the ad looks like, or \`/advertise disable\` to turn it off.`
            )
            .setTimestamp(),
        ],
      });
    }

    if (sub === 'disable') {
      cfg.set(guildId, 'advertiseChannel', null);
      cfg.set(guildId, 'advertiseInterval', null);
      await interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(0xef4444)
            .setDescription('❌ Auto-advertising has been disabled.'),
        ],
      });
    }

    if (sub === 'preview') {
      const embed = buildAdEmbed(interaction.guild);
      await interaction.reply({ embeds: [embed], ephemeral: true });
    }

    if (sub === 'status') {
      const channelId = cfg.get(guildId, 'advertiseChannel');
      const interval = cfg.get(guildId, 'advertiseInterval');
      const lastPost = cfg.get(guildId, 'advertiseLastPost', 0);

      if (!channelId || !interval) {
        return interaction.reply({
          embeds: [
            new EmbedBuilder()
              .setColor(0xf59e0b)
              .setDescription('⚠️ Auto-advertising is not set up. Use `/advertise setup` to enable it.'),
          ],
          ephemeral: true,
        });
      }

      const channel = interaction.guild.channels.cache.get(channelId);
      const nextPost = lastPost + interval * 60 * 60 * 1000;
      const msLeft = nextPost - Date.now();
      const nextLabel = msLeft > 0
        ? `<t:${Math.floor(nextPost / 1000)}:R>`
        : 'Soon (next scheduled check)';

      await interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(0x6366f1)
            .setTitle('📢 Auto-Advertise Status')
            .addFields(
              { name: 'Channel', value: channel ? `${channel}` : `<#${channelId}>`, inline: true },
              { name: 'Interval', value: `Every **${interval}h**`, inline: true },
              { name: 'Next Post', value: nextLabel, inline: true },
            )
            .setTimestamp(),
        ],
        ephemeral: true,
      });
    }
  },
};

function buildAdEmbed(guild) {
  const template = AD_TEMPLATES[Math.floor(Math.random() * AD_TEMPLATES.length)];
  const memberCount = guild.memberCount ?? '?';

  const description = template.description
    .replace(/\{serverName\}/g, guild.name)
    .replace(/\{memberCount\}/g, memberCount.toLocaleString());

  return new EmbedBuilder()
    .setColor(0x6366f1)
    .setTitle(template.title)
    .setDescription(description)
    .setThumbnail(guild.iconURL({ dynamic: true }) ?? null)
    .setFooter({ text: `${guild.name} • Growing every day` })
    .setTimestamp();
}

module.exports.buildAdEmbed = buildAdEmbed;
