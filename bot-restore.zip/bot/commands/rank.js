const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getLevel, xpForLevel } = require('../data/store');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rank')
    .setDescription('Check your rank and XP')
    .addUserOption((opt) => opt.setName('user').setDescription('User to check')),

  async execute(interaction) {
    const target = interaction.options.getUser('user') ?? interaction.user;
    const { level, xp } = getLevel(interaction.guild.id, target.id);
    const needed = xpForLevel(level + 1);
    const progress = Math.floor((xp / needed) * 20);
    const bar = '█'.repeat(progress) + '░'.repeat(20 - progress);

    const embed = new EmbedBuilder()
      .setColor(0x6366f1)
      .setTitle(`⭐ ${target.username}'s Rank`)
      .setThumbnail(target.displayAvatarURL())
      .addFields(
        { name: 'Level', value: `**${level}**`, inline: true },
        { name: 'XP', value: `${xp} / ${needed}`, inline: true },
        { name: 'Progress', value: `\`${bar}\`` }
      )
      .setFooter({ text: 'Keep chatting to earn XP!' })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
