const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getContractData, acceptContract, claimContract, CONTRACT_POOL } = require('../data/store');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('contracts')
    .setDescription('Advanced missions — complete contracts for big rewards')
    .addSubcommand((sub) => sub.setName('view').setDescription('Browse available contracts'))
    .addSubcommand((sub) =>
      sub.setName('accept').setDescription('Accept a contract')
        .addStringOption((opt) =>
          opt.setName('id').setDescription('Contract ID to accept').setRequired(true)
            .addChoices(...CONTRACT_POOL.map((c) => ({ name: `${c.name} (${c.coins} 💰)`, value: c.id })))
        )
    )
    .addSubcommand((sub) =>
      sub.setName('progress').setDescription('View your active contracts')
    )
    .addSubcommand((sub) =>
      sub.setName('claim').setDescription('Claim a completed contract')
        .addStringOption((opt) =>
          opt.setName('id').setDescription('Contract ID to claim').setRequired(true)
        )
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;
    const userId = interaction.user.id;

    if (sub === 'view') {
      const lines = CONTRACT_POOL.map((c) =>
        `\`${c.id}\` **${c.name}**\n${c.desc}\n💰 ${c.coins.toLocaleString()} coins | ✨ ${c.xp} XP\n`
      );
      const embed = new EmbedBuilder()
        .setColor(0x8b5cf6)
        .setTitle('📋 Available Contracts')
        .setDescription(lines.join('\n') || 'No contracts available.')
        .setFooter({ text: 'Max 2 active contracts • Use /contracts accept [id] to take one' })
        .setTimestamp();
      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'accept') {
      const contractId = interaction.options.getString('id');
      const result = acceptContract(guildId, userId, contractId);
      if (!result.success) return interaction.reply({ content: `❌ ${result.reason}`, flags: 64 });
      const c = CONTRACT_POOL.find((x) => x.id === contractId);
      const embed = new EmbedBuilder()
        .setColor(0x22c55e)
        .setTitle('📋 Contract Accepted!')
        .setDescription(`**${c.name}**\n${c.desc}`)
        .addFields(
          { name: 'Reward', value: `${c.coins.toLocaleString()} 💰 + ${c.xp} XP`, inline: true },
          { name: 'Expires', value: `<t:${Math.floor((Date.now() + 7 * 24 * 60 * 60 * 1000) / 1000)}:R>`, inline: true },
        )
        .setFooter({ text: 'Progress is tracked automatically' })
        .setTimestamp();
      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'progress') {
      const { active } = getContractData(guildId, userId);
      if (active.length === 0) {
        return interaction.reply({ content: '📋 You have no active contracts. Use `/contracts view` to pick one!', flags: 64 });
      }
      const lines = active.map((a) => {
        const c = CONTRACT_POOL.find((x) => x.id === a.id);
        if (!c) return null;
        const pct = Math.min(100, Math.floor((a.progress / c.goal) * 100));
        const bar = '█'.repeat(Math.floor(pct / 10)) + '░'.repeat(10 - Math.floor(pct / 10));
        const status = a.progress >= c.goal ? '✅ Complete! Use `/contracts claim`' : `${bar} ${a.progress}/${c.goal}`;
        return `**${c.name}**\n${status}\n💰 ${c.coins.toLocaleString()} coins | ✨ ${c.xp} XP`;
      }).filter(Boolean);

      const embed = new EmbedBuilder()
        .setColor(0x6366f1)
        .setTitle('📋 Your Active Contracts')
        .setDescription(lines.join('\n\n'))
        .setFooter({ text: 'Max 2 active contracts at a time' })
        .setTimestamp();
      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'claim') {
      const contractId = interaction.options.getString('id');
      const result = claimContract(guildId, userId, contractId);
      if (!result.success) return interaction.reply({ content: `❌ ${result.reason}`, flags: 64 });
      const embed = new EmbedBuilder()
        .setColor(0xf59e0b)
        .setTitle('🎉 Contract Complete!')
        .setDescription(`**${result.contract.name}** finished!`)
        .addFields(
          { name: '💰 Coins Earned', value: result.contract.coins.toLocaleString(), inline: true },
          { name: '✨ XP Earned', value: result.contract.xp.toString(), inline: true },
        )
        .setTimestamp();
      return interaction.reply({ embeds: [embed] });
    }
  },
};
