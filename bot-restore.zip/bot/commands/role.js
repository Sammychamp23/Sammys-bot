const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('role')
    .setDescription('Add or remove a role from a member')
    .addSubcommand((sub) =>
      sub
        .setName('add')
        .setDescription('Add a role to a member')
        .addUserOption((opt) => opt.setName('user').setDescription('Target member').setRequired(true))
        .addRoleOption((opt) => opt.setName('role').setDescription('Role to add').setRequired(true))
    )
    .addSubcommand((sub) =>
      sub
        .setName('remove')
        .setDescription('Remove a role from a member')
        .addUserOption((opt) => opt.setName('user').setDescription('Target member').setRequired(true))
        .addRoleOption((opt) => opt.setName('role').setDescription('Role to remove').setRequired(true))
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const target = interaction.options.getMember('user');
    const role = interaction.options.getRole('role');

    if (!target) return interaction.reply({ content: '❌ Member not found.', ephemeral: true });
    if (role.position >= interaction.guild.members.me.roles.highest.position)
      return interaction.reply({ content: '❌ That role is too high for me to manage.', ephemeral: true });
    if (role.position >= interaction.member.roles.highest.position)
      return interaction.reply({ content: '❌ You cannot manage a role equal to or higher than your own.', ephemeral: true });

    if (sub === 'add') {
      if (target.roles.cache.has(role.id))
        return interaction.reply({ content: `❌ ${target.user.tag} already has that role.`, ephemeral: true });
      await target.roles.add(role);
      const embed = new EmbedBuilder()
        .setColor(0x22c55e)
        .setTitle('✅ Role Added')
        .addFields(
          { name: 'Member', value: target.user.tag, inline: true },
          { name: 'Role', value: role.toString(), inline: true },
          { name: 'By', value: interaction.user.tag, inline: true }
        )
        .setTimestamp();
      await interaction.reply({ embeds: [embed] });
    }

    if (sub === 'remove') {
      if (!target.roles.cache.has(role.id))
        return interaction.reply({ content: `❌ ${target.user.tag} does not have that role.`, ephemeral: true });
      await target.roles.remove(role);
      const embed = new EmbedBuilder()
        .setColor(0xf59e0b)
        .setTitle('✅ Role Removed')
        .addFields(
          { name: 'Member', value: target.user.tag, inline: true },
          { name: 'Role', value: role.toString(), inline: true },
          { name: 'By', value: interaction.user.tag, inline: true }
        )
        .setTimestamp();
      await interaction.reply({ embeds: [embed] });
    }
  },
};
