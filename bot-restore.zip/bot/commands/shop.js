const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getCoins, addCoins, addToInventory, getInventory } = require('../data/store');

const ROLE_ITEMS = [
  { id: 'vip',     name: '🌟 VIP Role',           price: 5000,  roleToGive: '🌟 VIP',           desc: 'Get the exclusive VIP role & lounge access.' },
  { id: 'gamer',   name: '🎮 Gamer Role',          price: 500,   roleToGive: '🎮 Gamer',         desc: 'Show off the Gamer role.' },
  { id: 'elite',   name: '💜 Elite Role',          price: 2000,  roleToGive: '💜 Elite',         desc: 'Upgrade to Elite status.' },
  { id: 'booster', name: '💎 Server Booster Tag',  price: 1000,  roleToGive: '💎 Server Booster',desc: 'Cosmetic booster role tag.' },
];

const INVENTORY_ITEMS = [
  { id: 'xpboost',    name: '⚡ XP Boost Token',      price: 800,  desc: 'Doubles XP for 1 hour (use in events).' },
  { id: 'luckycharm', name: '🍀 Lucky Charm',         price: 300,  desc: 'Increases slot machine odds slightly.' },
  { id: 'namecolor',  name: '🎨 Custom Name Color',   price: 1500, desc: 'Request a custom role color from admins.' },
  { id: 'vcunlock',   name: '🔊 Private VC Unlock',   price: 2500, desc: 'Get a private voice channel for 24 hours.' },
];

const ALL_ITEMS = [...ROLE_ITEMS, ...INVENTORY_ITEMS];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('shop')
    .setDescription('Browse and buy items with your coins')
    .addSubcommand((sub) => sub.setName('browse').setDescription('Browse the shop'))
    .addSubcommand((sub) =>
      sub.setName('buy').setDescription('Buy an item from the shop')
        .addStringOption((opt) =>
          opt.setName('item').setDescription('Item to buy').setRequired(true)
            .addChoices(
              { name: '🌟 VIP Role — 5,000 coins', value: 'vip' },
              { name: '🎮 Gamer Role — 500 coins', value: 'gamer' },
              { name: '💜 Elite Role — 2,000 coins', value: 'elite' },
              { name: '💎 Server Booster Tag — 1,000 coins', value: 'booster' },
              { name: '⚡ XP Boost Token — 800 coins', value: 'xpboost' },
              { name: '🍀 Lucky Charm — 300 coins', value: 'luckycharm' },
              { name: '🎨 Custom Name Color — 1,500 coins', value: 'namecolor' },
              { name: '🔊 Private VC Unlock — 2,500 coins', value: 'vcunlock' },
            )
        )
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub === 'browse') {
      const { coins } = getCoins(interaction.guild.id, interaction.user.id);
      const embed = new EmbedBuilder()
        .setColor(0xf59e0b)
        .setTitle('🛒 Coin Shop')
        .setDescription(`Your balance: **${coins.toLocaleString()} 💰 coins**\n\nUse \`/shop buy\` to purchase!`)
        .addFields(
          { name: '── Role Items ──', value: '\u200B' },
          ...ROLE_ITEMS.map((i) => ({ name: `${i.name} — ${i.price.toLocaleString()} 💰`, value: i.desc, inline: true })),
          { name: '── Inventory Items ──', value: '\u200B' },
          ...INVENTORY_ITEMS.map((i) => ({ name: `${i.name} — ${i.price.toLocaleString()} 💰`, value: i.desc, inline: true })),
        )
        .setFooter({ text: 'Earn coins via chat, voice, quests, daily & weekly!' })
        .setTimestamp();
      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'buy') {
      const itemId = interaction.options.getString('item');
      const item = ALL_ITEMS.find((i) => i.id === itemId);
      const { coins } = getCoins(interaction.guild.id, interaction.user.id);

      if (coins < item.price) {
        return interaction.reply({ content: `❌ You need **${item.price.toLocaleString()}** coins but only have **${coins.toLocaleString()}**.`, ephemeral: true });
      }

      const isRoleItem = ROLE_ITEMS.find((i) => i.id === itemId);

      if (isRoleItem) {
        const role = interaction.guild.roles.cache.find((r) => r.name === isRoleItem.roleToGive);
        if (!role) return interaction.reply({ content: `❌ Role doesn't exist yet. Run \`/setup\` first!`, ephemeral: true });
        if (interaction.member.roles.cache.has(role.id)) return interaction.reply({ content: `❌ You already have **${item.name}**!`, ephemeral: true });
        addCoins(interaction.guild.id, interaction.user.id, -item.price);
        await interaction.member.roles.add(role);
      } else {
        addCoins(interaction.guild.id, interaction.user.id, -item.price);
        addToInventory(interaction.guild.id, interaction.user.id, item.name);
      }

      const embed = new EmbedBuilder()
        .setColor(0x22c55e)
        .setTitle('✅ Purchase Successful!')
        .addFields(
          { name: 'Item', value: item.name, inline: true },
          { name: 'Cost', value: `${item.price.toLocaleString()} coins`, inline: true },
          { name: 'Remaining Balance', value: `${(coins - item.price).toLocaleString()} coins` },
        )
        .setFooter({ text: isRoleItem ? 'Role applied to your profile!' : 'Item added to your inventory! Use /inventory view to check it.' })
        .setTimestamp();
      return interaction.reply({ embeds: [embed] });
    }
  },
};
