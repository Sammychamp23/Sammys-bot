const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('analytics')
    .setDescription('View server activity analytics and stats'),

  async execute(interaction, client) {
    await interaction.deferReply();

    const { load } = require('../data/store');
    const guildId = interaction.guild.id;

    const economy      = load('economy.json');
    const levels       = load('levels.json');
    const sessionStats = load('session_stats.json');
    const analytics    = load('analytics.json');
    const gData        = analytics[guildId] || {};

    // ── Economy overview ──────────────────────────────────────────────────────
    const econEntries = Object.entries(economy).filter(([k]) => k.startsWith(guildId));
    const totalCoins  = econEntries.reduce((s, [, v]) => s + (v.coins || 0), 0);
    const totalMsgs   = econEntries.reduce((s, [, v]) => s + (v.messagesCount || 0), 0);
    const totalVcMins = econEntries.reduce((s, [, v]) => s + (v.voiceMinutes || 0), 0);

    // ── Level overview ────────────────────────────────────────────────────────
    const levelEntries = Object.entries(levels).filter(([k]) => k.startsWith(guildId));
    const totalXp      = levelEntries.reduce((s, [, v]) => s + (v.xp || 0), 0);
    const maxLevel     = levelEntries.reduce((max, [, v]) => Math.max(max, v.level || 0), 0);

    // ── Session stats ─────────────────────────────────────────────────────────
    const sessEntries    = Object.entries(sessionStats).filter(([k]) => k.startsWith(guildId));
    const totalSessJoins = sessEntries.reduce((s, [, v]) => s + (v.joined || 0), 0);
    const totalSessComps = sessEntries.reduce((s, [, v]) => s + (v.completed || 0), 0);

    // ── Top active members (all-time messages) ────────────────────────────────
    const topMembers = econEntries
      .map(([k, v]) => ({ userId: k.replace(`${guildId}-`, ''), msgs: v.messagesCount || 0 }))
      .sort((a, b) => b.msgs - a.msgs)
      .slice(0, 5);

    const memberLines = [];
    for (let i = 0; i < topMembers.length; i++) {
      const m = await interaction.guild.members.fetch(topMembers[i].userId).catch(() => null);
      const medals = ['🥇', '🥈', '🥉', '4️⃣', '5️⃣'];
      memberLines.push(`${medals[i]} ${m ? m.user.username : 'Unknown'} — **${topMembers[i].msgs.toLocaleString()}** messages`);
    }

    // ── Today's most active channels ─────────────────────────────────────────
    const channelCounts = gData.channelCounts || {};
    const topChannels = Object.entries(channelCounts)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 5);

    const channelLines = [];
    for (const [chId, count] of topChannels) {
      const ch = interaction.guild.channels.cache.get(chId);
      channelLines.push(`${ch ? ch.toString() : `\`${chId}\``} — **${count}** messages today`);
    }

    // ── Peak hour today ───────────────────────────────────────────────────────
    const hourCounts = gData.hourCounts || {};
    const peakEntry  = Object.entries(hourCounts).sort(([, a], [, b]) => b - a)[0];
    let peakHourStr  = 'No data yet';
    if (peakEntry) {
      const h = parseInt(peakEntry[0]);
      const ampm = h >= 12 ? 'PM' : 'AM';
      const h12 = h % 12 || 12;
      peakHourStr = `**${h12}:00 ${ampm} UTC** (${peakEntry[1]} messages)`;
    }

    // ── 7-day trend ───────────────────────────────────────────────────────────
    const weeklyData = gData.weeklyData || [];
    const trendLines = weeklyData
      .slice(-7)
      .map((d) => {
        const bar = '█'.repeat(Math.min(10, Math.ceil((d.messages / Math.max(1, ...weeklyData.map((x) => x.messages))) * 10)));
        return `\`${d.date.slice(0, 6)}\` ${bar} **${d.messages}**`;
      });

    // ── Today's activity ──────────────────────────────────────────────────────
    const todayMsgs = gData.todayMessages || 0;

    // ── Build embeds ──────────────────────────────────────────────────────────
    const embed1 = new EmbedBuilder()
      .setColor(0x6366f1)
      .setTitle(`📊 ${interaction.guild.name} — Server Analytics`)
      .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
      .addFields(
        {
          name: '💬 Messages',
          value: `**Today:** ${todayMsgs.toLocaleString()}\n**All-time:** ${totalMsgs.toLocaleString()}`,
          inline: true,
        },
        {
          name: '🔊 Voice Activity',
          value: `**${totalVcMins.toLocaleString()}** minutes\n*(${Math.floor(totalVcMins / 60).toLocaleString()} hours total)*`,
          inline: true,
        },
        {
          name: '🏆 Leveling',
          value: `**Max Level:** ${maxLevel}\n**Total XP earned:** ${totalXp.toLocaleString()}`,
          inline: true,
        },
        {
          name: '💰 Economy',
          value: `**${totalCoins.toLocaleString()} coins** in circulation\nAcross **${econEntries.length}** members`,
          inline: true,
        },
        {
          name: '🎮 Sessions',
          value: `**${totalSessJoins}** joins · **${totalSessComps}** completed`,
          inline: true,
        },
        {
          name: '⏰ Peak Hour Today',
          value: peakHourStr,
          inline: true,
        },
      )
      .setTimestamp();

    const embed2 = new EmbedBuilder()
      .setColor(0xa855f7)
      .addFields(
        {
          name: '🔥 Most Active Members (All-Time)',
          value: memberLines.length > 0 ? memberLines.join('\n') : 'No data yet',
          inline: false,
        },
        {
          name: '📣 Most Active Channels Today',
          value: channelLines.length > 0 ? channelLines.join('\n') : 'No channel activity tracked yet today',
          inline: false,
        },
        {
          name: '📈 7-Day Message Trend',
          value: trendLines.length > 0 ? trendLines.join('\n') : 'Not enough data yet — check back tomorrow!',
          inline: false,
        },
      )
      .setFooter({ text: 'Analytics reset at midnight UTC • Channel data tracked since last bot restart' });

    await interaction.editReply({ embeds: [embed1, embed2] });
  },
};
