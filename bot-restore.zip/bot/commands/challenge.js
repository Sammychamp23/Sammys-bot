const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getChallenge, setPendingChallenge, clearChallenge, recordChallengeResult, getChallengeLeaderboard, addCoins, getCoins, incrementQuestProgress } = require('../data/store');

const CHALLENGE_COOLDOWN = 30 * 60 * 1000;
const CHALLENGE_WIN_REWARD = 200;

module.exports = {
  data: new SlashCommandBuilder()
    .setName('challenge')
    .setDescription('Challenge another player or view stats')
    .addSubcommand((sub) =>
      sub.setName('send').setDescription('Challenge a user')
        .addUserOption((opt) => opt.setName('user').setDescription('User to challenge').setRequired(true))
    )
    .addSubcommand((sub) => sub.setName('accept').setDescription('Accept an incoming challenge'))
    .addSubcommand((sub) => sub.setName('decline').setDescription('Decline an incoming challenge'))
    .addSubcommand((sub) => sub.setName('stats').setDescription('View your challenge stats')
      .addUserOption((opt) => opt.setName('user').setDescription('User to check (default: you)'))
    )
    .addSubcommand((sub) => sub.setName('leaderboard').setDescription('View the challenge leaderboard')),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;
    const userId = interaction.user.id;

    if (sub === 'send') {
      const target = interaction.options.getUser('user');
      if (target.id === userId) return interaction.reply({ content: '❌ You cannot challenge yourself.', ephemeral: true });
      if (target.bot) return interaction.reply({ content: '❌ You cannot challenge a bot.', ephemeral: true });

      const myStats = getChallenge(guildId, userId);
      if (myStats.pending) return interaction.reply({ content: '❌ You already have a pending challenge. Wait for it to be resolved.', ephemeral: true });

      if (myStats.lastChallenge && Date.now() - myStats.lastChallenge < CHALLENGE_COOLDOWN) {
        const rem = CHALLENGE_COOLDOWN - (Date.now() - myStats.lastChallenge);
        const mins = Math.floor(rem / 60000);
        return interaction.reply({ content: `⏳ Challenge cooldown: **${mins} minutes** remaining.`, ephemeral: true });
      }

      const targetStats = getChallenge(guildId, target.id);
      if (targetStats.incomingChallenge) return interaction.reply({ content: '❌ That user already has a pending challenge.', ephemeral: true });

      setPendingChallenge(guildId, userId, target.id);

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`challenge_accept_${userId}_${target.id}`).setLabel('✅ Accept').setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId(`challenge_decline_${userId}_${target.id}`).setLabel('❌ Decline').setStyle(ButtonStyle.Danger),
      );

      const embed = new EmbedBuilder()
        .setColor(0xef4444)
        .setTitle('⚔️ Challenge Issued!')
        .setDescription(`${interaction.user} has challenged ${target} to a duel!\n\n${target}, do you accept?\n\n🏆 Winner earns **${CHALLENGE_WIN_REWARD} coins**!`)
        .addFields(
          { name: `${interaction.user.username} Stats`, value: `W: **${myStats.wins}** | L: **${myStats.losses}**`, inline: true },
          { name: `${target.username} Stats`, value: `W: **${targetStats.wins}** | L: **${targetStats.losses}**`, inline: true },
        )
        .setFooter({ text: 'Challenge expires in 5 minutes.' })
        .setTimestamp();

      const msg = await interaction.reply({ embeds: [embed], components: [row], fetchReply: true });

      const collector = msg.createMessageComponentCollector({ time: 300_000 });

      collector.on('collect', async (btn) => {
        const [, action, challengerId, targetId] = btn.customId.split('_');
        if (btn.user.id !== targetId) return btn.reply({ content: '❌ This challenge is not for you.', ephemeral: true });

        collector.stop();

        if (action === 'decline') {
          clearChallenge(guildId, challengerId, targetId);
          const declinedEmbed = EmbedBuilder.from(embed).setColor(0x6b7280).setTitle('❌ Challenge Declined');
          return btn.update({ embeds: [declinedEmbed], components: [] });
        }

        if (action === 'accept') {
          clearChallenge(guildId, challengerId, targetId);
          const winner = Math.random() < 0.5 ? challengerId : targetId;
          const loser = winner === challengerId ? targetId : challengerId;
          recordChallengeResult(guildId, winner, loser, CHALLENGE_WIN_REWARD);
          addCoins(guildId, winner, CHALLENGE_WIN_REWARD);

          incrementQuestProgress(guildId, winner, 'wins', 1);

          const winnerUser = await interaction.guild.members.fetch(winner).catch(() => null);
          const loserUser = await interaction.guild.members.fetch(loser).catch(() => null);

          const winnerStats = getChallenge(guildId, winner);
          const loserStats = getChallenge(guildId, loser);

          const resultEmbed = new EmbedBuilder()
            .setColor(0xf59e0b)
            .setTitle('⚔️ Challenge Result!')
            .setDescription(`🏆 **${winnerUser?.user.username ?? 'Winner'}** defeated **${loserUser?.user.username ?? 'Loser'}**!\n\n+**${CHALLENGE_WIN_REWARD} coins** awarded to the winner!`)
            .addFields(
              { name: `${winnerUser?.user.username ?? 'Winner'} Record`, value: `W: **${winnerStats.wins}** | L: **${winnerStats.losses}**`, inline: true },
              { name: `${loserUser?.user.username ?? 'Loser'} Record`, value: `W: **${loserStats.wins}** | L: **${loserStats.losses}**`, inline: true },
            )
            .setFooter({ text: 'Stats updated!' })
            .setTimestamp();

          return btn.update({ embeds: [resultEmbed], components: [] });
        }
      });

      collector.on('end', (_, reason) => {
        if (reason === 'time') {
          clearChallenge(guildId, userId, target.id);
          msg.edit({ components: [] }).catch(() => {});
        }
      });
    }

    if (sub === 'accept' || sub === 'decline') {
      const myStats = getChallenge(guildId, userId);
      if (!myStats.incomingChallenge) {
        return interaction.reply({ content: '❌ You have no incoming challenge.', ephemeral: true });
      }
      return interaction.reply({ content: '💡 Use the Accept/Decline buttons on the original challenge message.', ephemeral: true });
    }

    if (sub === 'stats') {
      const target = interaction.options.getUser('user') ?? interaction.user;
      const stats = getChallenge(guildId, target.id);
      const total = stats.wins + stats.losses;
      const wr = total > 0 ? Math.round((stats.wins / total) * 100) : 0;
      const embed = new EmbedBuilder()
        .setColor(0x6366f1)
        .setTitle(`⚔️ ${target.username}'s Challenge Stats`)
        .setThumbnail(target.displayAvatarURL())
        .addFields(
          { name: '🏆 Wins', value: `**${stats.wins}**`, inline: true },
          { name: '💀 Losses', value: `**${stats.losses}**`, inline: true },
          { name: '📊 Win Rate', value: `**${wr}%**`, inline: true },
          { name: '💰 Coins Won', value: `**${(stats.coinsWon || 0).toLocaleString()}**`, inline: true },
        )
        .setTimestamp();
      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'leaderboard') {
      const board = getChallengeLeaderboard(guildId);
      const lines = await Promise.all(
        board.map(async (entry, i) => {
          const user = await interaction.client.users.fetch(entry.userId).catch(() => null);
          const name = user?.username ?? 'Unknown';
          const medals = ['🥇', '🥈', '🥉'];
          return `${medals[i] ?? `**${i + 1}.**`} ${name} — **${entry.wins}W** / ${entry.losses}L | ${(entry.coinsWon || 0).toLocaleString()} 💰 earned`;
        })
      );
      const embed = new EmbedBuilder()
        .setColor(0xef4444)
        .setTitle('⚔️ Challenge Leaderboard')
        .setDescription(lines.join('\n') || 'No challenges yet!')
        .setTimestamp();
      return interaction.reply({ embeds: [embed] });
    }
  },
};
