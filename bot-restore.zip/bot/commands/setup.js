const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
  ChannelType,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setup')
    .setDescription('Set up the server with channels, categories, and roles for a gaming server')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    await interaction.deferReply();

    const guild = interaction.guild;

    try {
      // ── Roles ──────────────────────────────────────────────────────────────
      const roleData = [
        // Staff
        { name: '👑 Owner',              color: 0xf59e0b, hoist: true  },
        { name: '⚔️ Co-Owner',           color: 0xf97316, hoist: true  },
        { name: '🔴 Admin',              color: 0xef4444, hoist: true  },
        { name: '🛡️ Moderator',          color: 0x3b82f6, hoist: true  },
        { name: '🔨 Trial Moderator',    color: 0x60a5fa, hoist: true  },
        { name: '🤝 Helper',             color: 0x38bdf8, hoist: true  },
        // Special
        { name: '🤖 Bot',               color: 0x64748b, hoist: false },
        { name: '💎 Server Booster',    color: 0xf472b6, hoist: true  },
        { name: '🌟 VIP',               color: 0xa855f7, hoist: true  },
        { name: '🎉 Giveaway Winner',   color: 0xfbbf24, hoist: false },
        // Member levels
        { name: '🏆 Legend',            color: 0xf59e0b, hoist: true  },
        { name: '💜 Elite',             color: 0x8b5cf6, hoist: true  },
        { name: '🎮 Gamer',             color: 0x22c55e, hoist: true  },
        { name: '🆕 Member',            color: 0x6b7280, hoist: true  },
        // Platform roles
        { name: '🖥️ PC',               color: 0x0ea5e9, hoist: false },
        { name: '🎮 PlayStation',       color: 0x003087, hoist: false },
        { name: '🟢 Xbox',             color: 0x107c10, hoist: false },
        { name: '📱 Mobile',            color: 0x6366f1, hoist: false },
        { name: '🔴 Nintendo Switch',   color: 0xe4000f, hoist: false },
        // Game roles
        { name: '🔫 Fortnite',          color: 0x9333ea, hoist: false },
        { name: '⚡ Valorant',          color: 0xff4655, hoist: false },
        { name: '🔲 Minecraft',         color: 0x5b8731, hoist: false },
        { name: '💣 Call of Duty',      color: 0x4b5320, hoist: false },
        { name: '🏃 Apex Legends',      color: 0xda292a, hoist: false },
        { name: '🌍 GTA V',             color: 0x2563eb, hoist: false },
        { name: '🔵 Roblox',            color: 0xe2231a, hoist: false },
        { name: '🗡️ League of Legends', color: 0xc89b3c, hoist: false },
        { name: '💀 Warzone',           color: 0x374151, hoist: false },
        { name: '🎯 Overwatch 2',       color: 0xf99e1a, hoist: false },
        { name: '⚽ Rocket League',     color: 0x1a6ef9, hoist: false },
        { name: '🕷️ Dead by Daylight',  color: 0x8b0000, hoist: false },
        // Path roles
        { name: '🎮 Casual',            color: 0x22c55e, hoist: false },
        { name: '⚔️ Competitive',       color: 0xef4444, hoist: false },
        { name: '🎬 Content Creator',   color: 0xa855f7, hoist: false },
        { name: '💹 Trader',            color: 0xf59e0b, hoist: false },
        // Seasonal / achievement roles
        { name: '🥇 Seasonal Champion', color: 0xf59e0b, hoist: true  },
        { name: '🥈 Elite Rival',       color: 0x9ca3af, hoist: false },
        { name: '🥉 Season Veteran',    color: 0xb45309, hoist: false },
        { name: '🤝 Trusted',           color: 0x10b981, hoist: false },
        // Ping roles
        { name: '📣 Announcements',     color: 0xfbbf24, hoist: false },
        { name: '🎉 Giveaways',         color: 0xec4899, hoist: false },
        { name: '🎮 Game Night',        color: 0x10b981, hoist: false },
        { name: '📺 Stream Pings',      color: 0x7c3aed, hoist: false },
        { name: '🔔 Event Pings',       color: 0xf59e0b, hoist: false },
        // Verification roles
        { name: '🔐 Unverified',        color: 0x6b7280, hoist: false },
        { name: '✅ Verified',           color: 0x22c55e, hoist: false },
      ];

      const createdRoles = {};
      for (const r of roleData) {
        const existing = guild.roles.cache.find((role) => role.name === r.name);
        const role = existing ?? await guild.roles.create({ name: r.name, color: r.color, hoist: r.hoist });
        createdRoles[r.name] = role;
      }

      const everyoneRole = guild.roles.everyone;
      const staffRoleNames = ['👑 Owner', '⚔️ Co-Owner', '🔴 Admin', '🛡️ Moderator', '🔨 Trial Moderator', '🤝 Helper'];
      const staffRoles = staffRoleNames
        .map((n) => guild.roles.cache.find((r) => r.name === n))
        .filter(Boolean);

      const verifiedRole = createdRoles['✅ Verified'];

      // ── Permission preset builders ─────────────────────────────────────────
      // Anyone without ✅ Verified is locked out of everything except #verify.
      // @everyone is denied ViewChannel on all member channels.

      const staffOnly = [
        { id: everyoneRole.id, deny: ['ViewChannel'] },
        ...staffRoles.map((r) => ({ id: r.id, allow: ['ViewChannel', 'SendMessages', 'ReadMessageHistory'] })),
      ];

      // Read-only for members (announcements, rules, etc.)
      const readOnly = [
        { id: everyoneRole.id, deny: ['ViewChannel', 'SendMessages'] },
        ...(verifiedRole ? [{ id: verifiedRole.id, allow: ['ViewChannel', 'ReadMessageHistory'], deny: ['SendMessages'] }] : []),
        ...staffRoles.map((r) => ({ id: r.id, allow: ['ViewChannel', 'SendMessages', 'ReadMessageHistory', 'ManageMessages'] })),
      ];

      // Verify-only: @everyone CAN see this channel (it's the only one they can see)
      const verifyOnly = [
        { id: everyoneRole.id, allow: ['ViewChannel', 'ReadMessageHistory'], deny: ['SendMessages'] },
        ...staffRoles.map((r) => ({ id: r.id, allow: ['ViewChannel', 'SendMessages', 'ReadMessageHistory', 'ManageMessages'] })),
      ];

      // ── Helper: find or create channel ────────────────────────────────────
      async function makeCategory(name, channels, categoryOverwrites = []) {
        const existingCat = guild.channels.cache.find(
          (c) => c.type === ChannelType.GuildCategory && c.name === name
        );

        let category;
        if (existingCat) {
          category = existingCat;
          if (categoryOverwrites.length) {
            await category.permissionOverwrites.set(categoryOverwrites).catch(console.error);
          }
        } else {
          category = await guild.channels.create({
            name,
            type: ChannelType.GuildCategory,
            permissionOverwrites: categoryOverwrites,
          });
        }

        const results = [];
        for (const ch of channels) {
          const existing = guild.channels.cache.find(
            (c) => c.name === ch.name && c.parentId === category.id
          );
          const channelOverwrites = ch.overwrites ?? (categoryOverwrites.length ? categoryOverwrites : undefined);
          let channel;
          if (existing) {
            channel = existing;
            if (channelOverwrites) {
              await existing.permissionOverwrites.set(channelOverwrites).catch(console.error);
            }
          } else {
            channel = await guild.channels.create({
              name: ch.name,
              type: ch.voice ? ChannelType.GuildVoice : ChannelType.GuildText,
              parent: category.id,
              topic: ch.topic ?? null,
              permissionOverwrites: channelOverwrites,
            });
          }
          results.push({ channel, seed: ch.seed, isNew: !existing });
        }
        return results;
      }

      // ── Seed message helper — always updates existing messages ───────────
      async function seedOrUpdate(channel, embedData, components) {
        if (!channel || channel.isVoiceBased()) return null;
        try {
          const messages = await channel.messages.fetch({ limit: 10 });
          const botMsgs = messages.filter((m) => m.author.id === guild.members.me.id);
          const payload = { embeds: [new EmbedBuilder(embedData)], components: components ? [components] : [] };
          if (botMsgs.size > 0) {
            const latest = botMsgs.first();
            return await latest.edit(payload).catch(() => null);
          }
          return await channel.send(payload).catch(() => null);
        } catch { return null; }
      }

      // ── Categories & Channels ─────────────────────────────────────────────

      // Open to verified members only — @everyone denied, Verified allowed
      const memberOpen = [
        { id: everyoneRole.id, deny: ['ViewChannel'] },
        ...(verifiedRole ? [{ id: verifiedRole.id, allow: ['ViewChannel', 'SendMessages', 'ReadMessageHistory'] }] : []),
        ...staffRoles.map((r) => ({ id: r.id, allow: ['ViewChannel', 'SendMessages', 'ReadMessageHistory', 'ManageMessages'] })),
      ];

      // INFORMATION — read-only for members; staff can post
      const infoChannels = await makeCategory('📢 INFORMATION', [
        { name: '🔐verify',        topic: 'Verify here to unlock the server.',                           overwrites: verifyOnly },
        { name: '📜rules',         topic: 'Read and follow the server rules.',                           overwrites: readOnly },
        { name: '📣announcements', topic: 'Server announcements and updates.',                           overwrites: readOnly },
        { name: '👋welcome',       topic: 'Welcome new members!',                                        overwrites: readOnly },
        { name: '🗺️roles',         topic: 'Assign yourself roles here.',                                 overwrites: readOnly },
        { name: '📋commands',      topic: 'All member commands explained. Run /guide to refresh this.',  overwrites: readOnly },
      ]);

      // GENERAL — verified members can talk
      const generalChannels = await makeCategory('💬 GENERAL', [
        { name: '💬general',      topic: 'General chat for everything.' },
        { name: '🤣memes',        topic: 'Post your best memes here.' },
        { name: '📸media',        topic: 'Share screenshots, clips, and art.' },
        { name: '🔗links',        topic: 'Share useful links and resources.' },
      ], memberOpen);

      // GAMING — verified members can talk
      const gamingChannels = await makeCategory('🎮 GAMING', [
        { name: '🎮game-chat',        topic: 'Talk about any game.' },
        { name: '🏆clips-highlights', topic: 'Share your best gaming moments.' },
        { name: '🔍lfg',             topic: 'Looking for group? Post here.' },
        { name: '🗳️game-polls',       topic: 'Vote on games to play together.', overwrites: readOnly },
        { name: '🎁giveaways',        topic: 'Giveaways! Enter with the button.' },
      ], memberOpen);

      // BOT COMMANDS — verified members can use
      const botChannels = await makeCategory('🤖 BOT COMMANDS', [
        { name: '🤖bot-commands',    topic: 'Use bot commands here.' },
        { name: '🎵music-commands',  topic: 'Use music bot commands here.' },
      ], memberOpen);

      // VOICE CHANNELS — verified members only
      await makeCategory('🔊 VOICE CHANNELS', [
        { name: '🎮 Gaming Lounge',  voice: true },
        { name: '🏆 Competitive',    voice: true },
        { name: '💬 Chill Zone',     voice: true },
        { name: '🎵 Music Room',     voice: true },
        { name: '📺 Stream Room',    voice: true },
        { name: '🔕 AFK',           voice: true },
      ], memberOpen);

      // STAFF ONLY — completely hidden from regular members
      await makeCategory('🔒 STAFF ONLY', [
        { name: '🛡️staff-chat',  topic: 'Private staff discussion.' },
        { name: '📋mod-log',     topic: 'Moderation action log.' },
        { name: '🚨reports',     topic: 'User reports go here.' },
        { name: '📊admin-stats', topic: 'Server analytics and growth tracking.' },
      ], staffOnly);

      // LEVELS & ECONOMY — verified members can use (same lock as memberOpen)
      const everyoneOpen = [
        { id: everyoneRole.id, deny: ['ViewChannel'] },
        ...(verifiedRole ? [{ id: verifiedRole.id, allow: ['ViewChannel', 'SendMessages', 'ReadMessageHistory'] }] : []),
        ...staffRoles.map((r) => ({ id: r.id, allow: ['ViewChannel', 'SendMessages', 'ReadMessageHistory', 'ManageMessages'] })),
      ];
      const levelChannels = await makeCategory('⭐ LEVELS & ECONOMY', [
        { name: '📈levels',      topic: 'Level up announcements and XP chat.' },
        { name: '💰coin-shop',   topic: 'Use /coins daily, /shop browse, /inventory view.' },
        { name: '🏆challenges',  topic: 'Challenge players with /challenge send.' },
        { name: '🎯quests',      topic: 'Daily & weekly quests. Use /quests view and /quests claim.' },
        { name: '🏅season',      topic: 'Seasonal leaderboard. Use /season info and /season top.' },
        { name: '💡suggestions', topic: 'Submit suggestions with /suggest.' },
      ], everyoneOpen);

      // COMMUNITY — verified members can use
      const communityChannels = await makeCategory('🎭 COMMUNITY', [
        { name: '🛤️path-lounge',  topic: 'Hang out based on your path. Use /path choose.' },
        { name: '🏪marketplace',  topic: 'Player marketplace. Use /marketplace list, browse, buy.' },
        { name: '🎬content',      topic: 'Share clips and content. Use /content submit.' },
        { name: '📲social',       topic: 'Share your TikToks, YouTube clips and invite friends!' },
      ], memberOpen);

      // VIP lounge — only visible to VIP role
      const vipRole = guild.roles.cache.find((r) => r.name === '🌟 VIP');
      const existingVipCat = guild.channels.cache.find(
        (c) => c.type === ChannelType.GuildCategory && c.name === '💎 VIP LOUNGE'
      );
      const vipCategory = existingVipCat ?? await guild.channels.create({
        name: '💎 VIP LOUNGE',
        type: ChannelType.GuildCategory,
        permissionOverwrites: [
          { id: everyoneRole.id, deny: ['ViewChannel'] },
          ...(vipRole ? [{ id: vipRole.id, allow: ['ViewChannel'] }] : []),
        ],
      });

      const vipChannelDefs = [
        { name: '💎vip-lounge', topic: 'Exclusive chat for VIP members.' },
        { name: '🎁vip-perks',  topic: 'VIP-only giveaways and perks.' },
      ];
      const vipResults = [];
      for (const ch of vipChannelDefs) {
        const existing = guild.channels.cache.find((c) => c.name === ch.name && c.parentId === vipCategory.id);
        let channel;
        if (!existing) {
          channel = await guild.channels.create({
            name: ch.name,
            type: ChannelType.GuildText,
            parent: vipCategory.id,
            topic: ch.topic,
            permissionOverwrites: [
              { id: everyoneRole.id, deny: ['ViewChannel'] },
              ...(vipRole ? [{ id: vipRole.id, allow: ['ViewChannel'] }] : []),
            ],
          });
        } else {
          channel = existing;
        }
        vipResults.push({ channel, isNew: !existing });
      }

      // Temp voice room creator
      const voiceCat = guild.channels.cache.find(
        (c) => c.type === ChannelType.GuildCategory && c.name === '🔊 VOICE CHANNELS'
      );
      if (voiceCat) {
        const existingCreateRoom = guild.channels.cache.find((c) => c.name === '➕ Create a Room');
        if (!existingCreateRoom) {
          await guild.channels.create({
            name: '➕ Create a Room',
            type: ChannelType.GuildVoice,
            parent: voiceCat.id,
            permissionOverwrites: memberOpen,
          });
        } else {
          await existingCreateRoom.permissionOverwrites.set(memberOpen).catch(console.error);
        }
      }

      // ── Seed initial messages into each channel ───────────────────────────

      // Helper to find channel by name from a result set
      function findCh(results, name) {
        return results.find((r) => r.channel.name === name)?.channel ?? null;
      }

      // 🔐 verify — reaction role, always refreshed
      const verifyChannel = findCh(infoChannels, '🔐verify');
      let verifyMsg = null;
      if (verifyChannel && !verifyChannel.isVoiceBased()) {
        try {
          const recentMsgs = await verifyChannel.messages.fetch({ limit: 10 });
          const botMsgs = recentMsgs.filter((m) => m.author.id === guild.members.me.id);
          // Delete all old bot messages so we get a clean slate
          for (const msg of botMsgs.values()) await msg.delete().catch(() => {});
          verifyMsg = await verifyChannel.send({
            embeds: [new EmbedBuilder({
              color: 0x22c55e,
              title: `Welcome to ${guild.name}`,
              description:
                'Before you can access the server, please read and agree to the rules below.\n\n' +
                '```\n' +
                '1. Treat everyone with respect.\n' +
                '2. No spamming or flooding any channel.\n' +
                '3. No NSFW content — anywhere.\n' +
                '4. No advertising without staff permission.\n' +
                '5. Follow Discord\'s Terms of Service.\n' +
                '6. Staff decisions are final.\n' +
                '```\n\n' +
                '> React with ✅ below to agree and unlock the server.',
              footer: { text: 'By verifying you agree to abide by all server rules.' },
            })],
          }).catch(() => null);
          if (verifyMsg) await verifyMsg.react('✅').catch(() => {});
        } catch { /* skip */ }
      }

      // 📜 rules
      await seedOrUpdate(findCh(infoChannels, '📜rules'), {
        color: 0xef4444,
        title: 'Server Rules',
        description:
          'All members are expected to follow these rules at all times.\n\n' +
          '```\n' +
          '1. Respect everyone — no harassment, hate speech, or bullying.\n' +
          '2. No spamming, flooding, or excessive pinging.\n' +
          '3. Keep content in the correct channels.\n' +
          '4. No NSFW content anywhere in this server.\n' +
          '5. No advertising without staff permission.\n' +
          '6. Do not share personal information of others.\n' +
          '7. Follow Discord\'s Terms of Service and Community Guidelines.\n' +
          '8. Staff decisions are final.\n' +
          '```\n\n' +
          '> Violations may result in warnings, mutes, kicks, or permanent bans.',
        footer: { text: 'Last updated by Server Staff' },
      });

      // 📣 announcements
      await seedOrUpdate(findCh(infoChannels, '📣announcements'), {
        color: 0xf59e0b,
        title: 'Announcements',
        description:
          'All server news, events, and updates are posted here.\n\n' +
          '> Use `/role add 📣 Announcements` to get pinged whenever something is posted.',
        footer: { text: 'Stay tuned for events, giveaways, and updates.' },
      });

      // 👋 welcome
      const rulesChannel = findCh(infoChannels, '📜rules');
      const rolesChannel = findCh(infoChannels, '🗺️roles');
      const welcomeRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId('welcome_daily')
          .setLabel('💰 Claim Daily Reward')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('welcome_invite')
          .setLabel('📲 Invite Friends')
          .setStyle(ButtonStyle.Primary),
      );
      await seedOrUpdate(findCh(infoChannels, '👋welcome'), {
        color: 0x22c55e,
        title: `Welcome to ${guild.name}`,
        description:
          `A gaming community built for players who love to compete, chill, and grow together.\n\n` +
          `**Getting started**\n` +
          `1. Read the rules in ${rulesChannel ?? '#📜rules'}\n` +
          `2. Grab your roles in ${rolesChannel ?? '#🗺️roles'}\n` +
          `3. Claim your daily coins with \`/coins daily\`\n` +
          `4. Invite friends with \`/invite link\` and earn rewards\n\n` +
          `> You start with **100 coins + 50 XP**. Every message earns more.`,
        footer: { text: `${guild.name} · Glad to have you here` },
      }, welcomeRow);

      // 🗺️ roles
      await seedOrUpdate(findCh(infoChannels, '🗺️roles'), {
        color: 0x6366f1,
        title: 'Role Assignment',
        description:
          'Use `/role add <name>` to assign yourself any role below.\n\n' +
          '**Platform**\n`🖥️ PC`  `🎮 PlayStation`  `🟢 Xbox`  `📱 Mobile`  `🔴 Nintendo Switch`\n\n' +
          '**Games**\n`🔫 Fortnite`  `⚡ Valorant`  `🔲 Minecraft`  `💣 Call of Duty`  `🏃 Apex Legends`\n`🌍 GTA V`  `🔵 Roblox`  `🗡️ League of Legends`  `💀 Warzone`  `🎯 Overwatch 2`\n`⚽ Rocket League`  `🕷️ Dead by Daylight`\n\n' +
          '**Path**\n`🎮 Casual`  `⚔️ Competitive`  `🎬 Content Creator`  `💹 Trader`\n\n' +
          '**Ping Roles**\n`📣 Announcements`  `🎉 Giveaways`  `🎮 Game Night`  `📺 Stream Pings`  `🔔 Event Pings`\n\n' +
          '> You can hold multiple roles at once.',
        footer: { text: 'Type /role add followed by the role name' },
      });

      // 📋 commands
      await seedOrUpdate(findCh(infoChannels, '📋commands'), {
        color: 0x0ea5e9,
        title: 'Member Commands',
        description:
          '```\n💰 ECONOMY\n' +
          '/coins daily          Claim your daily reward\n' +
          '/coins weekly         Claim your weekly bonus\n' +
          '/coins balance        Check your wallet\n' +
          '/coins give @user     Send coins to someone\n' +
          '/shop browse          Browse the item shop\n' +
          '/inventory            View your owned items\n' +
          '```\n' +
          '```\n⭐ LEVELS & PROFILE\n' +
          '/rank                 View your XP and level\n' +
          '/stats leaderboard    Server leaderboard\n' +
          '/stats richest        Richest members\n' +
          '/streak               View your login streak\n' +
          '/profile              Your full profile\n' +
          '/rep give @user       Give someone reputation\n' +
          '```\n' +
          '```\n🎯 QUESTS & CHALLENGES\n' +
          '/quests view          See active quests\n' +
          '/quests claim         Claim quest rewards\n' +
          '/challenge send @user Challenge a member\n' +
          '/challenge accept     Accept a challenge\n' +
          '```\n' +
          '```\n🎲 GAMBLING & GAMES\n' +
          '/gamble spin          Spin the wheel\n' +
          '/gamble doubleornothing  Double or nothing\n' +
          '/minigames coinflip   Flip a coin\n' +
          '/minigames slots      Pull the slots\n' +
          '/minigames duel @user Duel another member\n' +
          '```\n' +
          '```\n🤝 SOCIAL & SQUADS\n' +
          '/squad create/join/leave/info\n' +
          '/invite link          Get your invite link\n' +
          '/suggest <idea>       Submit a suggestion\n' +
          '/lfg                  Post a LFG ad\n' +
          '```\n' +
          '```\n🏪 MARKET & EXTRAS\n' +
          '/auction create/bid/view\n' +
          '/roleshop browse/buy\n' +
          '/season info/top\n' +
          '/8ball  /wouldyourather  /tip  /userinfo\n' +
          '```\n\n' +
          '> Use `/guide` for a full breakdown of every command.',
        footer: { text: 'Run commands in #🤖bot-commands' },
      });

      // 💬 general
      await seedOrUpdate(findCh(generalChannels, '💬general'), {
        color: 0x10b981,
        title: 'General Chat',
        description:
          'The main hub — talk about anything and everything here.\n\n' +
          '> Every message you send earns XP and coins. Keep it friendly and on-topic.',
        footer: { text: 'Chat to level up and earn rewards' },
      });

      // 🤣 memes
      await seedOrUpdate(findCh(generalChannels, '🤣memes'), {
        color: 0xf59e0b,
        title: 'Meme Zone',
        description:
          'Post your best gaming memes here — the funnier the better.\n\n' +
          '> Keep it clean. React 😂 to vote for your favourites.',
        footer: { text: 'All levels of dankness accepted.' },
      });

      // 📸 media
      await seedOrUpdate(findCh(generalChannels, '📸media'), {
        color: 0xa855f7,
        title: 'Media Gallery',
        description:
          'Share screenshots, clips, fan art, and setup photos here.\n\n' +
          '> Use `/content submit` to officially enter your content for staff features.',
        footer: { text: 'Show us what you\'ve got' },
      });

      // 🔗 links
      await seedOrUpdate(findCh(generalChannels, '🔗links'), {
        color: 0x38bdf8,
        title: 'Useful Links',
        description:
          'Share game guides, wikis, tutorials, and community resources here.\n\n' +
          '> No self-promotion or advertising without staff permission.',
        footer: { text: 'Keep it relevant and helpful' },
      });

      // 🎮 game-chat
      await seedOrUpdate(findCh(gamingChannels, '🎮game-chat'), {
        color: 0x22c55e,
        title: 'Game Chat',
        description:
          'Talk about any game, any platform, any genre.\n\n' +
          '> Share your rank, ask for tips, discuss upcoming releases — all games welcome.',
        footer: { text: 'What are you grinding right now?' },
      });

      // 🏆 clips-highlights
      await seedOrUpdate(findCh(gamingChannels, '🏆clips-highlights'), {
        color: 0xf59e0b,
        title: 'Clips & Highlights',
        description:
          'Post your best gaming moments — insane plays, funny fails, win screens, ace rounds.\n\n' +
          '> Most reacted clip each week gets featured in announcements and earns **500 bonus coins**.',
        footer: { text: 'React 🏆 to vote for your favourite clip' },
      });

      // 🔍 lfg
      await seedOrUpdate(findCh(gamingChannels, '🔍lfg'), {
        color: 0x6366f1,
        title: 'Looking for Group',
        description:
          'Need teammates? Use `/lfg` to post your ad with your game, rank, and requirements.\n\n' +
          '```\nExample\nGame:  Valorant\nRank:  Gold\nNeed:  2 players\nTime:  Tonight 8PM EST\n```\n\n' +
          '> React ✅ to join someone\'s group.',
        footer: { text: 'Find your squad and dominate' },
      });

      // 🗳️ game-polls
      await seedOrUpdate(findCh(gamingChannels, '🗳️game-polls'), {
        color: 0xec4899,
        title: 'Game Polls',
        description:
          'Staff post official polls here — react with the matching emoji to cast your vote.\n\n' +
          '> Members cannot post here. New polls go up weekly.',
        footer: { text: 'Your vote shapes what we play next' },
      });

      // 🎁 giveaways
      await seedOrUpdate(findCh(gamingChannels, '🎁giveaways'), {
        color: 0xfbbf24,
        title: 'Giveaways',
        description:
          'Game codes, in-game items, coins, and more — all posted here by staff.\n\n' +
          '**How to enter** — click the Enter button before time runs out.\n\n' +
          '**Earn bonus entries by:**\n— Having the `🎉 Giveaways` ping role\n— Being a high-level member\n— Boosting the server\n\n' +
          '> Use `/role add 🎉 Giveaways` to get notified.',
        footer: { text: 'Good luck 🍀' },
      });

      // 🤖 bot-commands
      await seedOrUpdate(findCh(botChannels, '🤖bot-commands'), {
        color: 0x64748b,
        title: 'Bot Commands',
        description:
          'Use all bot commands here — keep other channels clean.\n\n' +
          '**Quick start**\n`/coins daily` — Free coins every day\n`/rank` — Your XP and level\n`/8ball <question>` — Ask the magic 8-ball\n`/wouldyourather` — Quick mini game\n`/tip` — Random gaming tip\n\n' +
          '> See <#' + (findCh(infoChannels, '📋commands')?.id ?? '0') + '> for the full command list.\n\n' +
          '> Mystery Drops appear here randomly — be first to claim them.',
        footer: { text: 'Most commands only work in this channel' },
      });

      // 🎵 music-commands
      await seedOrUpdate(findCh(botChannels, '🎵music-commands'), {
        color: 0x7c3aed,
        title: '🎵 Music Lounge',
        description:
          'Hop into **🎵 Music Room** and use your favourite music bot to play tunes for everyone.\n\n' +
          '**Recommended bots**\n> 🎶 **Hydra** — `hydra.bot`\n> 🎵 **Jockie Music** — supports Spotify, YouTube & more\n> 🤖 **MEE6** — `/play` command built in\n\n' +
          '> Add one of the bots above and use their commands here.',
        footer: { text: '🎵 Music Room voice channel is reserved for listening sessions' },
      });

      // 📈 levels
      await seedOrUpdate(findCh(levelChannels, '📈levels'), {
        color: 0xf59e0b,
        title: 'Level Up Board',
        description:
          'Track your progress and celebrate level-ups here.\n\n' +
          '**How XP works**\n— Chat in any channel → **+15–25 XP** per message *(1 min cooldown)*\n— Time in voice channels → **+2 coins per minute**\n— Challenges and quests → bonus XP\n\n' +
          '**Level milestones**\n`Level 5` → 🎮 Gamer\n`Level 10` → 💜 Elite\n`Level 20` → 🏆 Legend\n\n' +
          '> Check your level anytime with `/rank` in <#' + (findCh(botChannels, '🤖bot-commands')?.id ?? '0') + '>.',
        footer: { text: 'Who\'s the highest ranked member?' },
      });

      // 💰 coin-shop
      await seedOrUpdate(findCh(levelChannels, '💰coin-shop'), {
        color: 0xfbbf24,
        title: 'Economy & Coin Shop',
        description:
          'Earn coins through activity and spend them on items, roles, and perks.\n\n' +
          '**Commands**\n`/coins daily` — Daily reward *(streak bonuses apply)*\n`/coins balance` — Check your wallet\n`/shop browse` — Browse available items\n`/shop buy <item>` — Purchase an item\n`/inventory` — View owned items\n\n' +
          '**How to earn coins**\n— Chatting → **+5–10** per message\n— Voice activity → **+2** per minute\n— Mystery drops, streaks, and invites\n\n' +
          '> Start with `/coins daily` for your first free reward.',
        footer: { text: 'Economy resets each season — spend wisely' },
      });

      // 🏆 challenges
      await seedOrUpdate(findCh(levelChannels, '🏆challenges'), {
        color: 0xef4444,
        title: 'Challenges',
        description:
          'Challenge other members and put your coins on the line.\n\n' +
          '`/challenge send @user <wager>` — Send a challenge\n`/challenge accept` — Accept one\n`/challenge complete` — Mark it done and claim your winnings\n\n' +
          '> Staff verify results for large wagers. Keep it fair.',
        footer: { text: 'Winner takes the pot' },
      });

      // 🎯 quests
      await seedOrUpdate(findCh(levelChannels, '🎯quests'), {
        color: 0x10b981,
        title: 'Daily & Weekly Quests',
        description:
          'Complete quests to earn bonus XP and coins on top of your regular activity.\n\n' +
          '`/quests view` — See your active quests\n`/quests claim` — Claim completed rewards\n\n' +
          '**Quest types:** Messages sent · Voice minutes · Challenge wins\n\n' +
          '> Quests reset daily and weekly. Log in every day to stack rewards.',
        footer: { text: 'Consistent players earn the most' },
      });

      // 🏅 season
      await seedOrUpdate(findCh(levelChannels, '🏅season'), {
        color: 0xa855f7,
        title: 'Season Leaderboard',
        description:
          'Compete for the top spot every month.\n\n' +
          '`/season info` — Current season details\n`/season top` — View the leaderboard\n\n' +
          '**Top 3 rewards at season end**\n🥇 1st — Seasonal Champion role + 5,000 coins\n🥈 2nd — Elite Rival role + 2,500 coins\n🥉 3rd — Season Veteran role + 1,000 coins\n\n' +
          '> Seasons reset on the 1st of every month.',
        footer: { text: 'Can you reach the top this season?' },
      });

      // 💡 suggestions
      await seedOrUpdate(findCh(levelChannels, '💡suggestions'), {
        color: 0x0ea5e9,
        title: 'Suggestions',
        description:
          'Have an idea to improve the server? We want to hear it.\n\n' +
          '`/suggest <your idea>` — Submit a suggestion\n\n' +
          '> Staff review everything and react ✅ or ❌. Upvoted ideas get priority.',
        footer: { text: 'Your feedback shapes this server' },
      });

      // 🛤️ path-lounge
      await seedOrUpdate(findCh(communityChannels, '🛤️path-lounge'), {
        color: 0x22c55e,
        title: 'Path Lounge',
        description:
          'Connect with members who share your playstyle.\n\n' +
          '`/path choose` — Pick your path to unlock your lounge.\n\n' +
          '**Paths available**\n🎮 Casual — Gaming for fun, no pressure\n⚔️ Competitive — Grinding ranks\n🎬 Content Creator — Clips and streams\n💹 Trader — Economy and marketplace\n\n' +
          '> What\'s your path and main game? Drop it below.',
        footer: { text: 'All paths are valid — play your way' },
      });

      // 🏪 marketplace
      await seedOrUpdate(findCh(communityChannels, '🏪marketplace'), {
        color: 0xfbbf24,
        title: 'Player Marketplace',
        description:
          'Buy and sell in-game items, services, and coins.\n\n' +
          '`/marketplace list <item> <price>` — List something for sale\n`/marketplace browse` — Browse all listings\n`/marketplace buy <listing>` — Purchase a listing\n\n' +
          '> Staff are not responsible for trades made outside the bot.',
        footer: { text: 'Trade smart and trade safe' },
      });

      // 🎬 content
      await seedOrUpdate(findCh(communityChannels, '🎬content'), {
        color: 0x7c3aed,
        title: 'Content Corner',
        description:
          'Share and support creators in the community.\n\n' +
          '`/content submit` — Submit your clip or video for staff review.\n\n' +
          'YouTube · Twitch highlights · TikTok clips · Gaming photography\n\n' +
          '> Most reacted post each week wins **250 coins** and gets featured in announcements.',
        footer: { text: 'Support your fellow creators' },
      });

      // 📲 social
      await seedOrUpdate(findCh(communityChannels, '📲social'), {
        color: 0xec4899,
        title: 'Social & Invites',
        description:
          'Share your socials and grow the community.\n\n' +
          '`/invite link` — Get your personal invite tracking link\n\n' +
          '**Invite milestones**\n🤝 1 invite → +200 coins\n⭐ 5 invites → +1,000 coins + Trusted role\n💎 10 invites → +2,500 coins + VIP role\n\n' +
          '> Post your TikTok, YouTube, Twitch, or Twitter here.',
        footer: { text: 'The more the merrier' },
      });

      // 💎 vip-lounge
      const vipLoungeChannel = vipResults.find((r) => r.channel.name === '💎vip-lounge')?.channel;
      await seedOrUpdate(vipLoungeChannel, {
        color: 0xa855f7,
        title: 'VIP Lounge',
        description:
          'Welcome — you\'ve earned this space by being a top supporter of the server.\n\n' +
          '— Chat freely with other VIPs\n— First access to giveaways in #🎁vip-perks\n— Your feedback goes directly to staff\n\n' +
          '> VIP is earned by inviting 10+ members or boosting the server.',
        footer: { text: 'Thank you for supporting the server' },
      });

      // 🎁 vip-perks
      const vipPerksChannel = vipResults.find((r) => r.channel.name === '🎁vip-perks')?.channel;
      await seedOrUpdate(vipPerksChannel, {
        color: 0xfbbf24,
        title: 'VIP Perks & Giveaways',
        description:
          'Exclusive rewards for VIP members only.\n\n' +
          '— VIP-only giveaways posted regularly\n— Bonus coin drops\n— Early event access\n— Special community recognition\n\n' +
          '> Staff post giveaways here — react or click the button to enter.',
        footer: { text: 'VIP perks are for 🌟 VIP role holders only' },
      });

      // ── Success embed ──────────────────────────────────────────────────────
      const embed = new EmbedBuilder()
        .setColor(0x22c55e)
        .setTitle('🎮 Server Setup Complete!')
        .setDescription('Your gaming server has been fully configured with locked channels, growth systems, and starter messages in every channel.')
        .addFields(
          {
            name: '🔒 Read-Only Channels',
            value: '📜rules · 📣announcements · 👋welcome · 🗺️roles · 📋commands · 🗳️game-polls\n> Members can read/react but not post here.',
            inline: false,
          },
          {
            name: '🚫 Admin-Only Channels',
            value: '🛡️staff-chat · 📋mod-log · 🚨reports · 📊admin-stats\n> Completely hidden from regular members.',
            inline: false,
          },
          {
            name: '📁 Categories',
            value: '📢 Information · 💬 General · 🎮 Gaming\n🤖 Bot Commands · 🔊 Voice · 🔒 Staff Only\n⭐ Levels & Economy · 🎭 Community · 💎 VIP',
            inline: false,
          },
          {
            name: '🎭 Staff Roles',
            value: '👑 Owner · ⚔️ Co-Owner · 🔴 Admin · 🛡️ Moderator · 🔨 Trial Mod · 🤝 Helper',
            inline: true,
          },
          {
            name: '🏅 Member Roles',
            value: '🏆 Legend · 💜 Elite · 🎮 Gamer · 🆕 Member',
            inline: true,
          },
          {
            name: '💬 Starter Messages',
            value: 'Every channel now has an intro message with info and activities for members!',
            inline: false,
          },
        )
        .setFooter({ text: 'Tip: Existing channels and roles were not duplicated. Messages only sent to empty channels.' })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error(error);
      await interaction.editReply({
        content: '❌ Something went wrong during setup. Make sure I have **Administrator** permissions.',
      });
    }
  },
};
