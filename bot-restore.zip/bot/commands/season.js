const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { getSeasonData, advanceSeason, getLeaderboard, getChallengeLeaderboard } = require('../data/store');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('season')
    .setDescription('View seasonal information and rewards')
    .addSubcommand((sub) => sub.setName('info').setDescription('View the current season info'))
    .addSubcommand((sub) => sub.setName('top').setDescription('View the current season leaderboard'))
    .addSubcommand((sub) =>
      sub.setName('reset').setDescription('Force advance to next season (Admin only)')
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;

    if (sub === 'info') {
      const season = getSeasonData(guildId);
      const now = Date.now();
      const remaining = season.endsAt - now;
      const days = Math.max(0, Math.floor(remaining / 86400000));
      const hours = Math.max(0, Math.floor((remaining % 86400000) / 3600000));

      const embed = new EmbedBuilder()
        .setColor(0xa855f7)
        .setTitle(`🏆 Season ${season.season}`)
        .setDescription('Every season, leaderboards reset and top players earn exclusive seasonal rewards!')
        .addFields(
          { name: '📅 Season Started', value: `<t:${Math.floor(season.startedAt / 1000)}:D>`, inline: true },
          { name: '⏳ Ends In', value: `**${days}d ${hours}h**`, inline: true },
          { name: '🎁 Season Rewards', value: '🥇 Top 1 — Seasonal Champion role + 5,000 coins\n🥈 Top 2 — Elite Rival role + 2,500 coins\n🥉 Top 3 — Season Veteran role + 1,000 coins', inline: false },
          { name: '📊 Tracked Stats', value: 'XP, Coins, Challenges, Reputation — all reset at season end.', inline: false },
        )
        .setFooter({ text: `Season ${season.season} | Compete hard before it resets!` })
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'top') {
      const lb = getLeaderboard(guildId);
      const challengeLb = getChallengeLeaderboard(guildId);

      const medals = ['🥇', '🥈', '🥉'];

      const xpLines = await Promise.all(
        lb.slice(0, 5).map(async (entry, i) => {
          const user = await interaction.client.users.fetch(entry.userId).catch(() => null);
          return `${medals[i] ?? `**${i + 1}.**`} ${user?.username ?? 'Unknown'} — Lv.**${entry.level}**`;
        })
      );

      const challengeLines = await Promise.all(
        challengeLb.slice(0, 5).map(async (entry, i) => {
          const user = await interaction.client.users.fetch(entry.userId).catch(() => null);
          return `${medals[i] ?? `**${i + 1}.**`} ${user?.username ?? 'Unknown'} — **${entry.wins}W**`;
        })
      );

      const season = getSeasonData(guildId);

      const embed = new EmbedBuilder()
        .setColor(0xa855f7)
        .setTitle(`🏆 Season ${season.season} — Top Players`)
        .addFields(
          { name: '⭐ XP Leaders', value: xpLines.join('\n') || 'No data yet', inline: true },
          { name: '⚔️ Challenge Leaders', value: challengeLines.join('\n') || 'No data yet', inline: true },
        )
        .setFooter({ text: 'Top 3 earn exclusive season rewards at reset!' })
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'reset') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
        return interaction.reply({ content: '❌ Admins only.', ephemeral: true });
      }

      const newSeason = advanceSeason(guildId);

      const embed = new EmbedBuilder()
        .setColor(0xef4444)
        .setTitle('🔄 Season Advanced!')
        .setDescription(`Season **${newSeason.prevSeason}** has ended.\n\n**Season ${newSeason.season}** has begun! The race starts now.`)
        .addFields(
          { name: '📅 New Season End', value: `<t:${Math.floor(newSeason.endsAt / 1000)}:D>` },
        )
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }
  },
};
