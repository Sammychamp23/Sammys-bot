const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warnings')
    .setDescription('View warnings for a member')
    .addUserOption((option) =>
      option.setName('target').setDescription('The member to check').setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction, client) {
    const target = interaction.options.getMember('target');
    if (!target) return interaction.reply({ content: '❌ Member not found.', ephemeral: true });

    const key = `${interaction.guild.id}-${target.id}`;
    const warnings = client.warnings.get(key) ?? [];

    const embed = new EmbedBuilder()
      .setColor(0x6366f1)
      .setTitle(`⚠️ Warnings for ${target.user.tag}`)
      .setDescription(
        warnings.length === 0
          ? 'This member has no warnings.'
          : warnings
              .map(
                (w, i) =>
                  `**#${i + 1}** — ${w.reason}\n> By ${w.moderator} at <t:${Math.floor(new Date(w.timestamp).getTime() / 1000)}:f>`
              )
              .join('\n\n')
      )
      .setFooter({ text: `Total: ${warnings.length} warning(s)` })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
