const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Kick a member from the server')
    .addUserOption((option) =>
      option.setName('target').setDescription('The member to kick').setRequired(true)
    )
    .addStringOption((option) =>
      option.setName('reason').setDescription('Reason for the kick')
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),

  async execute(interaction) {
    const target = interaction.options.getMember('target');
    const reason = interaction.options.getString('reason') ?? 'No reason provided';

    if (!target) return interaction.reply({ content: '❌ Member not found.', ephemeral: true });
    if (!target.kickable)
      return interaction.reply({ content: '❌ I cannot kick this member.', ephemeral: true });
    if (target.id === interaction.user.id)
      return interaction.reply({ content: '❌ You cannot kick yourself.', ephemeral: true });

    await target.kick(reason);

    const embed = new EmbedBuilder()
      .setColor(0xf59e0b)
      .setTitle('👢 Member Kicked')
      .addFields(
        { name: 'Member', value: `${target.user.tag} (${target.id})` },
        { name: 'Moderator', value: interaction.user.tag },
        { name: 'Reason', value: reason }
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
