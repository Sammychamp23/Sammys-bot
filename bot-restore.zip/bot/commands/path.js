const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getPath, setPath } = require('../data/store');

const PATHS = {
  casual:   { name: '🎮 Casual',          role: '🎮 Casual',          color: 0x22c55e, desc: 'Play for fun, no pressure.' },
  competitive: { name: '⚔️ Competitive',  role: '⚔️ Competitive',     color: 0xef4444, desc: 'Ranked grinder — win at all costs.' },
  creator:  { name: '🎬 Content Creator', role: '🎬 Content Creator', color: 0xa855f7, desc: 'Share your clips and highlights.' },
  trader:   { name: '💹 Trader',          role: '💹 Trader',          color: 0xf59e0b, desc: 'Buy, sell and trade in the marketplace.' },
};

const COOLDOWN_MS = 7 * 24 * 60 * 60 * 1000;

module.exports = {
  data: new SlashCommandBuilder()
    .setName('path')
    .setDescription('Choose your player path')
    .addSubcommand((sub) => sub.setName('choose').setDescription('Pick or switch your path'))
    .addSubcommand((sub) => sub.setName('info').setDescription('See your current path')),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;
    const userId = interaction.user.id;

    if (sub === 'info') {
      const current = getPath(guildId, userId);
      if (!current) {
        return interaction.reply({ content: '❌ You have not chosen a path yet. Use `/path choose`.', ephemeral: true });
      }
      const p = PATHS[current.path];
      const embed = new EmbedBuilder()
        .setColor(p.color)
        .setTitle(`${p.name}`)
        .setDescription(p.desc)
        .addFields({ name: 'Assigned', value: `<t:${Math.floor(current.assignedAt / 1000)}:R>` })
        .setFooter({ text: 'Switch with /path choose (7 day cooldown)' });
      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'choose') {
      const current = getPath(guildId, userId);
      if (current) {
        const elapsed = Date.now() - current.assignedAt;
        if (elapsed < COOLDOWN_MS) {
          const remaining = COOLDOWN_MS - elapsed;
          const days = Math.floor(remaining / 86400000);
          const hours = Math.floor((remaining % 86400000) / 3600000);
          return interaction.reply({
            content: `⏳ You can switch paths in **${days}d ${hours}h**.`,
            ephemeral: true,
          });
        }
      }

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('path_casual').setLabel('🎮 Casual').setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId('path_competitive').setLabel('⚔️ Competitive').setStyle(ButtonStyle.Danger),
        new ButtonBuilder().setCustomId('path_creator').setLabel('🎬 Creator').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId('path_trader').setLabel('💹 Trader').setStyle(ButtonStyle.Secondary),
      );

      const embed = new EmbedBuilder()
        .setColor(0x6366f1)
        .setTitle('🛤️ Choose Your Path')
        .setDescription('Your path defines your identity in this server. Choose wisely — you can switch after 7 days.')
        .addFields(
          { name: '🎮 Casual', value: 'Play for fun, no pressure.', inline: true },
          { name: '⚔️ Competitive', value: 'Ranked grinder — win at all costs.', inline: true },
          { name: '🎬 Content Creator', value: 'Share your clips and highlights.', inline: true },
          { name: '💹 Trader', value: 'Buy, sell and trade in the marketplace.', inline: true },
        );

      const reply = await interaction.reply({ embeds: [embed], components: [row], ephemeral: true, fetchReply: true });

      const collector = reply.createMessageComponentCollector({ time: 60_000 });

      collector.on('collect', async (btn) => {
        if (btn.user.id !== userId) return btn.reply({ content: '❌ Not your menu.', ephemeral: true });

        const pathKey = btn.customId.replace('path_', '');
        const p = PATHS[pathKey];
        if (!p) return;

        // Remove old path roles
        for (const [, info] of Object.entries(PATHS)) {
          const oldRole = interaction.guild.roles.cache.find((r) => r.name === info.role);
          if (oldRole && interaction.member.roles.cache.has(oldRole.id)) {
            await interaction.member.roles.remove(oldRole).catch(() => {});
          }
        }

        // Assign new path role
        let role = interaction.guild.roles.cache.find((r) => r.name === p.role);
        if (!role) {
          role = await interaction.guild.roles.create({ name: p.role, color: p.color, hoist: false }).catch(() => null);
        }
        if (role) await interaction.member.roles.add(role).catch(() => {});

        setPath(guildId, userId, pathKey);
        collector.stop();

        const confirmEmbed = new EmbedBuilder()
          .setColor(p.color)
          .setTitle(`✅ Path Set: ${p.name}`)
          .setDescription(p.desc)
          .setFooter({ text: 'You can switch again in 7 days.' });

        await btn.update({ embeds: [confirmEmbed], components: [] });
      });

      collector.on('end', (_, reason) => {
        if (reason === 'time') {
          interaction.editReply({ components: [] }).catch(() => {});
        }
      });
    }
  },
};
