const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('suggest')
    .setDescription('Submit a suggestion for the server')
    .addStringOption((opt) =>
      opt.setName('suggestion').setDescription('Your suggestion').setRequired(true)
    ),

  async execute(interaction) {
    const suggestion = interaction.options.getString('suggestion');

    const channel =
      interaction.guild.channels.cache.find((c) => c.name === '💡suggestions' && c.isTextBased()) ??
      interaction.guild.channels.cache.find((c) => c.name === 'suggestions' && c.isTextBased());

    if (!channel) {
      return interaction.reply({
        content: '❌ No suggestions channel found. Run `/setup` first!',
        ephemeral: true,
      });
    }

    const embed = new EmbedBuilder()
      .setColor(0x6366f1)
      .setTitle('💡 New Suggestion')
      .setDescription(suggestion)
      .setAuthor({ name: interaction.user.username, iconURL: interaction.user.displayAvatarURL() })
      .addFields(
        { name: '👍 Upvotes', value: '0', inline: true },
        { name: '👎 Downvotes', value: '0', inline: true },
        { name: 'Status', value: '⏳ Pending', inline: true }
      )
      .setFooter({ text: 'React with 👍 or 👎 to vote!' })
      .setTimestamp();

    const msg = await channel.send({ embeds: [embed] });
    await msg.react('👍');
    await msg.react('👎');

    await interaction.reply({ content: `✅ Your suggestion has been posted in ${channel}!`, ephemeral: true });
  },
};
