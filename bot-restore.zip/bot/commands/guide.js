const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('guide')
    .setDescription('Post the member commands guide to the info channel')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });

    const channel =
      interaction.guild.channels.cache.find((c) => c.name === '📋commands' && c.isTextBased()) ??
      interaction.guild.channels.cache.find((c) => c.name === 'commands' && c.isTextBased()) ??
      interaction.channel;

    // ── Embed 1: Economy & Coins ───────────────────────────────────────────
    const economyEmbed = new EmbedBuilder()
      .setColor(0xf59e0b)
      .setTitle('💰 Economy & Coins')
      .setDescription('Earn and manage your server currency.')
      .addFields(
        {
          name: '`/coins daily`',
          value: 'Claim your daily coins. Builds a **streak** — the longer you go without missing a day, the bigger your bonus!\n> 🔥 Milestones at day 3, 7, 14 & 30 for big bonus coins.',
        },
        {
          name: '`/coins weekly`',
          value: 'Claim a larger weekly reward every 7 days.',
        },
        {
          name: '`/coins balance [@user]`',
          value: 'Check your coin balance and daily streak. Mention someone to see theirs.',
        },
        {
          name: '`/coins give @user <amount>`',
          value: 'Send coins to another member.',
        },
        {
          name: '`/shop browse`',
          value: 'Browse items available in the server shop.',
        },
        {
          name: '`/shop buy <item>`',
          value: 'Buy an item from the shop using your coins.',
        },
        {
          name: '`/inventory`',
          value: 'View all the items you own. You can also sell items back for coins.',
        },
      );

    // ── Embed 2: Levels & Progression ─────────────────────────────────────
    const levelEmbed = new EmbedBuilder()
      .setColor(0x6366f1)
      .setTitle('⭐ Levels & Progression')
      .setDescription('XP is earned automatically by chatting and spending time in voice channels.')
      .addFields(
        {
          name: '`/rank [@user]`',
          value: 'See your current level, XP, and progress bar. Mention someone to check theirs.',
        },
        {
          name: '`/stats me [@user]`',
          value: 'Full breakdown of your stats — level, coins, challenges, VC time, messages, rep, and daily streak.',
        },
        {
          name: '`/stats leaderboard`',
          value: 'See the top 10 most levelled players in the server.',
        },
        {
          name: '`/stats richest`',
          value: 'See who has the most coins in the server.',
        },
        {
          name: '🎙️ Voice Rewards',
          value: 'Every minute you spend in a voice channel earns you **+2 coins** automatically.',
        },
        {
          name: '💬 Chat Rewards',
          value: 'Every message (once per minute) earns **15–25 XP** and **5–10 coins**.',
        },
        {
          name: '🏅 Level Roles',
          value: '🎮 **Gamer** at Level 5 · 💜 **Elite** at Level 10 · 🏆 **Legend** at Level 20',
        },
      );

    // ── Embed 3: Quests & Challenges ──────────────────────────────────────
    const questEmbed = new EmbedBuilder()
      .setColor(0x22c55e)
      .setTitle('🎯 Quests & Challenges')
      .setDescription('Complete objectives to earn extra XP and coins on top of your normal earnings.')
      .addFields(
        {
          name: '`/quests view`',
          value: 'See all your active daily and weekly quests with current progress.',
        },
        {
          name: '`/quests claim <quest>`',
          value: 'Claim your reward once a quest is completed.',
        },
        {
          name: '📋 Daily Quests',
          value: '> Chat 10 times — 50 XP + 100 coins\n> Chat 25 times — 100 XP + 200 coins\n> 15 min in VC — 80 XP + 150 coins',
        },
        {
          name: '📋 Weekly Quests',
          value: '> Chat 100 times — 300 XP + 600 coins\n> 60 min in VC — 400 XP + 800 coins\n> Win 3 challenges — 500 XP + 1,000 coins',
        },
        {
          name: '`/challenge send @user <game>`',
          value: 'Challenge another member. Winner gets **200 coins** and a win on their record.',
        },
        {
          name: '`/challenge accept / deny`',
          value: 'Respond to an incoming challenge.',
        },
        {
          name: '`/challenge leaderboard`',
          value: 'View the top challengers in the server by wins.',
        },
      );

    // ── Embed 4: Community Features ───────────────────────────────────────
    const communityEmbed = new EmbedBuilder()
      .setColor(0xa855f7)
      .setTitle('🤝 Community Features')
      .setDescription('Connect with other members, build your reputation, and find teammates.')
      .addFields(
        {
          name: '`/path choose`',
          value: 'Choose your player identity: **Casual**, **Competitive**, **Content Creator**, or **Trader**. Unlocks your path role and exclusive perks.',
        },
        {
          name: '`/rep give @user`',
          value: 'Give reputation to a member you respect. 12-hour cooldown per person.',
        },
        {
          name: '`/squad create / join / leave / info`',
          value: 'Form a squad with other members for team challenges and events.',
        },
        {
          name: '`/lfg post <game>`',
          value: 'Post a Looking-For-Group request to find teammates.',
        },
        {
          name: '`/invite link`',
          value: 'Get your personal invite link. Earn coins and exclusive roles for every friend you bring in!',
        },
        {
          name: '`/invite stats`',
          value: 'Check how many people you have invited and your milestone progress.',
        },
        {
          name: '`/suggest <idea>`',
          value: 'Submit a suggestion for the server. Members can vote with 👍 or 👎.',
        },
      );

    // ── Embed 5: Gambling & Mini-Games ───────────────────────────────────
    const gambleEmbed = new EmbedBuilder()
      .setColor(0xf97316)
      .setTitle('🎲 Gambling & Mini-Games')
      .setDescription('Risk your coins for big rewards — or just have fun!')
      .addFields(
        {
          name: '`/gamble spin <amount>`',
          value: 'Spin the wheel and risk coins for a reward. Different outcomes have different multipliers.',
        },
        {
          name: '`/gamble doubleornothing <amount>`',
          value: '50/50 shot — double your coins or lose them all.',
        },
        {
          name: '`/gamble odds`',
          value: 'View the full odds table before you bet.',
        },
        {
          name: '`/minigames coinflip <bet> <heads|tails>`',
          value: 'Flip a coin — pick the right side and double your bet.',
        },
        {
          name: '`/minigames slots <bet>`',
          value: 'Spin the slot machine. Match symbols to win big.',
        },
        {
          name: '`/minigames duel @user <bet>`',
          value: 'Challenge another member to a duel. Winner takes the pot.',
        },
        {
          name: '`/streak`',
          value: 'View your current activity streak and your XP/coin earn multiplier.',
        },
      );

    // ── Embed 6: Squads & Social ──────────────────────────────────────────
    const squadEmbed = new EmbedBuilder()
      .setColor(0x10b981)
      .setTitle('👥 Squads & Social')
      .setDescription('Team up, build your reputation, and grow together.')
      .addFields(
        {
          name: '`/squad create <name>`',
          value: 'Create a new squad. Share the name with friends so they can join.',
        },
        {
          name: '`/squad join <name>`',
          value: 'Join an existing squad by name.',
        },
        {
          name: '`/squad leave`',
          value: 'Leave your current squad.',
        },
        {
          name: '`/squad info`',
          value: 'View your squad\'s members and stats.',
        },
        {
          name: '`/squad leaderboard`',
          value: 'See the top squads in the server.',
        },
        {
          name: '`/invite stats`',
          value: 'Check how many people you have invited and your milestone progress.',
        },
      );

    // ── Embed 7: Market, Auctions & Contracts ─────────────────────────────
    const marketEmbed = new EmbedBuilder()
      .setColor(0xfbbf24)
      .setTitle('🏪 Market, Auctions & Contracts')
      .setDescription('Trade items, bid on auctions, and take on advanced missions for big rewards.')
      .addFields(
        {
          name: '`/market browse`',
          value: 'Browse all active player listings.',
        },
        {
          name: '`/market list <item> <price>`',
          value: 'List an item from your inventory for sale.',
        },
        {
          name: '`/market buy <id>`',
          value: 'Buy a listing by its ID.',
        },
        {
          name: '`/market remove <id>`',
          value: 'Remove your own listing.',
        },
        {
          name: '`/auction view`',
          value: 'Browse all active auctions.',
        },
        {
          name: '`/auction create <item> <starting_price> <hours>`',
          value: 'Put an item up for auction. Duration can be 1–48 hours.',
        },
        {
          name: '`/auction bid <id> <amount>`',
          value: 'Place a coin bid on an active auction.',
        },
        {
          name: '`/auction mine`',
          value: 'View auctions you have created.',
        },
        {
          name: '`/contracts view`',
          value: 'Browse available contracts — advanced missions with big coin and XP rewards.',
        },
        {
          name: '`/contracts accept <id>`',
          value: 'Accept a contract to start working on it.',
        },
        {
          name: '`/contracts progress`',
          value: 'Check the status of your active contracts.',
        },
        {
          name: '`/contracts claim <id>`',
          value: 'Claim your reward once a contract is complete.',
        },
        {
          name: '`/roleshop browse`',
          value: 'Browse exclusive roles available for purchase. Stock is limited — they sell out fast!',
        },
        {
          name: '`/roleshop buy <role>`',
          value: 'Purchase a role from the role shop using your coins.',
        },
      );

    // ── Embed 8: Fun & Extras ─────────────────────────────────────────────
    const funEmbed = new EmbedBuilder()
      .setColor(0xec4899)
      .setTitle('🎮 Fun & Extras')
      .setDescription('Games, trivia, and mini-features to pass the time.')
      .addFields(
        {
          name: '`/8ball <question>`',
          value: 'Ask the magic 8-ball anything.',
        },
        {
          name: '`/wouldyourather`',
          value: 'Get a random would-you-rather question to spark a debate.',
        },
        {
          name: '`/tip`',
          value: 'Get a random gaming tip.',
        },
        {
          name: '`/userinfo [@user]`',
          value: 'View your Discord account info — join date, roles, and more.',
        },
        {
          name: '`/content submit <title> <link> <game>`',
          value: 'Submit a clip or highlight for the weekly community vote.',
        },
        {
          name: '`/content highlights`',
          value: 'View and vote on this week\'s top submitted clips.',
        },
        {
          name: '`/season info`',
          value: 'See the current season number and when it ends.',
        },
        {
          name: '`/season top`',
          value: 'View the season leaderboard. Top 3 at the end earn exclusive roles and a big coin prize.',
        },
      );

    // ── Embed 6: How to Earn — Quick Reference ────────────────────────────
    const earnEmbed = new EmbedBuilder()
      .setColor(0x10b981)
      .setTitle('📈 How to Earn — Quick Reference')
      .setDescription('Everything that earns you coins or XP at a glance.')
      .addFields(
        {
          name: '💬 Chatting',
          value: '+15–25 XP and +5–10 coins per message (1-minute cooldown)',
          inline: true,
        },
        {
          name: '🎙️ Voice Channels',
          value: '+2 coins per minute in VC',
          inline: true,
        },
        {
          name: '💰 Daily Claim',
          value: '+150–350+ coins (grows with streak)',
          inline: true,
        },
        {
          name: '💜 Weekly Claim',
          value: '+500–1,000+ coins',
          inline: true,
        },
        {
          name: '🎯 Quests',
          value: 'Up to +1,000 coins per week',
          inline: true,
        },
        {
          name: '⚔️ Challenges',
          value: '+200 coins per win',
          inline: true,
        },
        {
          name: '🎁 Mystery Drops',
          value: 'Random drops in channels — first to click wins!',
          inline: true,
        },
        {
          name: '👥 Invites',
          value: 'Up to +10,000 coins for milestones',
          inline: true,
        },
      )
      .setFooter({ text: `${interaction.guild.name} · Last updated ${new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'long', year: 'numeric' })}` });

    // Send all embeds
    await channel.send({ embeds: [economyEmbed] });
    await channel.send({ embeds: [levelEmbed] });
    await channel.send({ embeds: [questEmbed] });
    await channel.send({ embeds: [communityEmbed] });
    await channel.send({ embeds: [gambleEmbed] });
    await channel.send({ embeds: [squadEmbed] });
    await channel.send({ embeds: [marketEmbed] });
    await channel.send({ embeds: [funEmbed] });
    await channel.send({ embeds: [earnEmbed] });

    await interaction.editReply({ content: `✅ Member guide posted in ${channel}!` });
  },
};
