const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const cfg = require('../data/config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('bumpsetup')
    .setDescription('Configure the Disboard bump reminder system')
    .addSubcommand((sub) =>
      sub
        .setName('enable')
        .setDescription('Set up bump reminders for this server')
        .addChannelOption((opt) =>
          opt.setName('channel').setDescription('Channel where /bump is used and reminders will post').setRequired(true)
        )
        .addRoleOption((opt) =>
          opt.setName('role').setDescription('Role to ping when it is time to bump (optional)')
        )
    )
    .addSubcommand((sub) =>
      sub.setName('disable').setDescription('Turn off bump reminders')
    )
    .addSubcommand((sub) =>
      sub.setName('status').setDescription('Check current bump reminder settings')
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;

    if (sub === 'enable') {
      const channel = interaction.options.getChannel('channel');
      const role = interaction.options.getRole('role');

      cfg.set(guildId, 'bumpChannel', channel.id);
      cfg.set(guildId, 'bumpRole', role?.id ?? null);
      cfg.set(guildId, 'bumpEnabled', true);

      await interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(0x22c55e)
            .setTitle('🔔 Bump Reminders Enabled!')
            .setDescription(
              [
                `The bot will watch for Disboard bumps in ${channel} and remind ${role ? role : 'the channel'} as soon as the **2-hour cooldown** is up.`,
                '',
                '**How it works:**',
                `1. Someone types \`/bump\` in ${channel} (Disboard must be in this server)`,
                '2. The bot detects the bump confirmation',
                '3. Exactly 2 hours later, a reminder is posted so you never miss a bump',
                '',
                '> 💡 Bumping consistently keeps your server at the top of Disboard search results, bringing in new members automatically.',
              ].join('\n')
            )
            .setFooter({ text: 'Make sure Disboard bot is in your server — invite it from disboard.org' })
            .setTimestamp(),
        ],
      });
    }

    if (sub === 'disable') {
      cfg.set(guildId, 'bumpEnabled', false);
      await interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(0xef4444)
            .setDescription('❌ Bump reminders have been disabled.'),
        ],
      });
    }

    if (sub === 'status') {
      const enabled = cfg.get(guildId, 'bumpEnabled', false);
      const channelId = cfg.get(guildId, 'bumpChannel');
      const roleId = cfg.get(guildId, 'bumpRole');
      const lastBump = cfg.get(guildId, 'lastBumpTime', 0);

      if (!enabled || !channelId) {
        return interaction.reply({
          embeds: [
            new EmbedBuilder()
              .setColor(0xf59e0b)
              .setDescription('⚠️ Bump reminders are not set up. Use `/bumpsetup enable` to configure them.'),
          ],
          ephemeral: true,
        });
      }

      const channel = interaction.guild.channels.cache.get(channelId);
      const role = roleId ? interaction.guild.roles.cache.get(roleId) : null;
      const nextBump = lastBump + 2 * 60 * 60 * 1000;
      const ready = Date.now() >= nextBump;

      await interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(ready ? 0x22c55e : 0x6366f1)
            .setTitle('📊 Bump Reminder Status')
            .addFields(
              { name: 'Status', value: enabled ? '✅ Active' : '❌ Disabled', inline: true },
              { name: 'Channel', value: channel ? `${channel}` : `<#${channelId}>`, inline: true },
              { name: 'Ping Role', value: role ? `${role}` : 'None (channel only)', inline: true },
              {
                name: 'Bump Status',
                value: lastBump === 0
                  ? '⏳ No bump recorded yet'
                  : ready
                  ? '✅ **Ready to bump now!** Type `/bump` in the channel'
                  : `⏱️ Next bump <t:${Math.floor(nextBump / 1000)}:R>`,
                inline: false,
              },
            )
            .setTimestamp(),
        ],
        ephemeral: true,
      });
    }
  },
};
