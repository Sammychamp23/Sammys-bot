# Discord Moderation Bot

A Discord moderation bot with slash commands.

## Commands

| Command | Description | Permission Required |
|---|---|---|
| `/kick` | Kick a member | Kick Members |
| `/ban` | Ban a member | Ban Members |
| `/unban` | Unban a user by ID | Ban Members |
| `/timeout` | Timeout a member (1min – 1 week) | Moderate Members |
| `/warn` | Warn a member (DMs them) | Moderate Members |
| `/warnings` | View a member's warnings | Moderate Members |
| `/clear` | Bulk delete messages | Manage Messages |
| `/userinfo` | View info about a member | Everyone |

## Setup

### 1. Create your Discord bot
1. Go to [discord.com/developers/applications](https://discord.com/developers/applications)
2. Click **New Application**, give it a name
3. Go to **Bot** → click **Add Bot**
4. Enable **Server Members Intent** and **Message Content Intent**
5. Copy your **Bot Token**
6. Go to **OAuth2 → General** and copy your **Client ID**

### 2. Invite the bot to your server
Go to **OAuth2 → URL Generator**, select:
- Scopes: `bot`, `applications.commands`
- Bot Permissions: `Kick Members`, `Ban Members`, `Moderate Members`, `Manage Messages`, `Send Messages`, `Embed Links`

Open the generated URL and invite the bot.

### 3. Configure environment variables
Copy `.env.example` to `.env` and fill in your values:
```
DISCORD_TOKEN=your-bot-token-here
CLIENT_ID=your-application-client-id-here
```

### 4. Install dependencies
```bash
npm install
```

### 5. Register slash commands
```bash
npm run deploy
```

### 6. Start the bot
```bash
npm start
```

## Deploying to Railway

1. Push this `bot/` folder to a GitHub repository
2. Go to [railway.app](https://railway.app) → New Project → Deploy from GitHub
3. Add your environment variables in Railway's **Variables** tab:
   - `DISCORD_TOKEN`
   - `CLIENT_ID`
4. Railway will automatically run `npm start`

> **Note:** Warnings are stored in memory and will reset when the bot restarts. For persistent warnings, a database would need to be added.
