const fs = require('fs');
const path = require('path');

const FILE = path.join(__dirname, 'serverconfig.json');

function load() {
  if (!fs.existsSync(FILE)) return {};
  return JSON.parse(fs.readFileSync(FILE, 'utf8'));
}

function save(data) {
  fs.writeFileSync(FILE, JSON.stringify(data, null, 2));
}

function getGuild(guildId) {
  const data = load();
  if (!data[guildId]) data[guildId] = {};
  return { data, config: data[guildId] };
}

function set(guildId, key, value) {
  const { data, config } = getGuild(guildId);
  config[key] = value;
  save(data);
}

function get(guildId, key, fallback = null) {
  const { config } = getGuild(guildId);
  return config[key] ?? fallback;
}

module.exports = { set, get };
