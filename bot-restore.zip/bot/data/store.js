const fs = require('fs');
const path = require('path');

const dataDir = path.join(__dirname);
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

function load(file) {
  const filePath = path.join(dataDir, file);
  if (!fs.existsSync(filePath)) return {};
  try { return JSON.parse(fs.readFileSync(filePath, 'utf8')); } catch { return {}; }
}

function save(file, data) {
  fs.writeFileSync(path.join(dataDir, file), JSON.stringify(data, null, 2));
}

function key(guildId, userId) { return `${guildId}-${userId}`; }

// ── Levels ────────────────────────────────────────────────────────────────────
function xpForLevel(level) { return 5 * level * level + 50 * level + 100; }

function getLevelData(guildId, userId) {
  const data = load('levels.json');
  const k = key(guildId, userId);
  if (!data[k]) data[k] = { xp: 0, level: 0 };
  return { data, k, entry: data[k] };
}

function addXp(guildId, userId, amount) {
  const { data, k, entry } = getLevelData(guildId, userId);
  entry.xp += amount;
  let leveledUp = false;
  while (entry.xp >= xpForLevel(entry.level + 1)) {
    entry.xp -= xpForLevel(entry.level + 1);
    entry.level += 1;
    leveledUp = true;
  }
  save('levels.json', data);
  return { level: entry.level, xp: entry.xp, leveledUp };
}

function getLevel(guildId, userId) { return getLevelData(guildId, userId).entry; }

function getLeaderboard(guildId) {
  const data = load('levels.json');
  return Object.entries(data)
    .filter(([k]) => k.startsWith(guildId))
    .map(([k, v]) => ({ userId: k.split('-')[1], ...v }))
    .sort((a, b) => b.level - a.level || b.xp - a.xp)
    .slice(0, 10);
}

// ── Economy ───────────────────────────────────────────────────────────────────
function getEconData(guildId, userId) {
  const data = load('economy.json');
  const k = key(guildId, userId);
  if (!data[k]) data[k] = { coins: 0, lastDaily: null, lastWeekly: null, inventory: [], voiceMinutes: 0, messagesCount: 0 };
  if (!data[k].inventory) data[k].inventory = [];
  if (!data[k].voiceMinutes) data[k].voiceMinutes = 0;
  if (!data[k].messagesCount) data[k].messagesCount = 0;
  if (!('lastWeekly' in data[k])) data[k].lastWeekly = null;
  return { data, k, entry: data[k] };
}

function getCoins(guildId, userId) { return getEconData(guildId, userId).entry; }

function addCoins(guildId, userId, amount) {
  const { data, k, entry } = getEconData(guildId, userId);
  entry.coins = Math.max(0, entry.coins + amount);
  save('economy.json', data);
  return entry.coins;
}

function incrementMessageCount(guildId, userId) {
  const { data, k, entry } = getEconData(guildId, userId);
  entry.messagesCount = (entry.messagesCount || 0) + 1;
  save('economy.json', data);
  return entry.messagesCount;
}

function claimDaily(guildId, userId) {
  const { data, k, entry } = getEconData(guildId, userId);
  const now = Date.now();
  const cooldown = 24 * 60 * 60 * 1000;
  if (entry.lastDaily && now - entry.lastDaily < cooldown) {
    return { success: false, remaining: cooldown - (now - entry.lastDaily) };
  }

  // Streak tracking — reset if more than 48h since last claim
  const streakExpiry = 48 * 60 * 60 * 1000;
  if (!entry.dailyStreak) entry.dailyStreak = 0;
  if (entry.lastDaily && now - entry.lastDaily > streakExpiry) {
    entry.dailyStreak = 0;
  }
  entry.dailyStreak += 1;

  // Milestone bonuses at streaks 3, 7, 14, 30
  const milestoneBonus = [3, 7, 14, 30].includes(entry.dailyStreak) ? entry.dailyStreak * 50 : 0;
  const streakBonus = Math.min(entry.dailyStreak * 10, 200);
  const base = 150 + Math.floor(Math.random() * 100);
  const reward = base + streakBonus + milestoneBonus;

  entry.coins += reward;
  entry.lastDaily = now;
  save('economy.json', data);
  return { success: true, reward, base, streakBonus, milestoneBonus, streak: entry.dailyStreak, total: entry.coins };
}

function claimWeekly(guildId, userId) {
  const { data, k, entry } = getEconData(guildId, userId);
  const now = Date.now();
  const cooldown = 7 * 24 * 60 * 60 * 1000;
  if (entry.lastWeekly && now - entry.lastWeekly < cooldown) {
    return { success: false, remaining: cooldown - (now - entry.lastWeekly) };
  }
  if (!entry.weeklyStreak) entry.weeklyStreak = 0;
  if (entry.lastWeekly && now - entry.lastWeekly > cooldown * 2) entry.weeklyStreak = 0;
  entry.weeklyStreak += 1;
  const streakBonus = Math.min(entry.weeklyStreak * 100, 500);
  const base = 500 + Math.floor(Math.random() * 251);
  const reward = base + streakBonus;
  entry.coins += reward;
  entry.lastWeekly = now;
  save('economy.json', data);
  return { success: true, reward, base, streakBonus, streak: entry.weeklyStreak, total: entry.coins };
}

function addVoiceMinutes(guildId, userId, minutes) {
  const { data, k, entry } = getEconData(guildId, userId);
  entry.voiceMinutes = (entry.voiceMinutes || 0) + minutes;
  const coinsEarned = minutes * 2;
  entry.coins += coinsEarned;
  save('economy.json', data);
  return coinsEarned;
}

function getInventory(guildId, userId) { return getEconData(guildId, userId).entry.inventory; }

function addToInventory(guildId, userId, item) {
  const { data, k, entry } = getEconData(guildId, userId);
  entry.inventory.push(item);
  save('economy.json', data);
}

function removeFromInventory(guildId, userId, item) {
  const { data, k, entry } = getEconData(guildId, userId);
  const idx = entry.inventory.indexOf(item);
  if (idx === -1) return false;
  entry.inventory.splice(idx, 1);
  save('economy.json', data);
  return true;
}

// ── Path System ───────────────────────────────────────────────────────────────
function getPath(guildId, userId) {
  const data = load('paths.json');
  return data[key(guildId, userId)] || null;
}

function setPath(guildId, userId, pathName) {
  const data = load('paths.json');
  const k = key(guildId, userId);
  data[k] = { path: pathName, assignedAt: Date.now() };
  save('paths.json', data);
}

// ── Challenge System ──────────────────────────────────────────────────────────
function getChallengeStats(guildId, userId) {
  const data = load('challenges.json');
  const k = key(guildId, userId);
  if (!data[k]) data[k] = { wins: 0, losses: 0, pending: null, lastChallenge: null, coinsWon: 0 };
  if (!data[k].coinsWon) data[k].coinsWon = 0;
  return { data, k, entry: data[k] };
}

function getChallenge(guildId, userId) { return getChallengeStats(guildId, userId).entry; }

function setPendingChallenge(guildId, challengerId, targetId) {
  const { data, k: ck, entry: ce } = getChallengeStats(guildId, challengerId);
  ce.pending = targetId;
  ce.lastChallenge = Date.now();
  const tk = key(guildId, targetId);
  if (!data[tk]) data[tk] = { wins: 0, losses: 0, pending: null, lastChallenge: null, coinsWon: 0 };
  data[tk].incomingChallenge = challengerId;
  save('challenges.json', data);
}

function clearChallenge(guildId, challengerId, targetId) {
  const data = load('challenges.json');
  const ck = key(guildId, challengerId);
  const tk = key(guildId, targetId);
  if (data[ck]) data[ck].pending = null;
  if (data[tk]) data[tk].incomingChallenge = null;
  save('challenges.json', data);
}

function recordChallengeResult(guildId, winnerId, loserId, coinReward = 0) {
  const data = load('challenges.json');
  const wk = key(guildId, winnerId);
  const lk = key(guildId, loserId);
  if (!data[wk]) data[wk] = { wins: 0, losses: 0, pending: null, lastChallenge: null, coinsWon: 0 };
  if (!data[lk]) data[lk] = { wins: 0, losses: 0, pending: null, lastChallenge: null, coinsWon: 0 };
  data[wk].wins += 1;
  data[lk].losses += 1;
  data[wk].coinsWon = (data[wk].coinsWon || 0) + coinReward;
  save('challenges.json', data);
}

function getChallengeLeaderboard(guildId) {
  const data = load('challenges.json');
  return Object.entries(data)
    .filter(([k]) => k.startsWith(guildId))
    .map(([k, v]) => ({ userId: k.split('-')[1], wins: v.wins || 0, losses: v.losses || 0, coinsWon: v.coinsWon || 0 }))
    .sort((a, b) => b.wins - a.wins)
    .slice(0, 10);
}

// ── Reputation System ─────────────────────────────────────────────────────────
function getRepData(guildId, userId) {
  const data = load('reputation.json');
  const k = key(guildId, userId);
  if (!data[k]) data[k] = { rep: 0, givenTo: {} };
  return { data, k, entry: data[k] };
}

function getRep(guildId, userId) { return getRepData(guildId, userId).entry; }

function addRep(guildId, giverId, targetId) {
  const now = Date.now();
  const cooldown = 12 * 60 * 60 * 1000;
  const giverData = getRepData(guildId, giverId);
  const lastGiven = giverData.entry.givenTo[targetId] || 0;
  if (now - lastGiven < cooldown) {
    return { success: false, remaining: cooldown - (now - lastGiven) };
  }
  giverData.entry.givenTo[targetId] = now;
  save('reputation.json', giverData.data);

  const targetData = getRepData(guildId, targetId);
  targetData.entry.rep += 1;
  save('reputation.json', targetData.data);
  return { success: true, newRep: targetData.entry.rep };
}

// ── Quest System ──────────────────────────────────────────────────────────────
const DAILY_QUESTS = [
  { id: 'messages10', name: 'Chat 10 times', type: 'messages', goal: 10, xp: 50, coins: 100 },
  { id: 'messages25', name: 'Chat 25 times', type: 'messages', goal: 25, xp: 100, coins: 200 },
  { id: 'vc15', name: 'Spend 15 min in VC', type: 'vc', goal: 15, xp: 80, coins: 150 },
];
const WEEKLY_QUESTS = [
  { id: 'messages100', name: 'Chat 100 times', type: 'messages', goal: 100, xp: 300, coins: 600 },
  { id: 'vc60', name: 'Spend 60 min in VC', type: 'vc', goal: 60, xp: 400, coins: 800 },
  { id: 'wins3', name: 'Win 3 challenges', type: 'wins', goal: 3, xp: 500, coins: 1000 },
];

function getQuestData(guildId, userId) {
  const data = load('quests.json');
  const k = key(guildId, userId);
  const now = Date.now();
  const dayMs = 24 * 60 * 60 * 1000;
  const weekMs = 7 * dayMs;
  if (!data[k]) data[k] = { daily: {}, weekly: {}, lastDailyReset: 0, lastWeeklyReset: 0 };
  const entry = data[k];
  if (now - entry.lastDailyReset > dayMs) {
    entry.daily = {};
    entry.lastDailyReset = now;
  }
  if (now - entry.lastWeeklyReset > weekMs) {
    entry.weekly = {};
    entry.lastWeeklyReset = now;
  }
  save('quests.json', data);
  return { data, k, entry };
}

function incrementQuestProgress(guildId, userId, type, amount = 1) {
  const { data, k, entry } = getQuestData(guildId, userId);
  for (const q of DAILY_QUESTS) {
    if (q.type === type) {
      if (!entry.daily[q.id]) entry.daily[q.id] = { progress: 0, claimed: false };
      entry.daily[q.id].progress = Math.min(q.goal, (entry.daily[q.id].progress || 0) + amount);
    }
  }
  for (const q of WEEKLY_QUESTS) {
    if (q.type === type) {
      if (!entry.weekly[q.id]) entry.weekly[q.id] = { progress: 0, claimed: false };
      entry.weekly[q.id].progress = Math.min(q.goal, (entry.weekly[q.id].progress || 0) + amount);
    }
  }
  save('quests.json', data);
}

function claimQuest(guildId, userId, questId) {
  const { data, k, entry } = getQuestData(guildId, userId);
  const daily = DAILY_QUESTS.find((q) => q.id === questId);
  const weekly = WEEKLY_QUESTS.find((q) => q.id === questId);
  const quest = daily || weekly;
  if (!quest) return { success: false, reason: 'Quest not found.' };
  const bucket = daily ? entry.daily : entry.weekly;
  if (!bucket[questId]) return { success: false, reason: 'No progress on this quest yet.' };
  if (bucket[questId].claimed) return { success: false, reason: 'Already claimed!' };
  if (bucket[questId].progress < quest.goal) return { success: false, reason: `Not complete yet (${bucket[questId].progress}/${quest.goal}).` };
  bucket[questId].claimed = true;
  save('quests.json', data);
  addXp(guildId, userId, quest.xp);
  addCoins(guildId, userId, quest.coins);
  return { success: true, quest };
}

// ── Squad System ──────────────────────────────────────────────────────────────
function getSquadData(guildId) {
  const data = load('squads.json');
  if (!data[guildId]) data[guildId] = {};
  return { data, squads: data[guildId] };
}

function getUserSquad(guildId, userId) {
  const { squads } = getSquadData(guildId);
  for (const [name, squad] of Object.entries(squads)) {
    if (squad.members.includes(userId) || squad.owner === userId) return { name, ...squad };
  }
  return null;
}

function createSquad(guildId, userId, name) {
  const { data, squads } = getSquadData(guildId);
  if (squads[name]) return { success: false, reason: 'Squad name already taken.' };
  if (getUserSquad(guildId, userId)) return { success: false, reason: 'You are already in a squad.' };
  squads[name] = { owner: userId, members: [userId], createdAt: Date.now(), wins: 0, losses: 0 };
  save('squads.json', data);
  return { success: true };
}

function joinSquad(guildId, userId, name) {
  const { data, squads } = getSquadData(guildId);
  if (!squads[name]) return { success: false, reason: 'Squad not found.' };
  if (getUserSquad(guildId, userId)) return { success: false, reason: 'You are already in a squad.' };
  squads[name].members.push(userId);
  save('squads.json', data);
  return { success: true };
}

function leaveSquad(guildId, userId) {
  const { data, squads } = getSquadData(guildId);
  for (const [name, squad] of Object.entries(squads)) {
    if (squad.members.includes(userId) || squad.owner === userId) {
      if (squad.owner === userId && squad.members.length === 1) {
        delete squads[name];
      } else {
        squad.members = squad.members.filter((id) => id !== userId);
        if (squad.owner === userId) squad.owner = squad.members[0];
      }
      save('squads.json', data);
      return { success: true, squadName: name };
    }
  }
  return { success: false, reason: 'You are not in a squad.' };
}

function getSquadLeaderboard(guildId) {
  const { squads } = getSquadData(guildId);
  return Object.entries(squads)
    .map(([name, s]) => ({ name, members: s.members.length, wins: s.wins || 0 }))
    .sort((a, b) => b.wins - a.wins)
    .slice(0, 10);
}

// ── Marketplace ───────────────────────────────────────────────────────────────
function getMarketData(guildId) {
  const data = load('marketplace.json');
  if (!data[guildId]) data[guildId] = {};
  return { data, listings: data[guildId] };
}

function listItem(guildId, sellerId, item, price) {
  const { data, listings } = getMarketData(guildId);
  const id = `${sellerId}-${Date.now()}`;
  listings[id] = { sellerId, item, price, listedAt: Date.now() };
  save('marketplace.json', data);
  return id;
}

function getListings(guildId) {
  return Object.entries(getMarketData(guildId).listings)
    .map(([id, v]) => ({ id, ...v }))
    .sort((a, b) => a.price - b.price);
}

function buyListing(guildId, buyerId, listingId) {
  const { data, listings } = getMarketData(guildId);
  const listing = listings[listingId];
  if (!listing) return { success: false, reason: 'Listing not found.' };
  if (listing.sellerId === buyerId) return { success: false, reason: 'You cannot buy your own listing.' };
  const { coins } = getCoins(guildId, buyerId);
  if (coins < listing.price) return { success: false, reason: `Need **${listing.price}** coins, you have **${coins}**.` };
  addCoins(guildId, buyerId, -listing.price);
  addCoins(guildId, listing.sellerId, listing.price);
  addToInventory(guildId, buyerId, listing.item);
  delete listings[listingId];
  save('marketplace.json', data);
  return { success: true, listing };
}

function removeListing(guildId, sellerId, listingId) {
  const { data, listings } = getMarketData(guildId);
  if (!listings[listingId]) return { success: false, reason: 'Listing not found.' };
  if (listings[listingId].sellerId !== sellerId) return { success: false, reason: 'Not your listing.' };
  delete listings[listingId];
  save('marketplace.json', data);
  return { success: true };
}

// ── Mystery Drop System ───────────────────────────────────────────────────────
function getMysteryDropData() {
  return load('mystery_drops.json');
}

function createMysteryDrop(dropId, reward) {
  const data = getMysteryDropData();
  data[dropId] = { reward, claimed: false, claimedBy: null, createdAt: Date.now() };
  save('mystery_drops.json', data);
}

function claimMysteryDrop(dropId, userId) {
  const data = getMysteryDropData();
  if (!data[dropId]) return { success: false, reason: 'Drop not found.' };
  if (data[dropId].claimed) return { success: false, reason: 'Already claimed!', claimedBy: data[dropId].claimedBy };
  data[dropId].claimed = true;
  data[dropId].claimedBy = userId;
  data[dropId].claimedAt = Date.now();
  save('mystery_drops.json', data);
  return { success: true, reward: data[dropId].reward };
}

// ── Seasonal System ───────────────────────────────────────────────────────────
function getSeasonData(guildId) {
  const data = load('seasons.json');
  if (!data[guildId]) {
    const now = new Date();
    data[guildId] = {
      season: 1,
      startedAt: Date.now(),
      endsAt: new Date(now.getFullYear(), now.getMonth() + 1, 1).getTime(),
      rewards: [],
    };
    save('seasons.json', data);
  }
  return data[guildId];
}

function advanceSeason(guildId) {
  const data = load('seasons.json');
  const current = data[guildId] || { season: 0 };
  const now = new Date();
  data[guildId] = {
    season: (current.season || 0) + 1,
    startedAt: Date.now(),
    endsAt: new Date(now.getFullYear(), now.getMonth() + 1, 1).getTime(),
    rewards: [],
    prevSeason: current.season || 1,
  };
  save('seasons.json', data);
  return data[guildId];
}

// ── Role Shop System ──────────────────────────────────────────────────────────
function getRoleShopStock(guildId) {
  const data = load('roleshop.json');
  if (!data[guildId]) data[guildId] = {};
  return data[guildId];
}

function buyRoleShopItem(guildId, userId, item) {
  const shopData = load('roleshop.json');
  if (!shopData[guildId]) shopData[guildId] = {};
  const stock = shopData[guildId];

  const now = Date.now();

  // Init stock entry if missing
  if (!stock[item.id]) {
    stock[item.id] = { current: item.stock, lastRestock: now, buyers: {} };
  }

  const entry = stock[item.id];

  // Auto-restock logic with jitter (±20%)
  if (entry.current <= 0) {
    const jitter = 0.8 + Math.random() * 0.4;
    const range = item.restockMax - item.restockMin;
    const minutes = item.restockMin + Math.floor(range * jitter);
    const restockAt = entry.lastRestock + minutes * 60 * 1000;
    if (now >= restockAt) {
      entry.current = item.stock;
      entry.lastRestock = now;
      entry.buyers = {};
    }
  }

  if (entry.current <= 0) {
    const jitter = 0.8 + Math.random() * 0.4;
    const range = item.restockMax - item.restockMin;
    const minutes = item.restockMin + Math.floor(range * jitter);
    const restockAt = entry.lastRestock + minutes * 60 * 1000;
    const remaining = restockAt - now;
    const h = Math.floor(remaining / 3600000);
    const m = Math.floor((remaining % 3600000) / 60000);
    return { success: false, reason: `**${item.role}** is sold out! Restocks in **${h > 0 ? h + 'h ' : ''}${m}m**.` };
  }

  // Check purchase cooldown (prevent spam — 5 min between buys per user)
  const lastBuy = entry.buyers?.[userId] || 0;
  const cooldown = 5 * 60 * 1000;
  if (now - lastBuy < cooldown) {
    const wait = Math.ceil((cooldown - (now - lastBuy)) / 60000);
    return { success: false, reason: `Please wait **${wait}m** before buying again.` };
  }

  // Check coins
  const econData = getEconData(guildId, userId);
  if (econData.entry.coins < item.price) {
    return { success: false, reason: `You need **${item.price.toLocaleString()}** 💰 but only have **${econData.entry.coins.toLocaleString()}** 💰.` };
  }

  // Deduct coins
  econData.entry.coins -= item.price;
  save('economy.json', econData.data);

  // Deduct stock
  entry.current -= 1;
  if (!entry.buyers) entry.buyers = {};
  entry.buyers[userId] = now;
  save('roleshop.json', shopData);

  return { success: true, newBalance: econData.entry.coins, stockLeft: entry.current };
}

// ── Activity Streak System ────────────────────────────────────────────────────
function getActivityStreak(guildId, userId) {
  const data = load('streaks.json');
  const k = key(guildId, userId);
  if (!data[k]) data[k] = { current: 0, best: 0, lastActive: null, lastActiveDate: null };
  return data[k];
}

function updateActivityStreak(guildId, userId) {
  const data = load('streaks.json');
  const k = key(guildId, userId);
  if (!data[k]) data[k] = { current: 0, best: 0, lastActive: null, lastActiveDate: null };
  const entry = data[k];
  const now = Date.now();
  const todayStr = new Date().toDateString();

  if (entry.lastActiveDate === todayStr) return { streaked: false, current: entry.current };

  const yesterday = new Date(now - 86400000).toDateString();
  if (entry.lastActiveDate === yesterday) {
    entry.current += 1;
  } else if (entry.lastActiveDate !== null) {
    entry.current = 1;
  } else {
    entry.current = 1;
  }

  entry.best = Math.max(entry.best || 0, entry.current);
  entry.lastActive = now;
  entry.lastActiveDate = todayStr;
  save('streaks.json', data);

  return { streaked: true, current: entry.current, best: entry.best };
}

// ── Contract System ───────────────────────────────────────────────────────────
const CONTRACT_POOL = [
  { id: 'msg50',   name: 'Chatterbox',      desc: 'Send 50 messages',             type: 'messages', goal: 50,  coins: 500,  xp: 150 },
  { id: 'msg100',  name: 'Social Butterfly', desc: 'Send 100 messages',            type: 'messages', goal: 100, coins: 1000, xp: 300 },
  { id: 'vc30',    name: 'Voice Veteran',   desc: 'Spend 30 minutes in voice',     type: 'vc',       goal: 30,  coins: 600,  xp: 200 },
  { id: 'vc60',    name: 'VC Legend',       desc: 'Spend 60 minutes in voice',     type: 'vc',       goal: 60,  coins: 1200, xp: 400 },
  { id: 'wins5',   name: 'Challenger',      desc: 'Win 5 challenges',              type: 'wins',     goal: 5,   coins: 800,  xp: 250 },
  { id: 'daily7',  name: 'Streak Keeper',   desc: 'Maintain a 7-day activity streak', type: 'streak', goal: 7,  coins: 2000, xp: 600 },
];

function getContractData(guildId, userId) {
  const data = load('contracts.json');
  const k = key(guildId, userId);
  if (!data[k]) data[k] = { active: [], completed: [] };
  return data[k];
}

function acceptContract(guildId, userId, contractId) {
  const data = load('contracts.json');
  const k = key(guildId, userId);
  if (!data[k]) data[k] = { active: [], completed: [] };
  const entry = data[k];
  if (entry.active.length >= 2) return { success: false, reason: 'You already have 2 active contracts. Claim or abandon one first.' };
  if (entry.active.find((a) => a.id === contractId)) return { success: false, reason: 'You already have this contract active.' };
  const contract = CONTRACT_POOL.find((c) => c.id === contractId);
  if (!contract) return { success: false, reason: 'Contract not found.' };
  entry.active.push({ id: contractId, progress: 0, acceptedAt: Date.now() });
  save('contracts.json', data);
  return { success: true };
}

function updateContractProgress(guildId, userId, type, amount = 1) {
  const data = load('contracts.json');
  const k = key(guildId, userId);
  if (!data[k]) return;
  for (const a of data[k].active) {
    const contract = CONTRACT_POOL.find((c) => c.id === a.id);
    if (contract && contract.type === type) {
      a.progress = Math.min(contract.goal, (a.progress || 0) + amount);
    }
  }
  save('contracts.json', data);
}

function claimContract(guildId, userId, contractId) {
  const data = load('contracts.json');
  const k = key(guildId, userId);
  if (!data[k]) return { success: false, reason: 'No contracts found.' };
  const idx = data[k].active.findIndex((a) => a.id === contractId);
  if (idx === -1) return { success: false, reason: 'Contract not active.' };
  const a = data[k].active[idx];
  const contract = CONTRACT_POOL.find((c) => c.id === contractId);
  if (!contract) return { success: false, reason: 'Contract not found.' };
  if (a.progress < contract.goal) return { success: false, reason: `Not complete yet (${a.progress}/${contract.goal}).` };
  data[k].active.splice(idx, 1);
  data[k].completed.push({ id: contractId, completedAt: Date.now() });
  save('contracts.json', data);
  addXp(guildId, userId, contract.xp);
  addCoins(guildId, userId, contract.coins);
  return { success: true, contract };
}

// ── Auction House ─────────────────────────────────────────────────────────────
function createAuction(guildId, sellerId, item, startingPrice, endsAt) {
  const data = load('auctions.json');
  if (!data[guildId]) data[guildId] = {};
  const id = `${sellerId}-${Date.now()}`;
  data[guildId][id] = { sellerId, item, startingPrice, currentBid: startingPrice, topBidderId: null, bids: {}, endsAt, ended: false, createdAt: Date.now() };
  save('auctions.json', data);
  return id;
}

function getAuctions(guildId) {
  const data = load('auctions.json');
  if (!data[guildId]) return [];
  return Object.entries(data[guildId]).map(([id, v]) => ({ id, ...v }));
}

function placeBid(guildId, userId, auctionId, amount) {
  const data = load('auctions.json');
  if (!data[guildId]?.[auctionId]) return { success: false, reason: 'Auction not found.' };
  const auction = data[guildId][auctionId];
  if (auction.ended || auction.endsAt <= Date.now()) return { success: false, reason: 'Auction has ended.' };

  const minBid = auction.currentBid + Math.max(10, Math.floor(auction.currentBid * 0.05));
  if (amount < minBid) return { success: false, reason: `Minimum bid is ${minBid.toLocaleString()} 💰.` };

  // Refund previous top bidder
  if (auction.topBidderId && auction.topBidderId !== userId) {
    addCoins(guildId, auction.topBidderId, auction.currentBid);
  }
  // Hold coins from new bidder
  addCoins(guildId, userId, -amount);
  auction.currentBid = amount;
  auction.topBidderId = userId;
  auction.bids[userId] = amount;
  save('auctions.json', data);
  return { success: true };
}

function endAuction(guildId, auctionId) {
  const data = load('auctions.json');
  if (!data[guildId]?.[auctionId]) return null;
  const auction = data[guildId][auctionId];
  auction.ended = true;
  // Give item to winner
  if (auction.topBidderId) {
    addToInventory(guildId, auction.topBidderId, auction.item);
    // Coins already deducted on bid — give to seller
    addCoins(guildId, auction.sellerId, auction.currentBid);
  }
  save('auctions.json', data);
  return auction;
}

// ── Game Rotation ─────────────────────────────────────────────────────────────
const GAME_POOL = [
  '🔫 Fortnite', '⚡ Valorant', '🔲 Minecraft', '💣 Call of Duty',
  '🏃 Apex Legends', '🌍 GTA V', '🔵 Roblox', '⚽ Rocket League',
  '🎯 Overwatch 2', '💀 Warzone',
];

function getGameRotation() {
  const data = load('game_rotation.json');
  if (!data.games || !data.lastRotated || Date.now() - data.lastRotated > 7 * 24 * 60 * 60 * 1000) {
    const shuffled = [...GAME_POOL].sort(() => Math.random() - 0.5);
    data.games = shuffled.slice(0, 3);
    data.lastRotated = Date.now();
    save('game_rotation.json', data);
  }
  return data;
}

function rotateGames() {
  const shuffled = [...GAME_POOL].sort(() => Math.random() - 0.5);
  const data = { games: shuffled.slice(0, 3), lastRotated: Date.now() };
  save('game_rotation.json', data);
  return data;
}

// ── Achievement System ────────────────────────────────────────────────────────
const ACHIEVEMENTS = [
  { id: 'chat10',    name: '💬 Chatterbox',       desc: 'Send 10 messages',             type: 'messages',   goal: 10,   xp: 50,   coins: 100  },
  { id: 'chat100',   name: '💬 Social Butterfly',  desc: 'Send 100 messages',            type: 'messages',   goal: 100,  xp: 150,  coins: 300  },
  { id: 'chat500',   name: '💬 Community Pillar',  desc: 'Send 500 messages',            type: 'messages',   goal: 500,  xp: 400,  coins: 800  },
  { id: 'chat1000',  name: '💬 Legendary Talker',  desc: 'Send 1,000 messages',          type: 'messages',   goal: 1000, xp: 1000, coins: 2000 },
  { id: 'vc30',      name: '🎙️ Voice Rookie',      desc: 'Spend 30 min in VC',           type: 'vc_minutes', goal: 30,   xp: 80,   coins: 150  },
  { id: 'vc180',     name: '🎙️ Voice Veteran',     desc: 'Spend 3 hours in VC',          type: 'vc_minutes', goal: 180,  xp: 250,  coins: 500  },
  { id: 'vc600',     name: '🎙️ Voice Legend',      desc: 'Spend 10 hours in VC',         type: 'vc_minutes', goal: 600,  xp: 600,  coins: 1200 },
  { id: 'wins3',     name: '⚔️ Challenger',        desc: 'Win 3 challenges',             type: 'wins',       goal: 3,    xp: 100,  coins: 200  },
  { id: 'wins10',    name: '⚔️ Warrior',           desc: 'Win 10 challenges',            type: 'wins',       goal: 10,   xp: 300,  coins: 600  },
  { id: 'streak7',   name: '🔥 Week Warrior',      desc: 'Reach a 7-day streak',         type: 'streak',     goal: 7,    xp: 200,  coins: 400  },
  { id: 'streak30',  name: '🔥 Monthly Grinder',   desc: 'Reach a 30-day streak',        type: 'streak',     goal: 30,   xp: 800,  coins: 1600 },
  { id: 'level10',   name: '⭐ Leveled Up',        desc: 'Reach Level 10',              type: 'level',      goal: 10,   xp: 300,  coins: 600  },
  { id: 'level25',   name: '⭐ Rising Star',       desc: 'Reach Level 25',              type: 'level',      goal: 25,   xp: 750,  coins: 1500 },
  { id: 'level50',   name: '⭐ Apex Member',       desc: 'Reach Level 50',              type: 'level',      goal: 50,   xp: 2000, coins: 4000 },
];

function getAchievementData(guildId, userId) {
  const data = load('achievements.json');
  const k = key(guildId, userId);
  if (!data[k]) data[k] = {};
  return { data, k, entry: data[k] };
}

function updateAchievementProgress(guildId, userId, type, amount = 1) {
  const { data, k, entry } = getAchievementData(guildId, userId);
  const relevant = ACHIEVEMENTS.filter((a) => a.type === type);
  for (const ach of relevant) {
    if (!entry[ach.id]) entry[ach.id] = { progress: 0, claimed: false };
    if (!entry[ach.id].claimed) {
      entry[ach.id].progress = Math.min(ach.goal, (entry[ach.id].progress || 0) + amount);
    }
  }
  save('achievements.json', data);
  return relevant.filter((a) => entry[a.id]?.progress >= a.goal && !entry[a.id]?.claimed);
}

function setAchievementProgress(guildId, userId, type, value) {
  const { data, k, entry } = getAchievementData(guildId, userId);
  const relevant = ACHIEVEMENTS.filter((a) => a.type === type);
  for (const ach of relevant) {
    if (!entry[ach.id]) entry[ach.id] = { progress: 0, claimed: false };
    if (!entry[ach.id].claimed) entry[ach.id].progress = Math.min(ach.goal, value);
  }
  save('achievements.json', data);
  return relevant.filter((a) => entry[a.id]?.progress >= a.goal && !entry[a.id]?.claimed);
}

function claimAchievement(guildId, userId, achId) {
  const { data, k, entry } = getAchievementData(guildId, userId);
  const ach = ACHIEVEMENTS.find((a) => a.id === achId);
  if (!ach) return { success: false, reason: 'Achievement not found.' };
  if (!entry[achId] || entry[achId].progress < ach.goal) return { success: false, reason: 'Not completed yet.' };
  if (entry[achId].claimed) return { success: false, reason: 'Already claimed.' };
  entry[achId].claimed = true;
  save('achievements.json', data);
  addXp(guildId, userId, ach.xp);
  addCoins(guildId, userId, ach.coins);
  return { success: true, ach };
}

function getAchievements(guildId, userId) {
  const { entry } = getAchievementData(guildId, userId);
  return ACHIEVEMENTS.map((a) => ({
    ...a,
    progress: entry[a.id]?.progress || 0,
    claimed: entry[a.id]?.claimed || false,
  }));
}

// ── Upgrade System ─────────────────────────────────────────────────────────────
const UPGRADES = [
  { id: 'xp_boost',      name: '⚡ XP Multiplier',     desc: 'Permanently boost XP gain',          maxLevel: 5, costPerLevel: 500,  effect: '+10% XP per level'       },
  { id: 'coin_bonus',    name: '💰 Coin Multiplier',    desc: 'Permanently boost coin gain',        maxLevel: 5, costPerLevel: 500,  effect: '+10% coins per level'    },
  { id: 'cd_reduction',  name: '⏱️ Cooldown Reduction', desc: 'Reduce XP/reward cooldowns',         maxLevel: 3, costPerLevel: 800,  effect: '-15s cooldown per level' },
];

function getUpgradeData(guildId, userId) {
  const data = load('upgrades.json');
  const k = key(guildId, userId);
  if (!data[k]) data[k] = {};
  return { data, k, entry: data[k] };
}

function getUpgrades(guildId, userId) {
  const { entry } = getUpgradeData(guildId, userId);
  return UPGRADES.map((u) => ({ ...u, level: entry[u.id] || 0, totalCost: (entry[u.id] || 0) * u.costPerLevel }));
}

function buyUpgrade(guildId, userId, upgradeId) {
  const upgrade = UPGRADES.find((u) => u.id === upgradeId);
  if (!upgrade) return { success: false, reason: 'Upgrade not found.' };
  const { data, k, entry } = getUpgradeData(guildId, userId);
  const current = entry[upgradeId] || 0;
  if (current >= upgrade.maxLevel) return { success: false, reason: `Already at max level (${upgrade.maxLevel}).` };
  const cost = upgrade.costPerLevel * (current + 1);
  const econData = getEconData(guildId, userId);
  if (econData.entry.coins < cost) return { success: false, reason: `Need **${cost.toLocaleString()}** 💰.` };
  econData.entry.coins -= cost;
  save('economy.json', econData.data);
  entry[upgradeId] = current + 1;
  save('upgrades.json', data);
  return { success: true, newLevel: current + 1, cost };
}

function getUpgradeMultiplier(guildId, userId, type) {
  const { entry } = getUpgradeData(guildId, userId);
  if (type === 'xp') return 1 + (entry['xp_boost'] || 0) * 0.10;
  if (type === 'coins') return 1 + (entry['coin_bonus'] || 0) * 0.10;
  if (type === 'cd') return Math.max(0, 60 - (entry['cd_reduction'] || 0) * 15);
  return 1;
}

// ── First Action Bonus System ──────────────────────────────────────────────────
function getFirstActionData(guildId, userId) {
  const data = load('first_actions.json');
  const k = key(guildId, userId);
  const today = new Date().toDateString();
  if (!data[k] || data[k].date !== today) data[k] = { date: today, message: false, vc: false, lfg: false };
  return { data, k, entry: data[k] };
}

function checkFirstAction(guildId, userId, type) {
  const { data, k, entry } = getFirstActionData(guildId, userId);
  if (entry[type]) return false;
  entry[type] = true;
  save('first_actions.json', data);
  return true;
}

// ── Comeback System ────────────────────────────────────────────────────────────
function updateLastSeen(guildId, userId) {
  const data = load('last_seen.json');
  const k = key(guildId, userId);
  data[k] = Date.now();
  save('last_seen.json', data);
}

function getInactiveUsers(guildId, minDays = 3, maxDays = 7) {
  const data = load('last_seen.json');
  const now = Date.now();
  const minMs = minDays * 24 * 60 * 60 * 1000;
  const maxMs = maxDays * 24 * 60 * 60 * 1000;
  return Object.entries(data)
    .filter(([k]) => k.startsWith(guildId))
    .filter(([, ts]) => now - ts >= minMs && now - ts <= maxMs)
    .map(([k]) => k.replace(`${guildId}-`, ''));
}

function getComebackData(guildId, userId) {
  const data = load('comeback.json');
  const k = key(guildId, userId);
  if (!data[k]) data[k] = { lastComebackReward: null };
  return { data, k, entry: data[k] };
}

function canGiveComebackReward(guildId, userId) {
  const { entry } = getComebackData(guildId, userId);
  const cooldown = 7 * 24 * 60 * 60 * 1000;
  if (!entry.lastComebackReward) return true;
  return Date.now() - entry.lastComebackReward > cooldown;
}

function recordComebackReward(guildId, userId) {
  const { data, k, entry } = getComebackData(guildId, userId);
  entry.lastComebackReward = Date.now();
  save('comeback.json', data);
}

// ── Claimable Rewards ─────────────────────────────────────────────────────────
function addClaimableReward(guildId, userId, reward) {
  const data = load('claimable.json');
  const k = key(guildId, userId);
  if (!data[k]) data[k] = [];
  data[k].push({ ...reward, addedAt: Date.now(), id: `${Date.now()}-${Math.random().toString(36).slice(2)}` });
  save('claimable.json', data);
}

function getClaimableRewards(guildId, userId) {
  const data = load('claimable.json');
  const k = key(guildId, userId);
  return data[k] || [];
}

function claimAllRewards(guildId, userId) {
  const data = load('claimable.json');
  const k = key(guildId, userId);
  const rewards = data[k] || [];
  data[k] = [];
  save('claimable.json', data);
  let totalCoins = 0, totalXp = 0;
  for (const r of rewards) {
    if (r.coins) { addCoins(guildId, userId, r.coins); totalCoins += r.coins; }
    if (r.xp) { addXp(guildId, userId, r.xp); totalXp += r.xp; }
  }
  return { rewards, totalCoins, totalXp };
}

// ── Chaos Mode ────────────────────────────────────────────────────────────────
const chaosModeState = new Map(); // guildId -> { active, endsAt, multiplier }

function getChaosMode(guildId) {
  const state = chaosModeState.get(guildId);
  if (!state) return { active: false };
  if (Date.now() > state.endsAt) { chaosModeState.delete(guildId); return { active: false }; }
  return state;
}

function activateChaosMode(guildId, durationMs = 30 * 60 * 1000, multiplier = 2) {
  chaosModeState.set(guildId, { active: true, endsAt: Date.now() + durationMs, multiplier, startedAt: Date.now() });
}

// ── Matchmaking Queue ─────────────────────────────────────────────────────────
const queues = new Map(); // `${guildId}-${game}` -> [{ userId, joinedAt }]

function joinQueue(guildId, userId, game) {
  const k = `${guildId}-${game}`;
  if (!queues.has(k)) queues.set(k, []);
  const q = queues.get(k);
  if (q.find((e) => e.userId === userId)) return { success: false, reason: 'Already in this queue.' };
  q.push({ userId, joinedAt: Date.now() });
  return { success: true, position: q.length, total: q.length };
}

function leaveQueue(guildId, userId, game) {
  const results = [];
  for (const [k, q] of queues.entries()) {
    if (!k.startsWith(guildId)) continue;
    if (game && k !== `${guildId}-${game}`) continue;
    const idx = q.findIndex((e) => e.userId === userId);
    if (idx !== -1) { q.splice(idx, 1); results.push(k.replace(`${guildId}-`, '')); }
  }
  return results.length > 0 ? { success: true, games: results } : { success: false, reason: 'Not in any queue.' };
}

function getQueue(guildId, game) {
  return queues.get(`${guildId}-${game}`) || [];
}

function getQueueSummary(guildId) {
  const result = [];
  for (const [k, q] of queues.entries()) {
    if (k.startsWith(guildId) && q.length > 0) result.push({ game: k.replace(`${guildId}-`, ''), players: q.length });
  }
  return result;
}

function popGroup(guildId, game, size = 4) {
  const k = `${guildId}-${game}`;
  const q = queues.get(k) || [];
  if (q.length < size) return null;
  return q.splice(0, size).map((e) => e.userId);
}

// ── Analytics Tracking ────────────────────────────────────────────────────────
function trackMessageAnalytics(guildId, channelId) {
  const data = load('analytics.json');
  if (!data[guildId]) data[guildId] = {};
  const g = data[guildId];

  const today = new Date().toDateString();
  const hour  = new Date().getHours().toString();

  // Reset daily counters when date changes
  if (g.date !== today) {
    // Push yesterday into weekly history before resetting
    if (g.date && g.todayMessages > 0) {
      if (!g.weeklyData) g.weeklyData = [];
      g.weeklyData.push({ date: g.date, messages: g.todayMessages });
      if (g.weeklyData.length > 7) g.weeklyData.shift();
    }
    g.date          = today;
    g.todayMessages = 0;
    g.hourCounts    = {};
    g.channelCounts = {};
  }

  g.todayMessages = (g.todayMessages || 0) + 1;

  if (!g.hourCounts)    g.hourCounts    = {};
  if (!g.channelCounts) g.channelCounts = {};

  g.hourCounts[hour]        = (g.hourCounts[hour]        || 0) + 1;
  g.channelCounts[channelId] = (g.channelCounts[channelId] || 0) + 1;

  save('analytics.json', data);
}

function getAnalytics(guildId) {
  const data = load('analytics.json');
  return data[guildId] || {};
}

// ── Session System ────────────────────────────────────────────────────────────
function getSessionStats(guildId, userId) {
  const data = load('session_stats.json');
  const k = key(guildId, userId);
  if (!data[k]) data[k] = { joined: 0, completed: 0 };
  return data[k];
}

function recordSessionJoin(guildId, userId) {
  const data = load('session_stats.json');
  const k = key(guildId, userId);
  if (!data[k]) data[k] = { joined: 0, completed: 0 };
  data[k].joined += 1;
  save('session_stats.json', data);
}

function recordSessionComplete(guildId, userId) {
  const data = load('session_stats.json');
  const k = key(guildId, userId);
  if (!data[k]) data[k] = { joined: 0, completed: 0 };
  data[k].completed += 1;
  save('session_stats.json', data);
}

function getSessionLeaderboard(guildId) {
  const data = load('session_stats.json');
  return Object.entries(data)
    .filter(([k]) => k.startsWith(guildId))
    .map(([k, v]) => ({ userId: k.split('-')[1], joined: v.joined || 0, completed: v.completed || 0 }))
    .sort((a, b) => b.completed - a.completed)
    .slice(0, 10);
}

// ── XP Boosts ─────────────────────────────────────────────────────────────────
const xpBoosts = new Map(); // key(guildId, userId) -> expiryTimestamp

function activateXpBoost(guildId, userId) {
  const k = key(guildId, userId);
  xpBoosts.set(k, Date.now() + 60 * 60 * 1000); // 1 hour
}

function hasActiveXpBoost(guildId, userId) {
  const k = key(guildId, userId);
  const expiry = xpBoosts.get(k);
  if (!expiry) return false;
  if (Date.now() > expiry) { xpBoosts.delete(k); return false; }
  return true;
}

function getXpBoostExpiry(guildId, userId) {
  const k = key(guildId, userId);
  return xpBoosts.get(k) || null;
}

module.exports = {
  load,
  addXp, getLevel, getLeaderboard, xpForLevel,
  activateXpBoost, hasActiveXpBoost, getXpBoostExpiry,
  getCoins, addCoins, claimDaily, claimWeekly, addVoiceMinutes, incrementMessageCount,
  getInventory, addToInventory, removeFromInventory,
  getPath, setPath,
  getChallenge, setPendingChallenge, clearChallenge, recordChallengeResult, getChallengeLeaderboard,
  getRep, addRep,
  DAILY_QUESTS, WEEKLY_QUESTS, getQuestData, incrementQuestProgress, claimQuest,
  getUserSquad, createSquad, joinSquad, leaveSquad, getSquadLeaderboard,
  listItem, getListings, buyListing, removeListing,
  createMysteryDrop, claimMysteryDrop,
  getSeasonData, advanceSeason,
  getRoleShopStock, buyRoleShopItem,
  getActivityStreak, updateActivityStreak,
  CONTRACT_POOL, getContractData, acceptContract, claimContract, updateContractProgress,
  createAuction, getAuctions, placeBid, endAuction,
  getGameRotation, rotateGames, GAME_POOL,
  // New systems
  ACHIEVEMENTS, getAchievements, updateAchievementProgress, setAchievementProgress, claimAchievement,
  UPGRADES, getUpgrades, buyUpgrade, getUpgradeMultiplier,
  checkFirstAction,
  updateLastSeen, getInactiveUsers, canGiveComebackReward, recordComebackReward,
  addClaimableReward, getClaimableRewards, claimAllRewards,
  getChaosMode, activateChaosMode,
  joinQueue, leaveQueue, getQueue, getQueueSummary, popGroup,
  getSessionStats, recordSessionJoin, recordSessionComplete, getSessionLeaderboard,
  trackMessageAnalytics, getAnalytics,
};
